# GE2RB Vita → iOS static recompilation (private test project)

Target: God Eater 2 Rage Burst (PCSE00789). **Keep this repo PRIVATE.** It must never contain game
files, and anything generated from them (ELFs, lifted C, built IPA with game code) is derived work: don't publish it.

## Status
| Stage | State |
|---|---|
| 1. prep: merge patch, SELF→ELF, manifest, HLE worklist | **done** (`converter/prep.py`) |
| 2a. analyze: function table (exidx) + instruction histogram | done (`converter/analyze.py`, runs in CI) |
| 2b. lifter Thumb-2 → C (`converter/lift.py`) + Unicorn differential test (`difftest.py`) | v1: integer core, scalar VFP, exclusives, jump tables. First CI run: 95.1% difftest pass, 95.4% of reached instructions lifted; v1 fixes ADC/SBC flags, adds VFP etc. |
| 3a. SELF loader + relocations (`runtime/src/vita_loader.c`) | done: loads all 53 eboot+bin modules; relocated images identical to the Python reference (`converter/check_loader.py`) |
| 3b. NID linker (`runtime/src/vita_link.c`): 12,570 cross-module function imports + 1,002 variable imports resolve with 0 missing; C == Python analysis | done |
| 4. PC runner (`runtime/runner`): lift all modules -> native -> run module_start | first run: Boot module_start executed locally; full-game run happens in CI (`boot_run.txt`) |
| 4. HLE kernel/IO/thread | runtime core only (`runtime/`) |
| 5. SceGxm→Metal, SceNgs, AvPlayer | not started |
| Launcher app (import game .zip into the app, checks, memory probe) | done, runs on device (TrollStore) |
| Touch controls + gamepad → runtime input state | done (Controls test screen), **untested on device** |

## Option A (easiest): run the workflow with a link to your own game zip
Actions → build → **Run workflow** → paste a direct link (or Google Drive link) to a zip that contains
`app/PCSE00789` and `patch/PCSE00789`. Leave the link EMPTY to reuse the newest cached game zip (no download). If you type a link, it is ALWAYS downloaded fresh and replaces the cache; it is typed into the workflow input box (the same link reuses the cache). Note: workflow inputs are visible on the run page, so keep the repo private.
CI downloads the zip, extracts only the code files (~40 MB), converts and builds.
The zip (3.8 GB) goes into the Actions cache (limit 10 GB/repo, evicted after 7 days unused; the cache key is a hash of your link):
a cache hit is reused and never re-saved; a miss downloads (manual runs only) and saves after the zip validated. Change `cache_version` to force a re-download. Only use links to your own dump, in a PRIVATE repo.

## Option B: upload your game code to a private release
Only code is needed in CI (~20 MB). Assets (3.77 GB) stay on your phone.

```
game-code/
  app/    eboot.bin  bin/  sce_module/  modules_psvita/     (from ux0:app/PCSE00789)
  patch/  eboot.bin  bin/  sce_module/                      (from ux0:patch/PCSE00789)
```
```
cd game-code && zip -r ../game-code.zip app patch && cd ..
gh release create game-code game-code.zip --title game-code --notes "private"
```
Push → Actions runs `runtime-test`, `converter`, `ios`. Download the IPA artifact and sideload with SideStore/AltStore.

## Run converter locally
```
python converter/prep.py --app game-code/app --patch game-code/patch --out out
cat out/REPORT.txt
```
Patch files override base files with the same relative path.

## Notes / caveats
- The entitlements (increased-memory-limit, extended-virtual-addressing) are fake-signed with ldid. SideStore re-signs; free
  Apple IDs may drop them. "Test memory reservation" in the app tells you if the 4 GiB reservation works on your device.
- `Launch` is intentionally disabled until lifted code exists.
- Game must be decrypted already (yours is). Encrypted SELFs raise a clear error.

## Using the app
1. Zip your own dump so it contains `app/PCSE00789/...` and `patch/PCSE00789/...` (a wrapper folder or `ux0/` prefix is fine; a bare `PCSE00789/` is treated as base).
2. Put the zip on the phone (Files → On My iPhone; iCloud works but downloads first), then **Import game zip…** in the app. It extracts to the app's Documents/Game (~3.8 GB, excluded from iCloud backup).
3. The Checks section verifies the files and (once converted code is embedded) the game version hash.
Importing the zip only provides the assets. The game's *code* must still be recompiled by `converter/` and linked into the IPA at build time (iOS cannot compile or JIT on device).

## Lifter status (2b)
Facts from the game analysis: 80,981 real Thumb-2 functions; the ~13.3k ARM-mode entries are 16-byte import stubs (resolved by NID → HLE, not lifted);
only ~58 real ARM functions exist. Thumb: 216 base mnemonics, top 100 cover 99.2% of instructions. Not yet lifted: VFP (3.4%), NEON (0.1%),
ldrex/strex/dmb, tbb/tbh jump tables, adr. CI job `converter` runs: mock test → difftest vs Unicorn → coverage → emit+syntax-check Boot module.

First CI results (v0): difftest 9943/10451; only ADC/SBC failed (Capstone reports update_flags for the carry *read*, fixed by using the mnemonic's `s`).
Unsupported then: scalar VFP ~99k insns, HINT 12k, BKPT 12k, MOVS 8k, tbb/tbh 1.1k, ldrex/strex 1.4k -> all handled in v1. Still missing: NEON (~800), vcvt fixed-point/vcvtr, adr.
Build note: lifted C must be compiled with `-ffp-contract=off -fno-math-errno` (already set in launcher/project.yml).

v2 results: difftest 17889/18358 (97.45%), coverage 99.96% (3,210,568 / 3,211,980). Remaining unsupported ~1.4k NEON instructions (vld1/vst1, vshr, vpadd, ...), 7 tbb/tbh, adr, a few coprocessor ops.
Known difftest artifact: on x86 CI, invalid float ops give a NEGATIVE default NaN; ARM and arm64 give a positive one -> difftest ignores NaN sign/payload.
v3 adds: NEON subset (vorr/vand/vbic/veor/vbsl/vbif/vbit/vmvn/vdup/vceq/vmov.i, f32 lanes with flush-to-zero), UXTAH precedence fix, TLS read (mrc p15 c13 c0 3), pld.

v3 CI results: difftest 20409/20457 (99.77%); only VADD failed (NEON integer vadd.i32 was treated as float) -> fixed in v4 with integer lane ops.
v3 regression found by coverage: FMSTAT/VMSR with apsr_nzcv/fpscr operands were rejected (5.4k insns) -> fixed in v4 (vk never raises for non-GPR names).

Relocation format (decoded + verified on 610k entries): see converter/relocs.py. Only 3 codes occur: ABS32 (2), THM_MOVW_ABS_NC (47), THM_MOVT_ABS (48).
MOVW/MOVT sites are patched by the loader, so the lifter emits `MOD_SEG[sym] + addend` for them (value known only at runtime).

Bug caught by the relocation-site metric (v5 CI): only 49.76% of movw/movt relocation sites were reached -> Capstone reports Thumb `movw` under the generic MOV id,
so relocated movw were lifted with their stale link-time immediate. Fixed by routing mnemonic `movw` to the MOVW path. Expect ~100% of reachable sites after this.

Boot pipeline (CI, manual runs): `lift.py all` -> `m*.c` (static symbols per module, ~360 MB of C for the whole game, ~20 min of compile on one core at -O1)
-> `runtime/runner/build.sh` -> `vita_run APPDIR PATCHDIR`. Unimplemented system calls are logged ONCE with their real name and return 0 (trace mode);
set VRT_STRICT=1 to abort instead. `boot_run.txt` therefore lists, in order, the system calls the game makes during start-up = the HLE to write next.
HLE functions are declared with the HLE(nid, name) macro (see runtime/runner/hle_boot.c).

v6 (first full-game boot attempt in CI): the lifter steps never ran because of two regressions of mine, both now guarded by tests that run first in CI:
 1. `lift.py all` registered `--out` twice (argparse error)  -> converter/test_cli.py parses every command line the workflow uses.
 2. a refactor dropped VitaModule.function_starts()          -> converter/test_vita_api.py.
Function discovery now = exidx + exported entry points + thumb code pointers in relocation data + Thumb call targets found while decoding
(exidx lacks a few tiny leaf functions in libc/libdeflt). Known gap: ~58 real ARM-mode (non-stub) functions are not lifted yet; `lift_all.txt` reports `arm-unlifted`.
Local rehearsal of the whole boot pipeline with a stub decoder: all 58 modules generate, build, load, link (0 unbound redirects) and start.

v7 (first real execution in CI): libc.suprx module_start ran natively and reached its first system calls (GetProcessParam, CreateLwMutex/Cond, GetStdin/out/err, Lock/UnlockLwMutex, GetTLSAddr).
It crashed because GetTLSAddr was unimplemented (returned 0 -> NULL deref). Fixed by `runtime/runner/hle_kernel.c`: ~100 kernel calls on pthreads
(threads, semaphores, event flags, lw mutex/cond, TLS, memory blocks, time, sceClib*, printf with AAPCS varargs, file I/O with app0:/patch0: mapping),
unit-tested in runtime/test/test_hle.c. NID names for NID_xxx defines come from out/nid_defs.h (generated by gen_nid_names.py).
Env vars for the PC runner: VRT_APP0 / VRT_PATCH0 (asset roots), VRT_IOLOG=1 (log every sceIoOpen), VRT_STRICT=1 (abort on the first unimplemented call).
Still to implement (unique functions): SceGxm 101, SceNp* ~100, SceNgs 37, SceLibJson 33, AppUtil/CommonDialog/Ime ~41, AvPlayer 11, Ctrl/Touch/Audio/Display/Power/Rtc/...

v8 (CI run with kernel HLE): HLE unit test passed on CI; libc.suprx module_start crashed right after sceKernelGetProcessParam because I returned the address of
module_sdk_version (NID 0x936C8A78, value 0x03100501) instead of module_proc_param (NID 0x70FBA1E7, starts {0x34,'PSP2'}). Fixed + verified locally against the real eboot.
The runner now prints the guest fault address and the guest call chain (`[bt] #n module+0xOFF`); CI runs converter/crash_disasm.py to disassemble those functions into out/crash_disasm.txt.

v9 (CI boot log): libc.suprx module_start ran, called back into the game's eboot (malloc setup), and stopped at `vst1` (NEON store, used by libc memset/memcpy), the first
instruction the lifter did not support. Added VLD1/VST1 (multi-register, lane, writeback/post-index) and VMULL/VMLAL/VMLSL/VMOVL/VSHLL/VADDW/VSHL/VSHR/VSHRN/VSLI/VPADD/VPADDL/VPADAL/VUZP/VTRN/
VREV16/32/64/VCLE/VCLT/VCGE/VCGT/VACGT/VMAX/VMIN and f32 multiply-by-scalar. Verified locally with helper unit tests + harness checks; the next CI difftest checks them against Unicorn on real encodings.
Still unlifted: VRECPE/VRSQRTE/VRECPS/VRSQRTS (bit-exact estimate tables), VCVTB, vmull.p8, Q-form vuzp/vtrn, CDP/LDC/STC coprocessor ops, adr, 7 tbb/tbh tables, ~20 ARM-mode functions.

v10 (CI): difftest 99.48% (21523/21635): only VST1 lane forms failed (`vst1.8 {d16[0]}, [r1]`: memory differs) -> Capstone exposes the lane as vector_index OR neon_lane; lifter now checks both (`_lane`).
All the new NEON mnemonics (VMULL, VLD1, ...) passed against Unicorn. Coverage 100.00% (110 unsupported of 3.21M).
Boot now gets through libc, libfios2 and libult module_start and into eboot's module_start, which calls abort() (libc NID 0x20fe0fff) because libc NID 0x54f87eac returns non-zero.
New debugging aids: runner prints the last 48 calls before a crash (`[call] #n module+0xOFF [export name]`), first unimplemented HLE call prints its guest backtrace, nid_db.json gives names for
game-provided libs too (vita-headers), and `converter/disasm_request.txt` lists functions to disassemble into out/crash_disasm.txt (edit it, push, run again).

v11 (CI boot log analysed by hand): the abort() came from libc calling sceKernelGetModuleInfoByAddr (static TLS setup) which my HLE answered with an error -> libc returned -1 -> eboot aborted.
Implemented the real thing (SceKernelModuleInfo 0x1B8: name, entries, exidx/extab, tlsInit/tlsInitSize/tlsAreaSize taken from the module's SceModuleInfo, segments); tested against the real eboot
(runtime/test/test_modinfo.c). libc's module_start ends with sceKernelExitThread(0), so ExitThread now unwinds to the thread/module_start boundary with longjmp (hle_common.h) instead of being a no-op.
Facts learned: libc malloc init reads the process param (0x70FBA1E7 export), its libcparam (+0x2c) and calls the game's allocator callbacks; module info TLS fields are segment OFFSETS.

v12 (CI): eboot passed abort(), loaded the game modules (enemy, musen, ys, net, god, script, missionorder, ui, rune via sceKernelLoadStartModule) and ran its start-up: AppUtil, Ctrl, Net/Np init, audio port,
then crashed in NGS init: the unimplemented sceNgsSystemGetRequiredMemorySize left its out-parameter unwritten, so the game memset a garbage size.
Lesson: for system calls whose out-parameters the game reads, returning 0 is not enough. New HLE files: hle_system.c (Ctrl/Touch from the input state, Display pacing, AudioOut, NGS null engine with real out-params,
RTC, AppUtil, dialogs/Ime stubs, libc time) and hle_gxm.c (all 101 imported SceGxm functions: objects/out-params/uniform buffers/sync objects/notification region, state+draw counted, vsync-paced display queue calling the game's callback).
Gxm is a NULL renderer for now (nothing is drawn); the Metal backend replaces the counting hooks. Set VRT_GXMLOG=1 to print frames/scenes/draws.

v13 (CI): boot passed NGS/Gxm init and reached real game code, then stopped on `vrsqrte` (NEON reciprocal-sqrt estimate). Added VRECPE/VRSQRTE/VRECPS/VRSQRTS (ARM FPRecipEstimate/FPRSqrtEstimate,
constants 2^19 and 2^28), VMULL.P8, VCVTB/VCVTT, ADR (from the raw encoding) and **ARM-mode lifting**: Thumb code calls ~20 ARM-mode routines (libgcc-style integer division etc.) that have no exidx entry
and were never lifted. `_lift_all` now lifts every non-stub ARM call target with an ARM-mode Lifter (pc reads +8, bl/blx interworking, mov pc,lr). Import stubs (4-word pattern) are skipped.
`converter/difftest_arm.py` runs each ARM function whole in Unicorn vs lifted C (return regs, callee-saved regs, sp, memory).

v14 (CI): the first crash inside real game code was a LIFTER bug: `blx lr` (vtable calls load the method into lr) wrote lr = return address before reading the target, so the call went to the next instruction
(`call to unrecompiled address 0x900bd7c7` = the instruction after the blx). Fixed (target read first) + regression test in test_lift_mock.py.
Single-instruction difftest can't see control-flow/ordering bugs like this, so there is now `converter/difftest_fn.py`: whole-function differential test (Thumb + ARM) against Unicorn using the module's real bytes,
random registers (pointers into a mapped data area) and the module's data segment; it skips functions that call out. Pgf font lifecycle stubs added. Note: the CI step for difftest.py had been broken by a YAML
line-folding mistake of mine (two commands folded into one) -> `run: |` block now.
