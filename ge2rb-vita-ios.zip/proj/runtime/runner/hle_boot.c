/* HLE: module loading and a few trivially-correct kernel calls. More HLE goes in separate files (hle_*.c). */
#include "vita_link.h"
#include "hle_common.h"
#include <stdio.h>
#include <string.h>

#define HLE(nid, name) static void hle_##name(vrt_ctx *x); \
    __attribute__((constructor)) static void reg_##name(void) { vrt_register_hle(nid, hle_##name, #name); } \
    static void hle_##name(vrt_ctx *x)

static unsigned char started[512];

/* Run a module's module_start(args, argp) on the calling guest thread. Returns its r0. */
int hle_start_module(vrt_ctx *x, int idx, uint32_t args, uint32_t argp) {
    if (idx < 0 || idx >= 512 || started[idx]) return 0;
    started[idx] = 1;
    uint32_t entry = vrt_link_module_export(idx, 0x935CD196u);
    if (!entry) { fprintf(stderr, "[boot] %s has no module_start\n", vrt_link_module_name(idx)); return 0; }
    fprintf(stderr, "[boot] module_start %s @%08x\n", vrt_link_module_name(idx), entry);
    uint32_t sr[16]; memcpy(sr, x->r, sizeof sr);
    x->r[0] = args; x->r[1] = argp; x->r[14] = 0;
    jmp_buf jb, *prev = hle_exit_jb; hle_exit_jb = &jb; int depth = vrt_cs_get();
    if (setjmp(jb) == 0) vrt_call(x, entry);
    else vrt_cs_set(depth);                               /* module_start ended through sceKernelExitThread(status) */
    hle_exit_jb = prev;
    int rc = (int)x->r[0];
    memcpy(x->r, sr, sizeof sr);
    return rc;
}

/* SceUID sceKernelLoadStartModule(const char *path, SceSize args, void *argp, int flags, void *opt, int *res) */
HLE(0x2DCC4AFAu, sceKernelLoadStartModule) {
    const char *path = (const char *)VRT_G2H(x->r[0]);
    uint32_t args = x->r[1], argp = x->r[2], res = x->r[5 - 1 + 0];   /* res is the 6th arg (stack): not needed yet */
    (void)res;
    int idx = vrt_link_find_module(path);
    fprintf(stderr, "[hle] sceKernelLoadStartModule(\"%s\") -> module %d\n", path, idx);
    if (idx < 0) { x->r[0] = 0x80010002u; return; }
    hle_start_module(x, idx, args, argp);
    x->r[0] = 0x1000u + (uint32_t)idx;                   /* positive module uid */
}
