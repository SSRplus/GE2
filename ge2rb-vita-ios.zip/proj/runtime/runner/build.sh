#!/bin/sh
# usage: build.sh GENDIR OUTBIN [NID_NAMES_C]   (GENDIR holds m*.c and modules_table.c from `lift.py all`)
set -e
GEN=$1; OUT=$2; NIDC=$3
HERE=$(cd "$(dirname "$0")" && pwd); INC=$HERE/../include; SRC=$HERE/../src
CF="-O1 -w -ffp-contract=off -fno-math-errno -I$INC -I$(dirname "$NIDC")"
mkdir -p "$GEN/obj"
ls "$GEN"/*.c | xargs -P "${JOBS:-4}" -I{} sh -c 'o='"$GEN"'/obj/$(basename {} .c).o; gcc '"$CF"' -c {} -o $o'
for f in "$SRC"/*.c "$HERE"/*.c $NIDC; do gcc $CF -c "$f" -o "$GEN/obj/rt_$(basename "$f" .c).o"; done
gcc "$GEN"/obj/*.o -o "$OUT" -lpthread -lm
