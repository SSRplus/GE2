/* HLE of libGxm with a NULL renderer: every object is created and every out-parameter is filled so the game's graphics code runs,
   state/draw calls are counted but draw nothing yet. The display queue is emulated (vsync-paced, calls the game's callback).
   The Metal backend will replace the counting hooks (gxm_draw etc.). */
#include "vita_link.h"
#include "nid_defs.h"
#include "hle_common.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define HLE(name) static void hle_##name(vrt_ctx *x); \
    __attribute__((constructor)) static void reg_##name(void) { vrt_register_hle(NID_##name, hle_##name, #name); } \
    static void hle_##name(vrt_ctx *x)
#define RET(v) do { x->r[0] = (uint32_t)(v); } while (0)
#define GX0(name) HLE(name) { (void)x; RET(0); }
static void w32(uint32_t gp, uint32_t v) { if (gp) memcpy(VRT_G2H(gp), &v, 4); }
static uint32_t r32(uint32_t gp) { uint32_t v = 0; if (gp) memcpy(&v, VRT_G2H(gp), 4); return v; }
static uint32_t stack_arg(vrt_ctx *x, int i) { return r32(x->r[13] + 4u * (uint32_t)i); }       /* i-th argument beyond r0-r3 */

static int g_log;
static uint64_t n_draws, n_scenes, n_frames;
static uint32_t alloc_obj(uint32_t size) { return vrt_alloc(size, 16); }

/* ---------------------------------------------------------------- init / memory */
static struct { uint32_t cb, cbsize, maxpend; } g_init;
HLE(sceGxmInitialize) {
    uint32_t p = x->r[0]; g_log = getenv("VRT_GXMLOG") != NULL;
    if (p) { g_init.maxpend = r32(p + 4); g_init.cb = r32(p + 8); g_init.cbsize = r32(p + 12); }
    if (g_init.maxpend == 0 || g_init.maxpend > 8) g_init.maxpend = 2;
    fprintf(stderr, "[gxm] initialize: displayQueueMaxPending=%u callback=%08x dataSize=%u\n", g_init.maxpend, g_init.cb, g_init.cbsize);
    RET(0);
}
GX0(sceGxmTerminate) GX0(sceGxmMapMemory) GX0(sceGxmUnmapMemory) GX0(sceGxmUnmapVertexUsseMemory) GX0(sceGxmUnmapFragmentUsseMemory)
HLE(sceGxmMapVertexUsseMemory) { w32(x->r[2], 0); RET(0); }
HLE(sceGxmMapFragmentUsseMemory) { w32(x->r[2], 0); RET(0); }
GX0(sceGxmSetWarningEnabled) GX0(sceGxmPadHeartbeat)

/* ---------------------------------------------------------------- contexts, render targets, scenes */
HLE(sceGxmCreateContext) { uint32_t c = alloc_obj(0x100); w32(c, r32(x->r[0] + 0)); w32(x->r[1], c); RET(0); }
HLE(sceGxmCreateDeferredContext) { w32(x->r[1], alloc_obj(0x100)); RET(0); }
GX0(sceGxmDestroyContext) GX0(sceGxmDestroyDeferredContext) GX0(sceGxmBeginCommandList) GX0(sceGxmEndCommandList) GX0(sceGxmExecuteCommandList)
GX0(sceGxmSetDeferredContextVdmBuffer) GX0(sceGxmSetDeferredContextVertexBuffer) GX0(sceGxmSetDeferredContextFragmentBuffer)
HLE(sceGxmCreateRenderTarget) { w32(x->r[1], alloc_obj(0x40)); RET(0); }
GX0(sceGxmDestroyRenderTarget)
HLE(sceGxmGetRenderTargetMemSize) {                      /* returns the size; also fills *r1 when r1 looks like a guest pointer */
    if (x->r[1] >= 0x90000000u && x->r[1] < 0xA0000000u) w32(x->r[1], 0x4000);
    RET(0x4000);
}
static uint32_t g_ubuf_v, g_ubuf_f;
HLE(sceGxmReserveVertexDefaultUniformBuffer) { if (!g_ubuf_v) g_ubuf_v = alloc_obj(0x10000); w32(x->r[1], g_ubuf_v); RET(0); }
HLE(sceGxmReserveFragmentDefaultUniformBuffer) { if (!g_ubuf_f) g_ubuf_f = alloc_obj(0x10000); w32(x->r[1], g_ubuf_f); RET(0); }
HLE(sceGxmBeginScene) { n_scenes++; RET(0); }
GX0(sceGxmEndScene) GX0(sceGxmFinish)
HLE(sceGxmSyncObjectCreate) { w32(x->r[0], alloc_obj(64)); RET(0); }
GX0(sceGxmSyncObjectDestroy)
HLE(sceGxmGetNotificationRegion) { static uint32_t reg; if (!reg) reg = alloc_obj(0x1000); RET(reg); }
GX0(sceGxmNotificationWait)

/* ---------------------------------------------------------------- shader patcher / programs */
HLE(sceGxmShaderPatcherCreate) { w32(x->r[1], alloc_obj(0x80)); RET(0); }
GX0(sceGxmShaderPatcherDestroy) GX0(sceGxmShaderPatcherUnregisterProgram)
HLE(sceGxmShaderPatcherRegisterProgram) { uint32_t id = alloc_obj(16); w32(id, x->r[1]); w32(x->r[2], id); RET(0); }   /* id block remembers the program header */
HLE(sceGxmShaderPatcherCreateVertexProgram) { uint32_t o = stack_arg(x, 2); w32(o, alloc_obj(0x40)); RET(0); }
HLE(sceGxmShaderPatcherCreateFragmentProgram) { uint32_t o = stack_arg(x, 2); w32(o, alloc_obj(0x40)); RET(0); }
GX0(sceGxmShaderPatcherReleaseVertexProgram) GX0(sceGxmShaderPatcherReleaseFragmentProgram)
static uint32_t dummy_param(void) { static uint32_t p; if (!p) p = alloc_obj(64); return p; }
HLE(sceGxmProgramGetParameterCount) { RET(0); }
HLE(sceGxmProgramGetParameter) { RET(dummy_param()); }
HLE(sceGxmProgramFindParameterByName) { RET(dummy_param()); }
HLE(sceGxmProgramParameterGetCategory) { RET(1); }          /* SCE_GXM_PARAMETER_CATEGORY_UNIFORM */
HLE(sceGxmProgramParameterGetResourceIndex) { RET(0); }
HLE(sceGxmProgramParameterGetName) { static uint32_t n; if (!n) { n = alloc_obj(16); } RET(n); }
HLE(sceGxmProgramParameterGetType) { RET(0); }
HLE(sceGxmProgramParameterGetComponentCount) { RET(4); }
HLE(sceGxmProgramParameterGetArraySize) { RET(1); }
HLE(sceGxmProgramParameterGetSemantic) { RET(0); }

/* ---------------------------------------------------------------- surfaces / textures (own packed layout; the game only uses the API) */
HLE(sceGxmColorSurfaceInit) {    /* (surface, format, type, scaleMode, outputRegisterSize, width, height, strideInPixels, data) */
    uint32_t s = x->r[0], w = stack_arg(x, 1), h = stack_arg(x, 2), stride = stack_arg(x, 3), data = stack_arg(x, 4);
    w32(s, data); w32(s + 4, x->r[1]); w32(s + 8, x->r[2]); w32(s + 12, stride); w32(s + 16, w); w32(s + 20, h); RET(0);
}
HLE(sceGxmColorSurfaceGetData) { RET(r32(x->r[0])); }
HLE(sceGxmColorSurfaceGetFormat) { RET(r32(x->r[0] + 4)); }
HLE(sceGxmColorSurfaceGetType) { RET(r32(x->r[0] + 8)); }
HLE(sceGxmColorSurfaceGetStrideInPixels) { RET(r32(x->r[0] + 12)); }
GX0(sceGxmDepthStencilSurfaceInit) GX0(sceGxmDepthStencilSurfaceSetForceLoadMode) GX0(sceGxmDepthStencilSurfaceSetForceStoreMode)
/* texture: [0]=data [4]=format [8]=width [12]=height */
static void tex_init(vrt_ctx *x, uint32_t data_i, uint32_t w, uint32_t h) { uint32_t t = x->r[0]; w32(t, data_i); w32(t + 4, x->r[2]); w32(t + 8, w); w32(t + 12, h); }
HLE(sceGxmTextureInitLinear) { tex_init(x, x->r[1], x->r[3], stack_arg(x, 0)); RET(0); }
HLE(sceGxmTextureInitLinearStrided) { tex_init(x, x->r[1], x->r[3], stack_arg(x, 0)); RET(0); }
HLE(sceGxmTextureInitTiled) { tex_init(x, x->r[1], x->r[3], stack_arg(x, 0)); RET(0); }
HLE(sceGxmTextureInitSwizzled) { tex_init(x, x->r[1], x->r[3], stack_arg(x, 0)); RET(0); }
HLE(sceGxmTextureInitSwizzledArbitrary) { tex_init(x, x->r[1], x->r[3], stack_arg(x, 0)); RET(0); }
HLE(sceGxmTextureInitCube) { tex_init(x, x->r[1], x->r[3], stack_arg(x, 0)); RET(0); }
HLE(sceGxmTextureInitCubeArbitrary) { tex_init(x, x->r[1], x->r[3], stack_arg(x, 0)); RET(0); }
HLE(sceGxmTextureGetData) { RET(r32(x->r[0])); }
HLE(sceGxmTextureGetFormat) { RET(r32(x->r[0] + 4)); }
HLE(sceGxmTextureGetWidth) { RET(r32(x->r[0] + 8)); }
HLE(sceGxmTextureGetHeight) { RET(r32(x->r[0] + 12)); }
GX0(sceGxmTextureSetUAddrMode) GX0(sceGxmTextureSetVAddrMode) GX0(sceGxmTextureSetMinFilter) GX0(sceGxmTextureSetMagFilter)
GX0(sceGxmTextureSetMipFilter) GX0(sceGxmTextureSetLodBias) GX0(sceGxmTextureSetPalette)

/* ---------------------------------------------------------------- state + draw (counted) */
GX0(sceGxmSetVertexProgram) GX0(sceGxmSetFragmentProgram) GX0(sceGxmSetVertexStream) GX0(sceGxmSetFragmentTexture)
GX0(sceGxmSetFrontDepthFunc) GX0(sceGxmSetBackDepthFunc) GX0(sceGxmSetFrontDepthWriteEnable) GX0(sceGxmSetBackDepthWriteEnable)
GX0(sceGxmSetFrontStencilFunc) GX0(sceGxmSetFrontStencilRef) GX0(sceGxmSetCullMode) GX0(sceGxmSetViewport) GX0(sceGxmSetViewportEnable)
GX0(sceGxmSetRegionClip) GX0(sceGxmSetFrontPolygonMode) GX0(sceGxmSetBackPolygonMode) GX0(sceGxmSetFrontFragmentProgramEnable) GX0(sceGxmSetBackFragmentProgramEnable)
HLE(sceGxmDraw) { n_draws++; RET(0); }
HLE(sceGxmGetPrecomputedDrawSize) { RET(128); }
GX0(sceGxmPrecomputedDrawInit) GX0(sceGxmPrecomputedDrawSetParams) GX0(sceGxmPrecomputedDrawSetAllVertexStreams)

/* ---------------------------------------------------------------- display queue (vsync-paced worker that calls the game's callback) */
typedef struct { uint32_t data; } QEnt;
static pthread_mutex_t qm = PTHREAD_MUTEX_INITIALIZER; static pthread_cond_t qc = PTHREAD_COND_INITIALIZER, qdone = PTHREAD_COND_INITIALIZER;
static QEnt queue[16]; static int qhead, qcount, worker_started, in_flight;
static void *display_worker(void *a) {
    (void)a;
    vrt_ctx *x = calloc(1, sizeof *x); uint32_t st = vrt_alloc(0x40000, 0x1000); x->r[13] = st + 0x40000 - 64; x->tls = vrt_alloc(0x1000, 0x1000);
    for (;;) {
        pthread_mutex_lock(&qm);
        while (qcount == 0) pthread_cond_wait(&qc, &qm);
        QEnt e = queue[qhead]; in_flight = 1;
        pthread_mutex_unlock(&qm);
        usleep(16667);                                             /* one vsync */
        if (g_init.cb) { jmp_buf jb; hle_exit_jb = &jb; if (setjmp(jb) == 0) { x->r[0] = e.data; x->r[14] = 0; vrt_call(x, g_init.cb); } }
        pthread_mutex_lock(&qm);
        qhead = (qhead + 1) % 16; qcount--; in_flight = 0; n_frames++;
        if (g_log && (n_frames % 60) == 0) fprintf(stderr, "[gxm] frames=%llu scenes=%llu draws=%llu\n", (unsigned long long)n_frames, (unsigned long long)n_scenes, (unsigned long long)n_draws);
        pthread_cond_broadcast(&qdone);
        pthread_mutex_unlock(&qm);
    }
    return NULL;
}
HLE(sceGxmDisplayQueueAddEntry) {                         /* (oldSync, newSync, callbackData) */
    uint32_t src = x->r[2], size = g_init.cbsize ? g_init.cbsize : 16, copy = alloc_obj(size < 16 ? 16 : size);
    if (src) memcpy(VRT_G2H(copy), VRT_G2H(src), size);
    pthread_mutex_lock(&qm);
    while (qcount >= (int)g_init.maxpend) pthread_cond_wait(&qdone, &qm);          /* back-pressure like the real queue */
    queue[(qhead + qcount) % 16].data = copy; qcount++;
    if (!worker_started) { worker_started = 1; pthread_t t; pthread_attr_t at; pthread_attr_init(&at); pthread_attr_setstacksize(&at, 64u << 20); pthread_create(&t, &at, display_worker, NULL); pthread_detach(t); }
    pthread_cond_signal(&qc);
    pthread_mutex_unlock(&qm);
    RET(0);
}
HLE(sceGxmDisplayQueueFinish) { pthread_mutex_lock(&qm); while (qcount > 0 || in_flight) pthread_cond_wait(&qdone, &qm); pthread_mutex_unlock(&qm); RET(0); }
