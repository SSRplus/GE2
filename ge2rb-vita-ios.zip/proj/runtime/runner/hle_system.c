/* HLE of the Vita system libraries (non-graphics): controls, touch, display timing, audio out, NGS (null engine), RTC, AppUtil,
   system modules, dialogs, plus libc time helpers. Out-parameters are filled with plausible values: the game reads them. */
#include "vita_link.h"
#include "nid_defs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define HLE(name) static void hle_##name(vrt_ctx *x); \
    __attribute__((constructor)) static void reg_##name(void) { vrt_register_hle(NID_##name, hle_##name, #name); } \
    static void hle_##name(vrt_ctx *x)
#define RET(v) do { x->r[0] = (uint32_t)(v); } while (0)
#define STUB0(name) HLE(name) { (void)x; RET(0); }

static void w8(uint32_t gp, uint8_t v)  { if (gp) memcpy(VRT_G2H(gp), &v, 1); }
static void w16(uint32_t gp, uint16_t v) { if (gp) memcpy(VRT_G2H(gp), &v, 2); }
static void w32(uint32_t gp, uint32_t v) { if (gp) memcpy(VRT_G2H(gp), &v, 4); }
static void w64(uint32_t gp, uint64_t v) { if (gp) memcpy(VRT_G2H(gp), &v, 8); }
static uint64_t now_us(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return (uint64_t)ts.tv_sec * 1000000ull + (uint64_t)ts.tv_nsec / 1000; }
static void ret64(vrt_ctx *x, uint64_t v) { x->r[0] = (uint32_t)v; x->r[1] = (uint32_t)(v >> 32); }

/* ------------------------------------------------------------------------------------------------ controls */
/* SceCtrlData (0x20): u64 timeStamp; u32 buttons; u8 lx,ly,rx,ry; u8 up,right,left,down,lt,rt,l1,r1,triangle,circle,cross,square; u8 rsvd[4] */
static void fill_ctrl(uint32_t gp) {
    uint8_t *d = VRT_G2H(gp); memset(d, 0, 0x20);
    uint64_t t = now_us(); uint32_t b = vrt_input_get_buttons(); uint8_t st[4]; vrt_input_get_sticks(st);
    memcpy(d, &t, 8); memcpy(d + 8, &b, 4); memcpy(d + 12, st, 4);
}
HLE(sceCtrlReadBufferPositive2) { uint32_t n = x->r[2] ? x->r[2] : 1; for (uint32_t i = 0; i < n && i < 64; i++) fill_ctrl(x->r[1] + 0x20 * i); RET(n); }
STUB0(sceCtrlSetSamplingMode)
STUB0(sceCtrlIsMultiControllerSupported)
HLE(sceCtrlGetWirelessControllerInfo) { if (x->r[0]) memset(VRT_G2H(x->r[0]), 0, 16); RET(0); }

/* ------------------------------------------------------------------------------------------------ touch */
/* SceTouchPanelInfo: 10 x u16. SceTouchData (0x90): u64 timeStamp; u32 status; u32 reportNum; SceTouchReport report[8] (16 bytes: u8 id,u8 force,s16 x,s16 y,u8 rsvd[8],s16 info) */
HLE(sceTouchGetPanelInfo) {
    uint16_t front[10] = {0, 0, 1919, 1087, 0, 0, 1919, 1087, 1, 128}, rear[10] = {0, 108, 1919, 889, 0, 108, 1919, 889, 1, 128};
    if (x->r[1]) memcpy(VRT_G2H(x->r[1]), x->r[0] ? rear : front, 20);
    RET(0);
}
STUB0(sceTouchSetSamplingState)
HLE(sceTouchPeek) {
    int port = (int)x->r[0] ? 1 : 0; uint32_t nb = x->r[2] ? x->r[2] : 1;
    for (uint32_t b = 0; b < nb && b < 8; b++) {
        uint8_t *d = VRT_G2H(x->r[1] + 0x90 * b); memset(d, 0, 0x90);
        uint8_t ids[8]; uint16_t xs[8], ys[8]; int n = vrt_input_get_touches(port, ids, xs, ys, 6);
        uint64_t t = now_us(); uint32_t status = 0, num = (uint32_t)n;
        memcpy(d, &t, 8); memcpy(d + 8, &status, 4); memcpy(d + 12, &num, 4);
        for (int i = 0; i < n; i++) {
            uint8_t *r = d + 16 + 16 * i; r[0] = ids[i]; r[1] = 128;
            int16_t px = (int16_t)(xs[i] * 2), py = (int16_t)(ys[i] * 2); memcpy(r + 2, &px, 2); memcpy(r + 4, &py, 2);
        }
    }
    RET(nb);
}

/* ------------------------------------------------------------------------------------------------ display */
static volatile uint32_t g_fb_ptr, g_fb_w, g_fb_h, g_fb_pitch, g_fb_fmt;
/* SceDisplayFrameBuf: u32 size; void *base; u32 pitch; u32 pixelformat; u32 width; u32 height */
HLE(sceDisplaySetFrameBuf) {
    if (x->r[0]) {
        uint32_t v[6]; memcpy(v, VRT_G2H(x->r[0]), 24);
        g_fb_ptr = v[1]; g_fb_pitch = v[2]; g_fb_fmt = v[3]; g_fb_w = v[4]; g_fb_h = v[5];
    }
    RET(0);
}
HLE(sceDisplayWaitVblankStart) { usleep(16667); RET(0); }
HLE(sceDisplayGetVcount) { RET((uint32_t)(now_us() / 16667)); }

/* ------------------------------------------------------------------------------------------------ system modules / app / misc */
STUB0(sceSysmoduleLoadModule)
STUB0(sceSysmoduleUnloadModule)
HLE(sceAppMgrIsGameProgram) { RET(1); }
HLE(sceAppMgrReceiveSystemEvent) { RET(0x80802001u); }                                   /* no event pending */
HLE(_sceAppMgrGetAppState) { if (x->r[0] && x->r[1]) memset(VRT_G2H(x->r[0]), 0, x->r[1] < 256 ? x->r[1] : 256); RET(0); }
STUB0(sceAppUtilInit)
HLE(sceAppUtilSystemParamGetInt) {
    /* 1 LANG (1 = English US), 2 ENTER_BUTTON (1 = cross), 3 DATE_FORMAT, 4 TIME_FORMAT (1 = 24h), 5 TIME_ZONE, 6 SUMMERTIME */
    static const int32_t v[8] = {0, 1, 1, 0, 1, 0, 0, 0};
    w32(x->r[1], (uint32_t)(x->r[0] < 8 ? v[x->r[0]] : 0)); RET(0);
}
HLE(sceAppUtilAppParamGetInt) { w32(x->r[1], 1); RET(0); }
STUB0(sceAppUtilDrmOpen)
STUB0(sceAppUtilDrmClose)
STUB0(sceKernelGetGPI)
STUB0(sceKernelSetGPO)
STUB0(sceCoredumpRegisterCoredumpHandler)
STUB0(sceCoredumpWriteUserData)
STUB0(scePowerSetConfigurationMode)
STUB0(sceScreenShotSetParam)
STUB0(sceScreenShotSetOverlayImage)
STUB0(sceCommonDialogUpdate)
STUB0(sceMsgDialogInit) STUB0(sceMsgDialogTerm) STUB0(sceMsgDialogAbort) STUB0(sceMsgDialogClose) STUB0(sceMsgDialogGetStatus)
STUB0(sceSaveDataDialogInit) STUB0(sceSaveDataDialogTerm) STUB0(sceSaveDataDialogGetStatus)
STUB0(sceNetCheckDialogInit) STUB0(sceNetCheckDialogTerm) STUB0(sceNetCheckDialogAbort) STUB0(sceNetCheckDialogGetStatus)
STUB0(sceNpTrophySetupDialogInit) STUB0(sceNpTrophySetupDialogTerm) STUB0(sceNpTrophySetupDialogGetStatus)
STUB0(sceImeOpen) STUB0(sceImeUpdate) STUB0(sceImeClose) STUB0(sceImeSetCaret) STUB0(sceImeSetText)

/* ------------------------------------------------------------------------------------------------ libc time */
HLE(sceKernelLibcLocaltime_r) { time_t t; memcpy(&t, VRT_G2H(x->r[0]), 4); struct tm tm; gmtime_r(&t, &tm);
    int32_t o[9] = {tm.tm_sec, tm.tm_min, tm.tm_hour, tm.tm_mday, tm.tm_mon, tm.tm_year, tm.tm_wday, tm.tm_yday, 0}; memcpy(VRT_G2H(x->r[1]), o, 36); RET(x->r[1]); }
HLE(sceKernelLibcGmtime_r) { time_t t; memcpy(&t, VRT_G2H(x->r[0]), 4); struct tm tm; gmtime_r(&t, &tm);
    int32_t o[9] = {tm.tm_sec, tm.tm_min, tm.tm_hour, tm.tm_mday, tm.tm_mon, tm.tm_year, tm.tm_wday, tm.tm_yday, 0}; memcpy(VRT_G2H(x->r[1]), o, 36); RET(x->r[1]); }
HLE(sceKernelLibcMktime) { int32_t i[9]; memcpy(i, VRT_G2H(x->r[0]), 36); struct tm tm; memset(&tm, 0, sizeof tm);
    tm.tm_sec = i[0]; tm.tm_min = i[1]; tm.tm_hour = i[2]; tm.tm_mday = i[3]; tm.tm_mon = i[4]; tm.tm_year = i[5]; RET((uint32_t)timegm(&tm)); }

/* ------------------------------------------------------------------------------------------------ RTC (ticks = microseconds since 0001-01-01 UTC) */
#define TICK_UNIX_EPOCH 62135596800ull
static uint64_t cur_tick(void) { struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts); return ((uint64_t)ts.tv_sec + TICK_UNIX_EPOCH) * 1000000ull + (uint64_t)ts.tv_nsec / 1000; }
static void tick_to_dt(uint64_t tick, uint32_t gp) {                /* SceDateTime: u16 year, month, day, hour, minute, second; u32 microsecond */
    time_t s = (time_t)(tick / 1000000ull - TICK_UNIX_EPOCH); struct tm tm; gmtime_r(&s, &tm);
    w16(gp, (uint16_t)(tm.tm_year + 1900)); w16(gp + 2, (uint16_t)(tm.tm_mon + 1)); w16(gp + 4, (uint16_t)tm.tm_mday);
    w16(gp + 6, (uint16_t)tm.tm_hour); w16(gp + 8, (uint16_t)tm.tm_min); w16(gp + 10, (uint16_t)tm.tm_sec); w32(gp + 12, (uint32_t)(tick % 1000000ull));
}
static uint64_t dt_to_tick(uint32_t gp) {
    uint16_t y, mo, d, h, mi, s; uint32_t us; uint8_t *p = VRT_G2H(gp);
    memcpy(&y, p, 2); memcpy(&mo, p + 2, 2); memcpy(&d, p + 4, 2); memcpy(&h, p + 6, 2); memcpy(&mi, p + 8, 2); memcpy(&s, p + 10, 2); memcpy(&us, p + 12, 4);
    struct tm tm; memset(&tm, 0, sizeof tm); tm.tm_year = y - 1900; tm.tm_mon = mo - 1; tm.tm_mday = d; tm.tm_hour = h; tm.tm_min = mi; tm.tm_sec = s;
    return ((uint64_t)timegm(&tm) + TICK_UNIX_EPOCH) * 1000000ull + us;
}
HLE(sceRtcGetCurrentTick) { w64(x->r[0], cur_tick()); RET(0); }
HLE(sceRtcGetCurrentNetworkTick) { w64(x->r[0], cur_tick()); RET(0); }
HLE(sceRtcGetTickResolution) { RET(1000000); }
HLE(sceRtcGetCurrentClock) { tick_to_dt(cur_tick(), x->r[0]); RET(0); }
HLE(sceRtcGetCurrentClockLocalTime) { tick_to_dt(cur_tick(), x->r[0]); RET(0); }
HLE(sceRtcConvertUtcToLocalTime) { uint64_t t; memcpy(&t, VRT_G2H(x->r[0]), 8); w64(x->r[1], t); RET(0); }
HLE(sceRtcSetTick) { uint64_t t; memcpy(&t, VRT_G2H(x->r[1]), 8); tick_to_dt(t, x->r[0]); RET(0); }
HLE(sceRtcGetTick) { w64(x->r[1], dt_to_tick(x->r[0])); RET(0); }
HLE(sceRtcSetTime64_t) { uint64_t t = (uint64_t)x->r[2] | ((uint64_t)x->r[3] << 32); tick_to_dt((t + TICK_UNIX_EPOCH) * 1000000ull, x->r[0]); RET(0); }
HLE(sceRtcGetTime64_t) { w64(x->r[1], dt_to_tick(x->r[0]) / 1000000ull - TICK_UNIX_EPOCH); RET(0); }
HLE(sceRtcTickAddYears) { uint64_t t; memcpy(&t, VRT_G2H(x->r[1]), 8); int64_t y = (int32_t)x->r[2]; w64(x->r[0], t + (uint64_t)(y * 31556952ll * 1000000ll)); RET(0); }
HLE(sceRtcFormatRFC3339LocalTime) {
    uint64_t t; memcpy(&t, VRT_G2H(x->r[1]), 8); time_t s = (time_t)(t / 1000000ull - TICK_UNIX_EPOCH); struct tm tm; gmtime_r(&s, &tm);
    char *o = VRT_G2H(x->r[0]); snprintf(o, 40, "%04d-%02d-%02dT%02d:%02d:%02d+00:00", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec); RET(0);
}
HLE(sceRtcGetAccumulativeTime) { static uint64_t t0; if (!t0) t0 = now_us(); ret64(x, now_us() - t0); }

/* ------------------------------------------------------------------------------------------------ audio out (paced, silent) */
static struct { int used; uint32_t len, freq; } aports[16];
HLE(sceAudioOutOpenPort) {
    for (int i = 1; i < 16; i++) if (!aports[i].used) { aports[i].used = 1; aports[i].len = x->r[1]; aports[i].freq = x->r[2]; RET(i); return; }
    RET(0x80260005u);
}
HLE(sceAudioOutOutput) { int p = (int)x->r[0]; if (p > 0 && p < 16 && aports[p].used && aports[p].freq) usleep((useconds_t)((uint64_t)aports[p].len * 1000000ull / aports[p].freq)); RET(0); }
HLE(sceAudioOutReleasePort) { int p = (int)x->r[0]; if (p > 0 && p < 16) aports[p].used = 0; RET(0); }
HLE(sceAudioOutGetAdopt) { RET(1); }

/* ------------------------------------------------------------------------------------------------ NGS (audio engine) - accepts everything, produces silence */
static uint32_t ngs_handle(void) { static uint32_t n = 0x4e470000u; return ++n; }
static uint32_t dummy_def(void) { static uint32_t d; if (!d) d = vrt_alloc(256, 16); return d; }
HLE(sceNgsSystemGetRequiredMemorySize) { w32(x->r[1], 0x20000); RET(0); }
HLE(sceNgsSystemInit) { w32(x->r[3], ngs_handle()); RET(0); }
STUB0(sceNgsSystemUpdate) STUB0(sceNgsSystemLock) STUB0(sceNgsSystemUnlock) STUB0(sceNgsSystemRelease) STUB0(sceNgsSystemSetFlags)
HLE(sceNgsRackGetRequiredMemorySize) { w32(x->r[2], 0x4000); RET(0); }
HLE(sceNgsRackInit) { w32(x->r[3], ngs_handle()); RET(0); }
STUB0(sceNgsRackRelease)
HLE(sceNgsRackGetVoiceHandle) { w32(x->r[2], ngs_handle()); RET(0); }
STUB0(sceNgsVoiceInit) STUB0(sceNgsVoicePlay) STUB0(sceNgsVoicePause) STUB0(sceNgsVoiceResume) STUB0(sceNgsVoiceKill) STUB0(sceNgsVoiceKeyOff)
STUB0(sceNgsVoiceSetModuleCallback) STUB0(sceNgsVoiceBypassModule) STUB0(sceNgsVoiceUnlockParams)
HLE(sceNgsVoiceGetInfo) { if (x->r[1]) memset(VRT_G2H(x->r[1]), 0, 20); RET(0); }
HLE(sceNgsVoiceGetStateData) { if (x->r[2] && x->r[3] && x->r[3] < 0x10000) memset(VRT_G2H(x->r[2]), 0, x->r[3]); RET(0); }
HLE(sceNgsVoiceLockParams) { uint32_t buf = vrt_alloc(0x800, 16); w32(x->r[3], buf); w32(x->r[3] + 4, 0x800); RET(0); }   /* SceNgsBufferInfo {data, size} */
HLE(sceNgsPatchCreateRouting) { w32(x->r[1], ngs_handle()); RET(0); }
STUB0(sceNgsPatchRemoveRouting) STUB0(sceNgsVoicePatchSetVolume) STUB0(sceNgsVoicePatchSetVolumesMatrix)
HLE(sceNgsAT9GetSectionDetails) { if (x->r[3]) memset(VRT_G2H(x->r[3]), 0, 32); RET(0); }
#define NGS_DEF(n) HLE(n) { RET(dummy_def()); }
NGS_DEF(sceNgsVoiceDefGetSimpleVoice) NGS_DEF(sceNgsVoiceDefGetSimpleAtrac9Voice) NGS_DEF(sceNgsVoiceDefGetMasterBuss) NGS_DEF(sceNgsVoiceDefGetMixerBuss)
NGS_DEF(sceNgsVoiceDefGetCompressorBuss) NGS_DEF(sceNgsVoiceDefGetDelayBuss) NGS_DEF(sceNgsVoiceDefGetReverbBuss) NGS_DEF(sceNgsVoiceDefGetDistortionBuss)
NGS_DEF(sceNgsVoiceDefGetEqBuss)

/* display: the game's display-queue callback ends with these */
