#ifndef HLE_COMMON_H
#define HLE_COMMON_H
#include <setjmp.h>
/* sceKernelExitThread must stop the guest thread but we run guest code as nested C calls: the thread entry (and each
   module_start call) installs a jump buffer here; ExitThread longjmps to the innermost one. */
extern __thread jmp_buf *hle_exit_jb;
#endif
