/* Exercises the kernel HLE through the registry, with a fake "guest" thread function (C code registered like lifted code). */
#include "vita_link.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "nid_defs.h"

static vrt_ctx *mk(void) { vrt_ctx *x = calloc(1, sizeof *x); x->r[13] = vrt_alloc(0x10000, 0x1000) + 0x10000 - 64; return x; }
static void H(vrt_ctx *x, uint32_t nid) { vrt_fn f = vrt_lookup_hle(nid); assert(f); f(x); }
static uint32_t g_sema, g_flag, g_work, g_counter, g_out;

static void worker(vrt_ctx *x) {                    /* "guest" thread: wait for the semaphore, bump counter, set event flag */
    vrt_ctx *c = x;
    c->r[0] = g_sema; c->r[1] = 1; c->r[2] = 0; H(c, NID_sceKernelWaitSema);
    assert(c->r[0] == 0);
    c->r[0] = g_work; c->r[1] = 1; c->r[2] = 0; H(c, NID_sceKernelLockLwMutex);
    g_counter += 1;
    c->r[0] = g_work; c->r[1] = 1; H(c, NID_sceKernelUnlockLwMutex);
    c->r[0] = g_flag; c->r[1] = 0x4; H(c, NID_sceKernelSetEventFlag);
    c->r[0] = 77;                                    /* exit status */
}

static void exiter(vrt_ctx *x) {                   /* guest code that ends its thread with sceKernelExitThread(42) from a nested call */
    x->r[0] = 42; vrt_lookup_hle(NID_sceKernelExitThread)(x);
    x->r[0] = 99;                                    /* must never run */
}

int main(void) {
    assert(vrt_init(0) == 0);
    vrt_register(0x90000001u, worker);
    vrt_ctx *x = mk();
    uint32_t name = vrt_alloc(64, 16); strcpy(VRT_G2H(name), "t0");
    g_work = vrt_alloc(64, 16); g_out = vrt_alloc(64, 16);
    /* semaphore + event flag + lwmutex */
    x->r[0] = name; x->r[1] = 0; x->r[2] = 0; x->r[3] = 8; H(x, NID_sceKernelCreateSema); g_sema = x->r[0]; assert(g_sema);
    x->r[0] = name; x->r[1] = 0; x->r[2] = 0; H(x, NID_sceKernelCreateEventFlag); g_flag = x->r[0]; assert(g_flag);
    x->r[0] = g_work; x->r[1] = name; x->r[2] = 2; x->r[3] = 0; H(x, NID_sceKernelCreateLwMutex); assert(x->r[0] == 0);
    /* thread: create, start (blocks on the sema), then signal it and wait for the event flag */
    x->r[0] = name; x->r[1] = 0x90000001u; x->r[2] = 0x40; x->r[3] = 0x10000; x->r[4] = 0; H(x, NID_sceKernelCreateThread); uint32_t th = x->r[0]; assert(th);
    x->r[0] = th; x->r[1] = 0; x->r[2] = 0; H(x, NID_sceKernelStartThread); assert(x->r[0] == 0);
    usleep(50000); assert(g_counter == 0);           /* still blocked */
    x->r[0] = g_sema; x->r[1] = 1; H(x, NID_sceKernelSignalSema); assert(x->r[0] == 0);
    uint32_t resp = g_out; memset(VRT_G2H(x->r[13]), 0, 4);        /* timeout (5th arg on stack) = NULL */
    x->r[0] = g_flag; x->r[1] = 0x4; x->r[2] = 0x1 | 0x20; x->r[3] = resp; H(x, NID_sceKernelWaitEventFlag); assert(x->r[0] == 0);
    uint32_t pat; memcpy(&pat, VRT_G2H(resp), 4); assert(pat & 4);
    x->r[0] = th; x->r[1] = g_out + 8; x->r[2] = 0; H(x, NID_sceKernelWaitThreadEnd); assert(x->r[0] == 77);
    assert(g_counter == 1);
    /* semaphore timeout */
    uint32_t tmo = g_out + 16; uint32_t us = 20000; memcpy(VRT_G2H(tmo), &us, 4);
    x->r[0] = g_sema; x->r[1] = 1; x->r[2] = tmo; H(x, NID_sceKernelWaitSema); assert(x->r[0] == 0x80028005u);
    /* TLS: stable per thread, 4 bytes per key */
    x->r[0] = 3; H(x, NID_sceKernelGetTLSAddr); uint32_t a3 = x->r[0]; x->r[0] = 4; H(x, NID_sceKernelGetTLSAddr); assert(x->r[0] == a3 + 4);
    /* memory blocks */
    x->r[0] = name; x->r[1] = 0; x->r[2] = 5000; x->r[3] = 0; H(x, NID_sceKernelAllocMemBlock); uint32_t mb = x->r[0]; assert(mb);
    x->r[0] = mb; x->r[1] = g_out; H(x, NID_sceKernelGetMemBlockBase); uint32_t base; memcpy(&base, VRT_G2H(g_out), 4); assert(base);
    x->r[0] = base + 100; H(x, NID_sceKernelFindMemBlockByAddr); assert(x->r[0] == mb);
    /* sceClibSnprintf with ints, a string, a 64-bit int (even register pair rule) and a double */
    uint32_t fmt = vrt_alloc(128, 16), s = vrt_alloc(32, 16), buf = vrt_alloc(256, 16);
    strcpy(VRT_G2H(fmt), "%d|%s|%5.2f|%llx|%04x"); strcpy(VRT_G2H(s), "hi");
    double d = 3.14159; uint64_t db; memcpy(&db, &d, 8);
    uint32_t *sp = VRT_G2H(x->r[13]);                /* varargs: r3=%d(42); %s -> stack0; double aligned -> stack8,12; ll -> stack16,20; %04x -> stack24 */
    x->r[0] = buf; x->r[1] = 256; x->r[2] = fmt; x->r[3] = 42;
    sp[0] = s; sp[1] = 0; sp[2] = (uint32_t)db; sp[3] = (uint32_t)(db >> 32); sp[4] = 0xdeadbeefu; sp[5] = 0x1u; sp[6] = 0xabc;
    H(x, NID_sceClibSnprintf);
    assert(!strcmp(VRT_G2H(buf), "42|hi| 3.14|1deadbeef|0abc"));
    /* file I/O + path mapping */
    system("mkdir -p /tmp/vrt_app0 && echo -n 'hello' > /tmp/vrt_app0/a.txt");
    setenv("VRT_APP0", "/tmp/vrt_app0", 1); setenv("VRT_PATCH0", "/tmp/vrt_nonexistent", 1);
    uint32_t path = vrt_alloc(64, 16); strcpy(VRT_G2H(path), "app0:/a.txt");
    x->r[0] = path; x->r[1] = 1; x->r[2] = 0; H(x, NID_sceIoOpen); uint32_t fd = x->r[0]; assert(fd < 0x80000000u);
    x->r[0] = fd; x->r[1] = g_out; x->r[2] = 16; H(x, NID_sceIoRead); assert(x->r[0] == 5 && !memcmp(VRT_G2H(g_out), "hello", 5));
    x->r[0] = fd; H(x, NID_sceIoClose); assert(x->r[0] == 0);
    strcpy(VRT_G2H(path), "app0:/missing"); x->r[0] = path; x->r[1] = 1; H(x, NID_sceIoOpen); assert(x->r[0] == 0x80010002u);
    /* ExitThread unwinds to the thread entry and reports its status */
    vrt_register(0x90000011u, exiter);
    x->r[0] = name; x->r[1] = 0x90000011u; x->r[2] = 0x40; x->r[3] = 0x10000; x->r[4] = 0; H(x, NID_sceKernelCreateThread); uint32_t th2 = x->r[0];
    x->r[0] = th2; x->r[1] = 0; x->r[2] = 0; H(x, NID_sceKernelStartThread);
    x->r[0] = th2; x->r[1] = g_out + 8; x->r[2] = 0; H(x, NID_sceKernelWaitThreadEnd); assert(x->r[0] == 42);
    puts("kernel HLE ok");
    return 0;
}
