/* Crash-safe runner used by converter/difftest.py (loaded via ctypes). */
#include "vita_rt.h"
#include <setjmp.h>
#include <signal.h>
#include <string.h>
static sigjmp_buf jb;
static void on_sig(int s) { (void)s; siglongjmp(jb, 1); }
int vrt_harness_run(void (*fn)(vrt_ctx *), vrt_ctx *c) {
    struct sigaction sa; memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_sig; sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, NULL); sigaction(SIGBUS, &sa, NULL); sigaction(SIGABRT, &sa, NULL);
    if (sigsetjmp(jb, 1)) return -1;
    fn(c);
    return 0;
}
