#include "vita_link.h"
#include "nid_defs.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static vrt_ctx *mk(void) { vrt_ctx *x = calloc(1, sizeof *x); x->r[13] = vrt_alloc(0x10000, 0x1000) + 0x10000 - 64; return x; }
static void H(vrt_ctx *x, uint32_t nid) { vrt_fn f = vrt_lookup_hle(nid); assert(f); f(x); }
int main(void) {
    assert(vrt_init(0) == 0); vrt_ctx *x = mk(); uint32_t buf = vrt_alloc(0x1000, 16);
    /* controls */
    vrt_input_set_buttons(VRT_CROSS | VRT_START); vrt_input_set_sticks(10, 20, 30, 40);
    x->r[0] = 0; x->r[1] = buf; x->r[2] = 1; H(x, NID_sceCtrlReadBufferPositive2); assert(x->r[0] == 1);
    uint32_t b; memcpy(&b, (char *)VRT_G2H(buf) + 8, 4); uint8_t *s = (uint8_t *)VRT_G2H(buf) + 12; assert(b == (VRT_CROSS | VRT_START) && s[0] == 10 && s[3] == 40);
    /* touch: a finger at (100,200) in 960x544 space -> (200,400) in panel space */
    vrt_input_touch(0, 3, 1, 100, 200);
    x->r[0] = 0; x->r[1] = buf; x->r[2] = 1; H(x, NID_sceTouchPeek);
    uint32_t n; int16_t tx, ty; memcpy(&n, (char *)VRT_G2H(buf) + 12, 4); memcpy(&tx, (char *)VRT_G2H(buf) + 16 + 2, 2); memcpy(&ty, (char *)VRT_G2H(buf) + 16 + 4, 2);
    assert(n == 1 && tx == 200 && ty == 400);
    x->r[0] = 0; x->r[1] = buf; H(x, NID_sceTouchGetPanelInfo); uint16_t pi[10]; memcpy(pi, VRT_G2H(buf), 20); assert(pi[2] == 1919 && pi[3] == 1087);
    /* RTC */
    x->r[0] = buf; H(x, NID_sceRtcGetCurrentTick); uint64_t tk; memcpy(&tk, VRT_G2H(buf), 8); assert(tk > 63000000000ull * 1000000ull);
    x->r[0] = buf + 32; x->r[1] = buf; H(x, NID_sceRtcSetTick); uint16_t yr; memcpy(&yr, (char *)VRT_G2H(buf) + 32, 2); assert(yr >= 2024);
    x->r[0] = buf + 32; x->r[1] = buf + 64; H(x, NID_sceRtcGetTick); uint64_t back; memcpy(&back, (char *)VRT_G2H(buf) + 64, 8); assert(back / 1000000 == tk / 1000000);
    x->r[0] = buf + 100; x->r[2] = 86400; x->r[3] = 0; H(x, NID_sceRtcSetTime64_t); memcpy(&yr, (char *)VRT_G2H(buf) + 100, 2); assert(yr == 1970);   /* unix day 1 */
    /* AppUtil / NGS out-parameters */
    x->r[0] = 4; x->r[1] = buf; H(x, NID_sceAppUtilSystemParamGetInt); uint32_t v; memcpy(&v, VRT_G2H(buf), 4); assert(v == 1);
    x->r[0] = 0; x->r[1] = buf; H(x, NID_sceNgsSystemGetRequiredMemorySize); memcpy(&v, VRT_G2H(buf), 4); assert(v >= 0x1000);
    x->r[3] = buf + 8; H(x, NID_sceNgsSystemInit); memcpy(&v, (char *)VRT_G2H(buf) + 8, 4); assert((v >> 16) == 0x4e47);
    x->r[3] = buf + 16; H(x, NID_sceNgsVoiceLockParams); uint32_t pb[2]; memcpy(pb, (char *)VRT_G2H(buf) + 16, 8); assert(pb[0] && pb[1] == 0x800); memset(VRT_G2H(pb[0]), 1, 0x800);
    H(x, NID_sceNgsVoiceDefGetMasterBuss); assert(x->r[0] != 0);
    /* audio pacing */
    x->r[0] = 0; x->r[1] = 256; x->r[2] = 48000; x->r[3] = 1; H(x, NID_sceAudioOutOpenPort); uint32_t port = x->r[0]; assert(port > 0 && port < 0x80000000u);
    x->r[0] = port; x->r[1] = buf; H(x, NID_sceAudioOutOutput); assert(x->r[0] == 0);
    puts("system HLE ok"); return 0;
}
