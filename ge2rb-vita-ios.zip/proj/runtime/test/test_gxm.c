#include "vita_link.h"
#include "nid_defs.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static vrt_ctx *mk(void) { vrt_ctx *x = calloc(1, sizeof *x); x->r[13] = vrt_alloc(0x10000, 0x1000) + 0x10000 - 64; return x; }
static void H(vrt_ctx *x, uint32_t nid) { vrt_fn f = vrt_lookup_hle(nid); assert(f); f(x); }
static int g_cb_calls; static uint32_t g_last_data;
static void display_cb(vrt_ctx *x) { g_cb_calls++; memcpy(&g_last_data, VRT_G2H(x->r[0]), 4); }
int main(void) {
    assert(vrt_init(0) == 0); vrt_ctx *x = mk(); uint32_t buf = vrt_alloc(0x1000, 16);
    vrt_register(0x90001001u, display_cb);
    uint32_t p[5] = {0, 2, 0x90001001u, 8, 0}; memcpy(VRT_G2H(buf), p, 20);
    x->r[0] = buf; H(x, NID_sceGxmInitialize); assert(x->r[0] == 0);
    x->r[0] = buf + 64; x->r[1] = buf + 128; H(x, NID_sceGxmCreateContext); uint32_t ctx; memcpy(&ctx, (char *)VRT_G2H(buf) + 128, 4); assert(ctx);
    x->r[1] = buf + 132; H(x, NID_sceGxmReserveVertexDefaultUniformBuffer); uint32_t ub; memcpy(&ub, (char *)VRT_G2H(buf) + 132, 4); assert(ub); memset(VRT_G2H(ub), 7, 0x10000);
    x->r[0] = buf + 136; H(x, NID_sceGxmSyncObjectCreate); uint32_t so; memcpy(&so, (char *)VRT_G2H(buf) + 136, 4); assert(so);
    /* shader patcher: vertex program out-pointer is the 7th argument (stack) */
    uint32_t *sp = VRT_G2H(x->r[13]); sp[0] = 0; sp[1] = 0; sp[2] = buf + 140;
    x->r[0] = 1; x->r[1] = 2; x->r[2] = 3; x->r[3] = 1; H(x, NID_sceGxmShaderPatcherCreateVertexProgram); uint32_t vp; memcpy(&vp, (char *)VRT_G2H(buf) + 140, 4); assert(vp);
    /* texture + color surface round trip through the getters */
    uint32_t tex = buf + 256; sp[0] = 64; x->r[0] = tex; x->r[1] = 0x91000000u; x->r[2] = 0x1234; x->r[3] = 128; H(x, NID_sceGxmTextureInitLinear);
    x->r[0] = tex; H(x, NID_sceGxmTextureGetWidth); assert(x->r[0] == 128); x->r[0] = tex; H(x, NID_sceGxmTextureGetHeight); assert(x->r[0] == 64);
    x->r[0] = tex; H(x, NID_sceGxmTextureGetData); assert(x->r[0] == 0x91000000u);
    /* display queue: 5 entries are paced by vsync, the callback sees each entry's data, Finish waits for all */
    for (uint32_t i = 0; i < 5; i++) { memcpy(VRT_G2H(buf + 512), &(uint32_t){0x100 + i}, 4); x->r[0] = 0; x->r[1] = 0; x->r[2] = buf + 512; H(x, NID_sceGxmDisplayQueueAddEntry); }
    H(x, NID_sceGxmDisplayQueueFinish);
    assert(g_cb_calls == 5 && g_last_data == 0x104);
    puts("gxm HLE ok"); return 0;
}
