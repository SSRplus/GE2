/* sceKernelGetModuleInfoByAddr against the REAL eboot.bin. usage: test_modinfo PATH/TO/eboot.bin */
#include "vita_link.h"
#include "nid_defs.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char **argv) {
    assert(vrt_init(0) == 0);
    vrt_module m; assert(vrt_load_self(argv[1], &m) == 0);
    vrt_link_add_module(&m, "eboot.bin");
    vrt_ctx *x = calloc(1, sizeof *x);
    uint32_t info = vrt_alloc(0x200, 16);
    x->r[0] = m.base[1] + 0x100; x->r[1] = info;                      /* an address inside the data segment */
    vrt_lookup_hle(NID_sceKernelGetModuleInfoByAddr)(x);
    assert(x->r[0] == 0);
    uint8_t *d = VRT_G2H(info); uint32_t sz, tinit, tfile, tarea, s0b, s0m, s1b; memcpy(&sz, d, 4);
    memcpy(&tinit, d + 0x48, 4); memcpy(&tfile, d + 0x4c, 4); memcpy(&tarea, d + 0x50, 4);
    memcpy(&s0b, d + 0x154 + 8, 4); memcpy(&s0m, d + 0x154 + 12, 4); memcpy(&s1b, d + 0x154 + 0x18 + 8, 4);
    printf("size=0x%x name=%s path=%s tlsInit=0x%x tlsInitSize=0x%x tlsAreaSize=0x%x seg0=0x%x(+0x%x) seg1=0x%x\n", sz, d + 0x10, d + 0x54, tinit, tfile, tarea, s0b, s0m, s1b);
    assert(sz == 0x1B8 && !strcmp((char *)d + 0x10, "main") && s0b == m.base[0] && s1b == m.base[1] && tfile <= tarea && tinit >= m.base[0] && tinit < m.base[0] + m.memsz[0]);
    x->r[0] = 0x12345678; vrt_lookup_hle(NID_sceKernelGetModuleInfoByAddr)(x); assert(x->r[0] == 0x8002d002u);   /* unknown address */
    puts("module info ok"); return 0;
}
