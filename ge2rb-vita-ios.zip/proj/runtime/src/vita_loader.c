#include "vita_loader.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PT_LOAD      1u
#define PT_SCE_RELA  0x60000000u

static uint64_t rd64(const uint8_t *p) { uint64_t v; memcpy(&v, p, 8); return v; }
static uint32_t rd32(const uint8_t *p) { uint32_t v; memcpy(&v, p, 4); return v; }
static uint16_t rd16(const uint8_t *p) { uint16_t v; memcpy(&v, p, 2); return v; }

static void patch_imm16(uint8_t *p, uint32_t imm) {      /* Thumb-2 MOVW/MOVT immediate */
    uint16_t hw1 = rd16(p), hw2 = rd16(p + 2);
    hw1 = (uint16_t)((hw1 & 0xFBF0u) | ((imm >> 12) & 0xfu) | (((imm >> 11) & 1u) << 10));
    hw2 = (uint16_t)((hw2 & 0x8F00u) | (((imm >> 8) & 7u) << 12) | (imm & 0xffu));
    memcpy(p, &hw1, 2); memcpy(p + 2, &hw2, 2);
}

static int apply_one(vrt_module *m, int code, int datseg, uint32_t off, uint32_t value) {
    if (datseg < 0 || datseg >= m->nseg || off + 4 > m->memsz[datseg]) return -1;
    uint8_t *p = (uint8_t *)VRT_G2H(m->base[datseg] + off);
    switch (code) {
    case 2:  memcpy(p, &value, 4); break;                          /* R_ARM_ABS32 */
    case 47: patch_imm16(p, value & 0xffffu); break;               /* R_ARM_THM_MOVW_ABS_NC */
    case 48: patch_imm16(p, (value >> 16) & 0xffffu); break;       /* R_ARM_THM_MOVT_ABS */
    default: return -2;
    }
    m->relocs_applied++;
    return 0;
}

int vrt_load_self(const char *path, vrt_module *m) {
    memset(m, 0, sizeof *m);
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "vrt_load_self: cannot open %s\n", path); return -1; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *buf = malloc((size_t)n);
    if (!buf || fread(buf, 1, (size_t)n, f) != (size_t)n) { fclose(f); free(buf); return -1; }
    fclose(f);
    if (n < 0x100 || memcmp(buf, "SCE\0", 4)) { fprintf(stderr, "%s: not a SELF\n", path); free(buf); return -2; }

    uint64_t elfoff = rd64(buf + 0x40), phoff = rd64(buf + 0x48), secinfo = rd64(buf + 0x58);
    uint32_t e_entry = rd32(buf + elfoff + 0x18);
    int phnum = rd16(buf + elfoff + 0x2c);
    m->entry_seg = e_entry >> 30; m->entry_off = e_entry & 0x3fffffffu;

    /* pass 1: map the LOAD segments */
    for (int i = 0; i < phnum; i++) {
        const uint8_t *ph = buf + phoff + (size_t)i * 0x20;
        uint32_t type = rd32(ph), vaddr = rd32(ph + 8), filesz = rd32(ph + 16), memsz = rd32(ph + 20);
        if (type != PT_LOAD) continue;
        if (i >= VRT_MAX_SEG) { fprintf(stderr, "%s: too many segments\n", path); free(buf); return -3; }
        const uint8_t *si = buf + secinfo + (size_t)i * 0x20;
        uint64_t soff = rd64(si), slen = rd64(si + 8), comp = rd64(si + 16), enc = rd64(si + 24);
        if (comp != 1 || enc != 2) { fprintf(stderr, "%s: segment %d is compressed/encrypted (comp=%llu enc=%llu)\n", path, i, (unsigned long long)comp, (unsigned long long)enc); free(buf); return -4; }
        uint32_t alloc = (memsz + 0x3fffu) & ~0x3fffu;
        uint32_t base = vrt_alloc(alloc ? alloc : 0x4000, 0x4000);
        memcpy(VRT_G2H(base), buf + soff, filesz < slen ? filesz : (size_t)slen);   /* bss stays zero (fresh pages) */
        m->base[i] = base; m->memsz[i] = memsz; m->link[i] = vaddr;
        if (i + 1 > m->nseg) m->nseg = i + 1;
    }

    /* pass 2: relocations */
    for (int i = 0; i < phnum; i++) {
        const uint8_t *ph = buf + phoff + (size_t)i * 0x20;
        if (rd32(ph) != PT_SCE_RELA) continue;
        const uint8_t *si = buf + secinfo + (size_t)i * 0x20;
        const uint8_t *p = buf + rd64(si), *end = p + rd32(ph + 16);
        while (p < end) {
            uint32_t w0 = rd32(p);
            uint32_t sym = (w0 >> 4) & 0xf, code = (w0 >> 8) & 0xff, datseg = (w0 >> 16) & 0xf;
            uint32_t addend, off, code2 = 0, dist2 = 0;
            if ((w0 & 0xf) == 0) {                       /* long, 12 bytes */
                code2 = (w0 >> 20) & 0xff; dist2 = (w0 >> 28) & 0xf;
                addend = rd32(p + 4); off = rd32(p + 8); p += 12;
            } else {                                     /* short, 8 bytes */
                uint32_t w1 = rd32(p + 4);
                off = (w0 >> 20) | ((w1 & 0x3ffu) << 12); addend = w1 >> 10; p += 8;
            }
            uint32_t sv = (sym == 15 ? 0u : m->base[sym]) + addend;
            if (apply_one(m, (int)code, (int)datseg, off, sv) ||
                (code2 && apply_one(m, (int)code2, (int)datseg, off + dist2 * 2, sv))) {
                fprintf(stderr, "%s: bad relocation (code %u/%u datseg %u off 0x%x)\n", path, code, code2, datseg, off);
                free(buf); return -5;
            }
        }
    }
    free(buf);
    return 0;
}
