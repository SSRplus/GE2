#include "vita_rt.h"
#include <stdatomic.h>
#include <pthread.h>
#include <string.h>

static _Atomic uint32_t g_buttons;
static _Atomic uint32_t g_sticks = 0x80808080u;     /* lx | ly<<8 | rx<<16 | ry<<24 */

typedef struct { int used; int id; uint16_t x, y; } tpoint;
static tpoint g_touch[2][VRT_MAX_TOUCH];
static pthread_mutex_t g_tlock = PTHREAD_MUTEX_INITIALIZER;

void vrt_input_set_buttons(uint32_t m) { atomic_store(&g_buttons, m); }
uint32_t vrt_input_get_buttons(void) { return atomic_load(&g_buttons); }
void vrt_input_set_sticks(uint8_t lx, uint8_t ly, uint8_t rx, uint8_t ry) {
    atomic_store(&g_sticks, (uint32_t)lx | (uint32_t)ly << 8 | (uint32_t)rx << 16 | (uint32_t)ry << 24);
}
void vrt_input_get_sticks(uint8_t out[4]) {
    uint32_t v = atomic_load(&g_sticks);
    out[0] = v & 0xff; out[1] = (v >> 8) & 0xff; out[2] = (v >> 16) & 0xff; out[3] = v >> 24;
}

void vrt_input_touch(int port, int id, int down, uint16_t x, uint16_t y) {
    if (port < 0 || port > 1) return;
    pthread_mutex_lock(&g_tlock);
    tpoint *t = g_touch[port], *slot = NULL;
    for (int i = 0; i < VRT_MAX_TOUCH; i++) if (t[i].used && t[i].id == id) { slot = &t[i]; break; }
    if (!down) { if (slot) slot->used = 0; }
    else {
        if (!slot) for (int i = 0; i < VRT_MAX_TOUCH; i++) if (!t[i].used) { slot = &t[i]; break; }
        if (slot) { slot->used = 1; slot->id = id; slot->x = x; slot->y = y; }
    }
    pthread_mutex_unlock(&g_tlock);
}

int vrt_input_get_touches(int port, uint8_t *ids, uint16_t *xs, uint16_t *ys, int max) {
    if (port < 0 || port > 1) return 0;
    int n = 0;
    pthread_mutex_lock(&g_tlock);
    for (int i = 0; i < VRT_MAX_TOUCH && n < max; i++)
        if (g_touch[port][i].used) { ids[n] = (uint8_t)g_touch[port][i].id; xs[n] = g_touch[port][i].x; ys[n] = g_touch[port][i].y; n++; }
    pthread_mutex_unlock(&g_tlock);
    return n;
}
