#include "vita_link.h"
#include <stdlib.h>
#include <string.h>

typedef struct { uint32_t nid; const char *name; } vrt_nid_name_rec;
/* Weak FUNCTION (data symbols were folded to their default by the compiler). converter/gen_nid_names.py generates the strong one. */
__attribute__((weak)) const vrt_nid_name_rec *vrt_nid_names_get(int *n) { *n = 0; return 0; }
static const char *nid_name(uint32_t nid) {
    int n; const vrt_nid_name_rec *t = vrt_nid_names_get(&n);
    for (int i = 0; i < n; i++) if (t[i].nid == nid) return t[i].name;
    return "?";
}

typedef struct { uint32_t lib_nid, nid, addr; uint8_t is_var; int mod; } export_rec;
typedef struct { char lib[40]; uint32_t lib_nid, nid, stub; uint8_t is_var; int mod; } import_rec;
typedef struct { char name[64]; vrt_module m; } mod_rec;

static export_rec *g_exp; static size_t g_nexp, g_capexp;
static import_rec *g_imp; static size_t g_nimp, g_capimp;
static mod_rec *g_mod; static size_t g_nmod, g_capmod;
static int *g_ehash; static size_t g_ehcap;               /* open-addressing index into g_exp */

static uint32_t rd32g(uint32_t a) { uint32_t v; memcpy(&v, VRT_G2H(a), 4); return v; }
static uint16_t rd16g(uint32_t a) { uint16_t v; memcpy(&v, VRT_G2H(a), 2); return v; }
static size_t hkey(uint32_t l, uint32_t n) { return ((size_t)l * 2654435761u) ^ ((size_t)n * 40503u * 65599u); }

static void ehash_rebuild(void) {
    size_t cap = 1024; while (cap < g_nexp * 2 + 16) cap <<= 1;
    free(g_ehash); g_ehash = malloc(cap * sizeof(int)); g_ehcap = cap;
    for (size_t i = 0; i < cap; i++) g_ehash[i] = -1;
    for (size_t i = 0; i < g_nexp; i++) {
        size_t h = hkey(g_exp[i].lib_nid, g_exp[i].nid) & (cap - 1);
        while (g_ehash[h] >= 0) h = (h + 1) & (cap - 1);
        g_ehash[h] = (int)i;
    }
}
static export_rec *find_export(uint32_t lib_nid, uint32_t nid, uint8_t is_var) {
    if (!g_ehcap) return NULL;
    size_t h = hkey(lib_nid, nid) & (g_ehcap - 1);
    while (g_ehash[h] >= 0) {
        export_rec *e = &g_exp[g_ehash[h]];
        if (e->lib_nid == lib_nid && e->nid == nid && e->is_var == is_var) return e;
        h = (h + 1) & (g_ehcap - 1);
    }
    return NULL;
}
#define PUSH(arr, n, cap, T) do { if ((n) == (cap)) { (cap) = (cap) ? (cap) * 2 : 4096; (arr) = realloc((arr), (cap) * sizeof(T)); } } while (0)

int vrt_link_add_module(const vrt_module *m, const char *name) {
    PUSH(g_mod, g_nmod, g_capmod, mod_rec);
    int idx = (int)g_nmod++;
    g_mod[idx].m = *m; snprintf(g_mod[idx].name, sizeof g_mod[idx].name, "%s", name);
    uint32_t base = m->base[m->entry_seg], mi = base + m->entry_off;
    uint32_t ent_top = base + rd32g(mi + 0x24), ent_end = base + rd32g(mi + 0x28);
    uint32_t stub_top = base + rd32g(mi + 0x2c), stub_end = base + rd32g(mi + 0x30);

    for (uint32_t p = ent_top; p < ent_end;) {                       /* exports */
        uint16_t size = rd16g(p);
        if (size < 0x20) break;
        uint32_t nf = rd16g(p + 6), nv = rd32g(p + 8), lib_nid = rd32g(p + 16), nidtab = rd32g(p + 24), enttab = rd32g(p + 28);
        for (uint32_t i = 0; i < nf + nv; i++) {
            PUSH(g_exp, g_nexp, g_capexp, export_rec);
            export_rec *e = &g_exp[g_nexp++];
            e->lib_nid = lib_nid; e->nid = rd32g(nidtab + 4 * i); e->addr = rd32g(enttab + 4 * i); e->is_var = i >= nf; e->mod = idx;
        }
        p += size;
    }
    for (uint32_t p = stub_top; p < stub_end;) {                     /* imports */
        uint16_t size = rd16g(p);
        if (size != 0x24 && size != 0x34) break;
        uint32_t nf = rd16g(p + 6), nv = rd16g(p + 8), lib_nid, nameptr, fnid, fent, vnid, vent;
        if (size == 0x34) { lib_nid = rd32g(p + 0x10); nameptr = rd32g(p + 0x14); fnid = rd32g(p + 0x1c); fent = rd32g(p + 0x20); vnid = rd32g(p + 0x24); vent = rd32g(p + 0x28); }
        else              { lib_nid = rd32g(p + 0x0c); nameptr = rd32g(p + 0x10); fnid = rd32g(p + 0x14); fent = rd32g(p + 0x18); vnid = rd32g(p + 0x1c); vent = rd32g(p + 0x20); }
        for (uint32_t k = 0; k < nf + nv; k++) {
            PUSH(g_imp, g_nimp, g_capimp, import_rec);
            import_rec *r = &g_imp[g_nimp++];
            memset(r, 0, sizeof *r);
            if (nameptr) { strncpy(r->lib, (const char *)VRT_G2H(nameptr), sizeof r->lib - 1); }
            r->lib_nid = lib_nid; r->mod = idx; r->is_var = k >= nf;
            r->nid = r->is_var ? rd32g(vnid + 4 * (k - nf)) : rd32g(fnid + 4 * k);
            r->stub = r->is_var ? rd32g(vent + 4 * (k - nf)) : rd32g(fent + 4 * k);
        }
        p += size;
    }
    return idx;
}

static void hle_unimpl_register(uint32_t stub) { vrt_register(stub, vrt_unimplemented); }

int vrt_link_resolve(vrt_link_stats *st) {
    memset(st, 0, sizeof *st);
    st->modules = (int)g_nmod;
    ehash_rebuild();
    for (size_t i = 0; i < g_nexp; i++) { if (g_exp[i].is_var) st->exports_var++; else st->exports_func++; }
    for (size_t i = 0; i < g_nimp; i++) {
        import_rec *r = &g_imp[i];
        export_rec *e = find_export(r->lib_nid, r->nid, r->is_var);
        if (!r->is_var) {
            if (e) { vrt_redirect(r->stub, e->addr); st->game_func++; }
            else if (vrt_lookup_hle(r->nid)) { vrt_register(r->stub, vrt_lookup_hle(r->nid)); st->hle_func_bound++; }
            else { hle_unimpl_register(r->stub); st->hle_func_missing++; }
        } else {
            uint32_t target;
            if (e) { target = e->addr; st->game_var++; }
            else {                                           /* system variable: private zeroed cell (stack guard gets a constant) */
                target = vrt_alloc(16, 16);
                if (r->nid == 0x93b8aa67u) { uint32_t g = 0x3c8a9f21u; memcpy(VRT_G2H(target), &g, 4); }
                st->hle_var++;
            }
            memcpy(VRT_G2H(r->stub), &target, 4);            /* slot receives the variable's address */
        }
    }
    return 0;
}

const char *vrt_stub_describe(uint32_t stub) {
    static char buf[256];
    for (size_t i = 0; i < g_nimp; i++)
        if (!g_imp[i].is_var && g_imp[i].stub == stub) {
            snprintf(buf, sizeof buf, "%s::%s 0x%08x (imported by %s)", g_imp[i].lib, nid_name(g_imp[i].nid), g_imp[i].nid, g_mod[g_imp[i].mod].name);
            return buf;
        }
    return NULL;
}

void vrt_link_report_missing(FILE *out) {
    for (size_t i = 0; i < g_nimp; i++) {
        import_rec *r = &g_imp[i];
        if (!r->is_var && !find_export(r->lib_nid, r->nid, 0) && !vrt_lookup_hle(r->nid))
            fprintf(out, "UNIMPL %s 0x%08X %s\n", r->lib, r->nid, nid_name(r->nid));
    }
}

int vrt_lenient = 0;                  /* trace mode: log each unimplemented system call once, return 0 and keep going */
void vrt_unimplemented(vrt_ctx *x) {
    const char *d = vrt_stub_describe(x->last_call);
    if (vrt_lenient) {
        static uint32_t seen[4096]; static int nseen;
        for (int i = 0; i < nseen; i++) if (seen[i] == x->last_call) goto quiet;
        if (nseen < 4096) seen[nseen++] = x->last_call;
        fprintf(stderr, "[hle] UNIMPLEMENTED %s  args r0=%08x r1=%08x r2=%08x r3=%08x lr=%08x\n", d ? d : "?", x->r[0], x->r[1], x->r[2], x->r[3], x->r[14]);
        { uint32_t bt[16]; int nb = vrt_backtrace(bt, 12); char nm[200];            /* where was it called from? */
          for (int i = 0; i < nb; i++) { const char *dd = vrt_describe_addr(bt[i], nm, sizeof nm); fprintf(stderr, "[bt] #%d %s\n", i, dd ? dd : "?"); } }
quiet:
        x->r[0] = 0;
        return;
    }
    vrt_fatal("unimplemented system call: %s (lr=0x%08x)", d ? d : "?", x->r[14]);
}

uint32_t vrt_link_module_export_var(int idx, uint32_t nid) { return vrt_link_module_export(idx, nid); }
/* "libc.suprx+0x1a2c4" for a guest code address, or NULL */
const char *vrt_describe_addr(uint32_t addr, char *buf, size_t n) {
    for (size_t i = 0; i < g_nmod; i++) {
        const vrt_module *m = &g_mod[i].m;
        if (m->nseg && addr >= m->base[0] && addr < m->base[0] + m->memsz[0]) {
            snprintf(buf, n, "%s+0x%x", g_mod[i].name, (addr & ~1u) - m->base[0]);
            for (size_t k = 0; k < g_nexp; k++)
                if (!g_exp[k].is_var && g_exp[k].mod == (int)i && (g_exp[k].addr & ~1u) == (addr & ~1u)) {
                    size_t l = strlen(buf); snprintf(buf + l, n - l, "  [export %s]", nid_name(g_exp[k].nid)); break;
                }
            return buf;
        }
    }
    return NULL;
}
int vrt_link_module_find_addr(uint32_t addr) {                /* index of the module owning a guest address, or -1 */
    for (size_t i = 0; i < g_nmod; i++) {
        const vrt_module *m = &g_mod[i].m;
        for (int k = 0; k < m->nseg; k++) if (addr >= m->base[k] && addr < m->base[k] + m->memsz[k]) return (int)i;
    }
    return -1;
}
uint32_t vrt_link_module_info_word(int idx, uint32_t off) {   /* word at SceModuleInfo+off (pointers there are already relocated) */
    if (idx < 0 || (size_t)idx >= g_nmod) return 0;
    const vrt_module *m = &g_mod[idx].m;
    return rd32g(m->base[m->entry_seg] + m->entry_off + off);
}
int vrt_link_module_count(void) { return (int)g_nmod; }
const char *vrt_link_module_name(int idx) { return (idx >= 0 && (size_t)idx < g_nmod) ? g_mod[idx].name : NULL; }
const vrt_module *vrt_link_module(int idx) { return (idx >= 0 && (size_t)idx < g_nmod) ? &g_mod[idx].m : NULL; }
int vrt_link_find_module(const char *path_suffix) {      /* "app0:/bin/god.self" matches "bin/god.self" */
    size_t pl = strlen(path_suffix);
    for (size_t i = 0; i < g_nmod; i++) {
        size_t nl = strlen(g_mod[i].name);
        if (pl >= nl && !strcmp(path_suffix + pl - nl, g_mod[i].name)) return (int)i;
    }
    return -1;
}
/* address of a function exported by the module's nameless "module" library (module_start 0x935CD196, module_stop 0x79F8E492) */
uint32_t vrt_link_module_export(int idx, uint32_t nid) {
    for (size_t i = 0; i < g_nexp; i++)
        if (g_exp[i].mod == idx && g_exp[i].lib_nid == 0 && g_exp[i].nid == nid) return g_exp[i].addr;
    return 0;
}
