#include "vita_rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <sys/mman.h>

uint8_t *vrt_mem;
static uint32_t bump = 0x90000000u;       /* heap region for vrt_alloc, away from module images at 0x81000000 */

typedef struct { uint32_t key; vrt_fn fn; const char *name; } slot;
typedef struct { slot *s; size_t cap, n; } table;
static table fn_tab, hle_tab;

static void grow(table *t) {
    size_t nc = t->cap ? t->cap * 2 : 1024;
    slot *ns = calloc(nc, sizeof(slot));
    for (size_t i = 0; i < t->cap; i++)
        if (t->s[i].fn) {
            size_t h = (t->s[i].key * 2654435761u) & (nc - 1);
            while (ns[h].fn) h = (h + 1) & (nc - 1);
            ns[h] = t->s[i];
        }
    free(t->s); t->s = ns; t->cap = nc;
}
static void put(table *t, uint32_t k, vrt_fn fn, const char *nm) {
    if ((t->n + 1) * 2 > t->cap) grow(t);
    size_t h = (k * 2654435761u) & (t->cap - 1);
    while (t->s[h].fn && t->s[h].key != k) h = (h + 1) & (t->cap - 1);
    if (!t->s[h].fn) t->n++;
    t->s[h] = (slot){k, fn, nm};
}
static vrt_fn get(table *t, uint32_t k) {
    if (!t->cap) return NULL;
    size_t h = (k * 2654435761u) & (t->cap - 1);
    while (t->s[h].fn) { if (t->s[h].key == k) return t->s[h].fn; h = (h + 1) & (t->cap - 1); }
    return NULL;
}

int vrt_init(size_t commit_bytes) {
    (void)commit_bytes;
    void *p = mmap(NULL, 1ull << 32, PROT_NONE, MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
    if (p == MAP_FAILED) return -1;
    vrt_mem = p;
    return 0;
}
void vrt_shutdown(void) { if (vrt_mem) munmap(vrt_mem, 1ull << 32); vrt_mem = NULL; }

int vrt_commit(uint32_t a, size_t len) {
    uintptr_t s = (uintptr_t)(vrt_mem + a) & ~(uintptr_t)0x3fff;
    uintptr_t e = ((uintptr_t)(vrt_mem + a) + len + 0x3fff) & ~(uintptr_t)0x3fff;
    return mprotect((void *)s, e - s, PROT_READ | PROT_WRITE);
}
uint32_t vrt_alloc(size_t len, size_t align) {
    if (align < 16) align = 16;
    bump = (uint32_t)((bump + align - 1) & ~(align - 1));
    uint32_t r = bump; bump += (uint32_t)len;
    if (vrt_commit(r, len)) vrt_fatal("vrt_alloc: commit failed (%zu bytes)", len);
    return r;
}

void vrt_register(uint32_t a, vrt_fn fn) { put(&fn_tab, a, fn, NULL); }
vrt_fn vrt_lookup(uint32_t a) { return get(&fn_tab, a); }
static table redir_tab;                       /* key = stub address, value (in .name) = target address */
void vrt_redirect(uint32_t from, uint32_t to) {
    if ((redir_tab.n + 1) * 2 > redir_tab.cap) grow(&redir_tab);
    size_t h = (from * 2654435761u) & (redir_tab.cap - 1);
    while (redir_tab.s[h].fn && redir_tab.s[h].key != from) h = (h + 1) & (redir_tab.cap - 1);
    if (!redir_tab.s[h].fn) redir_tab.n++;
    redir_tab.s[h] = (slot){from, (vrt_fn)(uintptr_t)1, (const char *)(uintptr_t)to};   /* fn=1 marks "used" */
}
static uint32_t redirect_of(uint32_t a) {
    if (!redir_tab.cap) return 0;
    size_t h = (a * 2654435761u) & (redir_tab.cap - 1);
    while (redir_tab.s[h].fn) { if (redir_tab.s[h].key == a) return (uint32_t)(uintptr_t)redir_tab.s[h].name; h = (h + 1) & (redir_tab.cap - 1); }
    return 0;
}
int vrt_bind_redirects(void) {
    int unbound = 0;
    for (size_t i = 0; i < redir_tab.cap; i++) {
        if (!redir_tab.s[i].fn) continue;
        vrt_fn f = get(&fn_tab, (uint32_t)(uintptr_t)redir_tab.s[i].name);
        if (f) put(&fn_tab, redir_tab.s[i].key, f, NULL);
        else { unbound++; fprintf(stderr, "[link] unbound redirect: stub 0x%08x -> target 0x%08x has no lifted function\n", redir_tab.s[i].key, (uint32_t)(uintptr_t)redir_tab.s[i].name); }
    }
    return unbound;
}
#define CS_MAX 4096
static __thread uint32_t cs_stack[CS_MAX]; static __thread int cs_n;
int vrt_cs_get(void) { return cs_n; }
void vrt_cs_set(int n) { cs_n = n; }
int vrt_backtrace(uint32_t *out, int max) { int n = cs_n < CS_MAX ? cs_n : CS_MAX; if (n > max) n = max; for (int i = 0; i < n; i++) out[i] = cs_stack[cs_n - n + i]; return n; }
#define RING 64
static __thread uint32_t ring[RING]; static __thread unsigned ring_n;
int vrt_recent_calls(uint32_t *out, int max) {
    int n = ring_n < RING ? (int)ring_n : RING; if (n > max) n = max;
    for (int i = 0; i < n; i++) out[i] = ring[(ring_n - n + i) % RING];
    return n;
}
void vrt_call(vrt_ctx *c, uint32_t a) {
    c->last_call = a;
    vrt_fn f = get(&fn_tab, a);
    if (!f) { uint32_t t = redirect_of(a); if (t) f = get(&fn_tab, t); }
    if (!f) vrt_fatal("call to unrecompiled/unlinked address 0x%08x", a);
    { uint32_t t = redirect_of(a); ring[ring_n++ % RING] = t ? t : a; }
    if (cs_n < CS_MAX) cs_stack[cs_n] = a;
    cs_n++;
    f(c);
    cs_n--;
}
void vrt_register_hle(uint32_t nid, vrt_fn fn, const char *name) { put(&hle_tab, nid, fn, name); }
vrt_fn vrt_lookup_hle(uint32_t nid) { return get(&hle_tab, nid); }

void vrt_fatal(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    fprintf(stderr, "[vrt fatal] "); vfprintf(stderr, fmt, ap); fputc('\n', stderr);
    va_end(ap); abort();
}
