#ifndef VITA_LINK_H
#define VITA_LINK_H
#include "vita_loader.h"
#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct {
    int modules, game_func, game_var, hle_func_bound, hle_func_missing, hle_var, bad;
    int exports_func, exports_var, duplicate_exports;
} vrt_link_stats;

/* Parse the (relocated) export/import tables of a loaded module and remember them. Call once per module. */
int  vrt_link_add_module(const vrt_module *m, const char *name);
/* Resolve every import: game-module exports (redirect), HLE functions by NID, variables (slot gets the variable's address). */
int  vrt_link_resolve(vrt_link_stats *st);
/* Describe an import stub address ("SceLibKernel 0x0c7b834b"), or NULL if the address is not an import stub. */
const char *vrt_stub_describe(uint32_t stub_addr);
/* Print unresolved system imports ("UNIMPL <lib> <nid>") */
void vrt_link_report_missing(FILE *out);
/* Generic handler registered for system functions that have no HLE yet: reports the import and aborts. */
void vrt_unimplemented(vrt_ctx *x);
extern int vrt_lenient;
int  vrt_link_module_count(void);
int  vrt_link_module_find_addr(uint32_t addr);
uint32_t vrt_link_module_info_word(int idx, uint32_t off);
const char *vrt_link_module_name(int idx);
const vrt_module *vrt_link_module(int idx);
int  vrt_link_find_module(const char *path_suffix);
uint32_t vrt_link_module_export(int idx, uint32_t nid);
uint32_t vrt_link_module_export_var(int idx, uint32_t nid);
const char *vrt_describe_addr(uint32_t addr, char *buf, size_t n);
#ifdef __cplusplus
}
#endif
#endif
