/* Helpers used by lifted code. Pure functions; unit-tested in runtime/test/test_ops.c */
#ifndef VITA_OPS_H
#define VITA_OPS_H
#include "vita_rt.h"
#include <string.h>

static inline uint32_t vrt_adc(uint32_t a, uint32_t b, uint32_t cin, uint8_t *c, uint8_t *v) {
    uint64_t u = (uint64_t)a + b + cin;
    int64_t  s = (int64_t)(int32_t)a + (int64_t)(int32_t)b + cin;
    uint32_t r = (uint32_t)u;
    *c = (uint8_t)((u >> 32) & 1);
    *v = (s != (int64_t)(int32_t)r);
    return r;
}
static inline uint32_t vrt_lsl(uint32_t v, uint32_t n, uint8_t *c) {
    if (n == 0) return v;
    if (n < 32) { *c = (v >> (32 - n)) & 1; return v << n; }
    if (n == 32) { *c = v & 1; return 0; }
    *c = 0; return 0;
}
static inline uint32_t vrt_lsr(uint32_t v, uint32_t n, uint8_t *c) {
    if (n == 0) return v;
    if (n < 32) { *c = (v >> (n - 1)) & 1; return v >> n; }
    if (n == 32) { *c = v >> 31; return 0; }
    *c = 0; return 0;
}
static inline uint32_t vrt_asr(uint32_t v, uint32_t n, uint8_t *c) {
    if (n == 0) return v;
    if (n < 32) { *c = (v >> (n - 1)) & 1; return (uint32_t)((int32_t)v >> n); }
    *c = v >> 31; return (uint32_t)((int32_t)v >> 31);
}
static inline uint32_t vrt_ror(uint32_t v, uint32_t n, uint8_t *c) {
    if (n == 0) return v;
    n &= 31;
    if (n == 0) { *c = v >> 31; return v; }
    *c = (v >> (n - 1)) & 1;
    return (v >> n) | (v << (32 - n));
}
static inline uint32_t vrt_ror_nc(uint32_t v, uint32_t n) { n &= 31; return n ? (v >> n) | (v << (32 - n)) : v; }
static inline uint32_t vrt_rrx(uint32_t v, uint32_t n, uint8_t *c) {   /* n unused; carry in/out via *c */
    (void)n; uint32_t r = ((uint32_t)*c << 31) | (v >> 1); *c = v & 1; return r;
}

/* guest memory access, unaligned-safe */
static inline uint32_t vrt_ld32(uint32_t a) { uint32_t v; memcpy(&v, vrt_mem + a, 4); return v; }
static inline uint32_t vrt_ld16(uint32_t a) { uint16_t v; memcpy(&v, vrt_mem + a, 2); return v; }
static inline uint32_t vrt_ld8 (uint32_t a) { return vrt_mem[a]; }
static inline void vrt_st32(uint32_t a, uint32_t v) { memcpy(vrt_mem + a, &v, 4); }
static inline void vrt_st16(uint32_t a, uint32_t v) { uint16_t t = (uint16_t)v; memcpy(vrt_mem + a, &t, 2); }
static inline void vrt_st8 (uint32_t a, uint32_t v) { vrt_mem[a] = (uint8_t)v; }
static inline uint32_t vrt_sx8 (uint32_t v) { return (uint32_t)(int32_t)(int8_t)v; }
static inline uint32_t vrt_sx16(uint32_t v) { return (uint32_t)(int32_t)(int16_t)v; }

static inline uint32_t vrt_rev(uint32_t v) { return __builtin_bswap32(v); }
static inline uint32_t vrt_rev16(uint32_t v) { return ((v & 0x00ff00ffu) << 8) | ((v >> 8) & 0x00ff00ffu); }
static inline uint32_t vrt_revsh(uint32_t v) { return vrt_sx16(__builtin_bswap16((uint16_t)v)); }
static inline uint32_t vrt_rbit(uint32_t v) { uint32_t r = 0; for (int i = 0; i < 32; i++) r |= ((v >> i) & 1u) << (31 - i); return r; }
static inline uint32_t vrt_clz(uint32_t v) { return v ? (uint32_t)__builtin_clz(v) : 32u; }

/* ---- 64-bit memory ---- */
static inline uint64_t vrt_ld64(uint32_t a) { uint64_t v; memcpy(&v, vrt_mem + a, 8); return v; }
static inline void vrt_st64(uint32_t a, uint64_t v) { memcpy(vrt_mem + a, &v, 8); }

/* ---- VFP helpers (ARM semantics: vcvt rounds toward zero, saturates, NaN -> 0) ---- */
static inline uint32_t vrt_f2s(float f)  { if (f != f) return 0; if (f >= 2147483648.0f) return 0x7fffffffu; if (f < -2147483648.0f) return 0x80000000u; return (uint32_t)(int32_t)f; }
static inline uint32_t vrt_f2u(float f)  { if (f != f) return 0; if (f >= 4294967296.0f) return 0xffffffffu; if (f <= 0.0f) return 0; return (uint32_t)f; }
static inline uint32_t vrt_d2s(double f) { if (f != f) return 0; if (f >= 2147483648.0) return 0x7fffffffu; if (f <= -2147483649.0) return 0x80000000u; return (uint32_t)(int32_t)f; }
static inline uint32_t vrt_d2u(double f) { if (f != f) return 0; if (f >= 4294967296.0) return 0xffffffffu; if (f <= 0.0) return 0; return (uint32_t)f; }
static inline void vrt_fcmp32(vrt_ctx *x, float a, float b) {
    uint32_t f = (a != a || b != b) ? 0x3u : (a == b) ? 0x6u : (a < b) ? 0x8u : 0x2u;   /* NZCV */
    x->fpscr = (x->fpscr & 0x0fffffffu) | (f << 28);
}
static inline void vrt_fcmp64(vrt_ctx *x, double a, double b) {
    uint32_t f = (a != a || b != b) ? 0x3u : (a == b) ? 0x6u : (a < b) ? 0x8u : 0x2u;
    x->fpscr = (x->fpscr & 0x0fffffffu) | (f << 28);
}

static inline uint32_t vrt_f2bits(float f) { uint32_t u; memcpy(&u, &f, 4); return u; }
static inline float vrt_bits2f(uint32_t u) { float f; memcpy(&f, &u, 4); return f; }

/* ---- NEON helpers: NEON float ops always flush denormals to zero and produce the default NaN ---- */
static inline float vrt_nf(float f) { uint32_t u; memcpy(&u, &f, 4); if (!(u & 0x7f800000u) && (u & 0x007fffffu)) { u &= 0x80000000u; memcpy(&f, &u, 4); } return f; }
static inline float vrt_nres(float f) { if (f != f) return vrt_bits2f(0x7fc00000u); return vrt_nf(f); }
static inline uint64_t vrt_vadd(uint64_t a, uint64_t b, int bits) {
    if (bits == 64) return a + b;
    uint64_t m = (1ull << bits) - 1, r = 0;
    for (int s = 0; s < 64; s += bits) r |= (((a >> s) + (b >> s)) & m) << s;
    return r;
}
static inline uint64_t vrt_vsub(uint64_t a, uint64_t b, int bits) {
    if (bits == 64) return a - b;
    uint64_t m = (1ull << bits) - 1, r = 0;
    for (int s = 0; s < 64; s += bits) r |= (((a >> s) - (b >> s)) & m) << s;
    return r;
}
static inline uint64_t vrt_vmul(uint64_t a, uint64_t b, int bits) {
    uint64_t m = (1ull << bits) - 1, r = 0;
    for (int s = 0; s < 64; s += bits) r |= ((((a >> s) & m) * ((b >> s) & m)) & m) << s;
    return r;
}
static inline uint64_t vrt_dup(uint32_t v, int bits) {
    if (bits == 32) return ((uint64_t)v << 32) | v;
    if (bits == 16) return (uint64_t)(v & 0xffffu) * 0x0001000100010001ull;
    return (uint64_t)(v & 0xffu) * 0x0101010101010101ull;
}
static inline uint64_t vrt_vceq_i(uint64_t a, uint64_t b, int bits) {
    uint64_t m = (bits == 64) ? ~0ull : ((1ull << bits) - 1), r = 0;
    for (int s = 0; s < 64; s += bits) if (((a >> s) & m) == ((b >> s) & m)) r |= m << s;
    return r;
}
static inline uint64_t vrt_vceq_f(uint64_t a, uint64_t b) {
    uint64_t r = 0;
    for (int i = 0; i < 2; i++) {
        float fa = vrt_nf(vrt_bits2f((uint32_t)(a >> (32 * i)))), fb = vrt_nf(vrt_bits2f((uint32_t)(b >> (32 * i))));
        if (fa == fb) r |= 0xffffffffull << (32 * i);
    }
    return r;
}

/* ---- NEON integer/widening/narrowing helpers: operate on 64-bit D units; Q = 2 units, wide results are 128-bit ---- */
typedef unsigned __int128 vrt_u128;
static inline uint64_t vrt_lmask(int bits) { return bits >= 64 ? ~0ull : ((1ull << bits) - 1); }
static inline int64_t vrt_ext(uint64_t v, int bits, int sgn) {                       /* extend a lane */
    v &= vrt_lmask(bits);
    if (sgn && bits < 64 && (v >> (bits - 1))) v |= ~vrt_lmask(bits);
    return (int64_t)v;
}
static inline vrt_u128 vrt_q128(uint64_t lo, uint64_t hi) { return (vrt_u128)lo | ((vrt_u128)hi << 64); }
/* D (lanes of `bits`) -> Q (lanes of 2*bits), each lane extended then shifted left by shl */
static inline vrt_u128 vrt_widen(uint64_t d, int bits, int sgn, int shl) {
    vrt_u128 r = 0; int w = 2 * bits;
    for (int i = 0; i < 64 / bits; i++) {
        uint64_t v = (uint64_t)vrt_ext(d >> (i * bits), bits, sgn) << shl;
        r |= (vrt_u128)(v & vrt_lmask(w)) << (i * w);
    }
    return r;
}
static inline vrt_u128 vrt_vmull128(uint64_t a, uint64_t b, int bits, int sgn) {
    vrt_u128 r = 0; int w = 2 * bits;
    for (int i = 0; i < 64 / bits; i++) {
        uint64_t p = (uint64_t)(vrt_ext(a >> (i * bits), bits, sgn) * vrt_ext(b >> (i * bits), bits, sgn));
        r |= (vrt_u128)(p & vrt_lmask(w)) << (i * w);
    }
    return r;
}
static inline vrt_u128 vrt_wadd(vrt_u128 a, vrt_u128 b, int w) {
    vrt_u128 r = 0;
    for (int i = 0; i < 128 / w; i++) { vrt_u128 m = (w == 64) ? (vrt_u128)~0ull : (((vrt_u128)1 << w) - 1); r |= ((((a >> (i * w)) + (b >> (i * w))) & m)) << (i * w); }
    return r;
}
static inline vrt_u128 vrt_wsub(vrt_u128 a, vrt_u128 b, int w) {
    vrt_u128 r = 0;
    for (int i = 0; i < 128 / w; i++) { vrt_u128 m = (w == 64) ? (vrt_u128)~0ull : (((vrt_u128)1 << w) - 1); r |= ((((a >> (i * w)) - (b >> (i * w))) & m)) << (i * w); }
    return r;
}
static inline uint64_t vrt_dup_el(uint64_t d, int idx, int bits) {                    /* replicate lane idx of d across a D register */
    uint64_t v = (d >> (idx * bits)) & vrt_lmask(bits), r = 0;
    for (int s = 0; s < 64; s += bits) r |= v << s;
    return r;
}
static inline uint64_t vrt_shl_imm(uint64_t m, int bits, int imm) {
    uint64_t r = 0, mk = vrt_lmask(bits);
    for (int s = 0; s < 64; s += bits) r |= ((((m >> s) & mk) << imm) & mk) << s;
    return r;
}
static inline uint64_t vrt_shr_imm(uint64_t m, int bits, int imm, int sgn) {
    uint64_t r = 0, mk = vrt_lmask(bits);
    for (int s = 0; s < 64; s += bits) { int64_t v = vrt_ext(m >> s, bits, sgn); r |= (((uint64_t)(v >> imm)) & mk) << s; }
    return r;
}
static inline uint64_t vrt_sli(uint64_t d, uint64_t m, int bits, int imm) {          /* shift left and insert */
    uint64_t r = 0, mk = vrt_lmask(bits), keep = (imm ? vrt_lmask(imm) : 0);
    for (int s = 0; s < 64; s += bits) r |= (((((m >> s) & mk) << imm) & mk) | ((d >> s) & keep)) << s;
    return r;
}
static inline uint64_t vrt_shl_reg(uint64_t m, uint64_t n, int bits, int sgn) {      /* VSHL by per-lane signed byte count */
    uint64_t r = 0, mk = vrt_lmask(bits);
    for (int s = 0; s < 64; s += bits) {
        int sh = (int8_t)((n >> s) & 0xff); int64_t v = vrt_ext(m >> s, bits, sgn); uint64_t o;
        if (sh >= 0) o = sh >= bits ? 0 : ((uint64_t)v << sh); else { int rs = -sh; o = rs >= bits ? (sgn && v < 0 ? ~0ull : 0) : (uint64_t)(v >> rs); }
        r |= (o & mk) << s;
    }
    return r;
}
static inline uint64_t vrt_shrn(vrt_u128 q, int srcbits, int imm) {                  /* narrowing shift right, result lanes are srcbits/2 */
    uint64_t r = 0; int nb = srcbits / 2; uint64_t mk = vrt_lmask(nb);
    for (int i = 0; i < 128 / srcbits; i++) { uint64_t v = (uint64_t)((q >> (i * srcbits)) & vrt_lmask(srcbits)); r |= ((v >> imm) & mk) << (i * nb); }
    return r;
}
static inline uint64_t vrt_vpadd(uint64_t a, uint64_t b, int bits) {
    uint64_t r = 0, mk = vrt_lmask(bits); int n = 64 / bits;
    for (int i = 0; i < n / 2; i++) {
        r |= ((((a >> (2 * i * bits)) & mk) + ((a >> ((2 * i + 1) * bits)) & mk)) & mk) << (i * bits);
        r |= ((((b >> (2 * i * bits)) & mk) + ((b >> ((2 * i + 1) * bits)) & mk)) & mk) << ((n / 2 + i) * bits);
    }
    return r;
}
static inline uint64_t vrt_vpaddl(uint64_t a, int bits, int sgn) {                   /* D -> D, lanes double in width */
    uint64_t r = 0; int w = 2 * bits; uint64_t mk = vrt_lmask(w);
    for (int i = 0; i < 32 / bits; i++) {
        int64_t s = vrt_ext(a >> (2 * i * bits), bits, sgn) + vrt_ext(a >> ((2 * i + 1) * bits), bits, sgn);
        r |= ((uint64_t)s & mk) << (i * w);
    }
    return r;
}
static inline uint64_t vrt_vpadal(uint64_t d, uint64_t a, int bits, int sgn) {
    uint64_t p = vrt_vpaddl(a, bits, sgn), r = 0; int w = 2 * bits; uint64_t mk = vrt_lmask(w);
    for (int i = 0; i < 32 / bits; i++) r |= ((((d >> (i * w)) & mk) + ((p >> (i * w)) & mk)) & mk) << (i * w);
    return r;
}
static inline void vrt_vuzp(uint64_t *d, uint64_t *m, int bits) {                    /* D form: de-interleave (d:m) */
    int n = 64 / bits; uint64_t mk = vrt_lmask(bits), nd = 0, nm = 0;
    for (int i = 0; i < n; i++) {
        uint64_t e0 = (i < n / 2) ? (*d >> (2 * i * bits)) & mk : (*m >> ((2 * i - n) * bits)) & mk;
        uint64_t e1 = (i < n / 2) ? (*d >> ((2 * i + 1) * bits)) & mk : (*m >> ((2 * i + 1 - n) * bits)) & mk;
        nd |= e0 << (i * bits); nm |= e1 << (i * bits);
    }
    *d = nd; *m = nm;
}
static inline void vrt_vtrn(uint64_t *d, uint64_t *m, int bits) {                    /* D form: transpose 2x2 element blocks */
    int n = 64 / bits; uint64_t mk = vrt_lmask(bits), nd = *d, nm = *m;
    for (int i = 0; i + 1 < n; i += 2) {
        uint64_t d1 = (*d >> ((i + 1) * bits)) & mk, m0 = (*m >> (i * bits)) & mk;
        nd = (nd & ~(mk << ((i + 1) * bits))) | (m0 << ((i + 1) * bits));
        nm = (nm & ~(mk << (i * bits))) | (d1 << (i * bits));
    }
    *d = nd; *m = nm;
}
static inline uint64_t vrt_vrev(uint64_t a, int bits, int blk) {                     /* reverse `bits`-wide elements inside blk-bit blocks */
    uint64_t r = 0, mk = vrt_lmask(bits); int per = blk / bits;
    for (int b = 0; b < 64; b += blk) for (int i = 0; i < per; i++) r |= ((a >> (b + i * bits)) & mk) << (b + (per - 1 - i) * bits);
    return r;
}
enum { VRT_EQ, VRT_GE, VRT_GT, VRT_LE, VRT_LT };
static inline uint64_t vrt_vcmp_i(uint64_t a, uint64_t b, int bits, int op, int sgn) {
    uint64_t r = 0, mk = vrt_lmask(bits);
    for (int s = 0; s < 64; s += bits) {
        int64_t x = vrt_ext(a >> s, bits, sgn), y = vrt_ext(b >> s, bits, sgn); int t;
        if (!sgn) { uint64_t ux = (uint64_t)x & mk, uy = (uint64_t)y & mk; t = op == VRT_EQ ? ux == uy : op == VRT_GE ? ux >= uy : op == VRT_GT ? ux > uy : op == VRT_LE ? ux <= uy : ux < uy; }
        else t = op == VRT_EQ ? x == y : op == VRT_GE ? x >= y : op == VRT_GT ? x > y : op == VRT_LE ? x <= y : x < y;
        if (t) r |= mk << s;
    }
    return r;
}
static inline uint64_t vrt_vcmp_f(uint64_t a, uint64_t b, int op, int absolute) {
    uint64_t r = 0;
    for (int i = 0; i < 2; i++) {
        float x = vrt_nf(vrt_bits2f((uint32_t)(a >> (32 * i)))), y = vrt_nf(vrt_bits2f((uint32_t)(b >> (32 * i))));
        if (absolute) { x = __builtin_fabsf(x); y = __builtin_fabsf(y); }
        int t = op == VRT_EQ ? x == y : op == VRT_GE ? x >= y : op == VRT_GT ? x > y : op == VRT_LE ? x <= y : x < y;
        if (t) r |= 0xffffffffull << (32 * i);
    }
    return r;
}
static inline uint64_t vrt_vmaxmin_i(uint64_t a, uint64_t b, int bits, int sgn, int is_max) {
    uint64_t r = 0, mk = vrt_lmask(bits);
    for (int s = 0; s < 64; s += bits) {
        int64_t x = vrt_ext(a >> s, bits, sgn), y = vrt_ext(b >> s, bits, sgn); int64_t o;
        if (sgn) o = is_max ? (x > y ? x : y) : (x < y ? x : y);
        else { uint64_t ux = (uint64_t)x & mk, uy = (uint64_t)y & mk; o = (int64_t)(is_max ? (ux > uy ? ux : uy) : (ux < uy ? ux : uy)); }
        r |= ((uint64_t)o & mk) << s;
    }
    return r;
}
static inline uint64_t vrt_vmaxmin_f(uint64_t a, uint64_t b, int is_max) {
    uint64_t r = 0;
    for (int i = 0; i < 2; i++) {
        float x = vrt_nf(vrt_bits2f((uint32_t)(a >> (32 * i)))), y = vrt_nf(vrt_bits2f((uint32_t)(b >> (32 * i)))), o;
        if (x != x || y != y) o = vrt_bits2f(0x7fc00000u); else o = is_max ? (x > y ? x : y) : (x < y ? x : y);
        r |= (uint64_t)vrt_f2bits(o) << (32 * i);
    }
    return r;
}

/* ---- NEON reciprocal / reciprocal-sqrt estimate + Newton steps (ARM pseudocode FPRecipEstimate/FPRSqrtEstimate, standard FPSCR: FZ + default NaN) ---- */
static inline uint32_t vrt_recip_est9(uint32_t a) { a = a * 2 + 1; uint32_t b = (1u << 19) / a; return (b + 1) / 2; }
static inline uint32_t vrt_rsqrt_est(uint32_t a) {
    if (a < 256) a = a * 2 + 1; else { a = (a >> 1) << 1; a = (a + 1) * 2; }
    uint64_t b = 512; while ((uint64_t)a * (b + 1) * (b + 1) < (1ull << 28)) b++;
    return (uint32_t)((b + 1) / 2);
}
static inline uint32_t vrt_recpe_f32(uint32_t op) {
    uint32_t sign = op & 0x80000000u, exp = (op >> 23) & 0xff, frac = op & 0x7fffffu;
    if (exp == 0xff) return frac ? 0x7fc00000u : sign;                      /* NaN -> default NaN; inf -> 0 */
    if (exp == 0) return sign | 0x7f800000u;                                /* zero and flushed denormals -> inf */
    if (exp >= 253) return sign;                                           /* result underflows */
    uint32_t est = vrt_recip_est9(256u | (frac >> 15));
    return sign | ((253u - exp) << 23) | ((est & 0xffu) << 15);
}
static inline uint32_t vrt_rsqrte_f32(uint32_t op) {
    uint32_t sign = op & 0x80000000u, exp = (op >> 23) & 0xff, frac = op & 0x7fffffu;
    if (exp == 0xff) return frac ? 0x7fc00000u : (sign ? 0x7fc00000u : 0u);  /* NaN; +inf -> 0; -inf -> NaN */
    if (exp == 0) return sign | 0x7f800000u;                                /* zero -> inf */
    if (sign) return 0x7fc00000u;                                          /* negative -> default NaN */
    uint32_t scaled = (exp & 1) ? (128u | (frac >> 16)) : (256u | (frac >> 15));
    uint32_t est = vrt_rsqrt_est(scaled);
    return (((380u - exp) / 2u) << 23) | ((est & 0xffu) << 15);
}
static inline uint64_t vrt_vrecpe_d(uint64_t a) { return (uint64_t)vrt_recpe_f32((uint32_t)a) | ((uint64_t)vrt_recpe_f32((uint32_t)(a >> 32)) << 32); }
static inline uint64_t vrt_vrsqrte_d(uint64_t a) { return (uint64_t)vrt_rsqrte_f32((uint32_t)a) | ((uint64_t)vrt_rsqrte_f32((uint32_t)(a >> 32)) << 32); }
static inline uint32_t vrt_recps_f32(uint32_t ua, uint32_t ub) {
    float a = -vrt_nf(vrt_bits2f(ua)), b = vrt_nf(vrt_bits2f(ub));
    if ((__builtin_isinf(a) && b == 0.0f) || (__builtin_isinf(b) && a == 0.0f)) return 0x40000000u;       /* 2.0 */
    return vrt_f2bits(vrt_nres(__builtin_fmaf(a, b, 2.0f)));
}
static inline uint32_t vrt_rsqrts_f32(uint32_t ua, uint32_t ub) {
    float a = -vrt_nf(vrt_bits2f(ua)), b = vrt_nf(vrt_bits2f(ub));
    if ((__builtin_isinf(a) && b == 0.0f) || (__builtin_isinf(b) && a == 0.0f)) return 0x3fc00000u;       /* 1.5 */
    return vrt_f2bits(vrt_nres(__builtin_fmaf(a, b, 3.0f) * 0.5f));
}
static inline uint64_t vrt_vrecps_d(uint64_t a, uint64_t b) { return (uint64_t)vrt_recps_f32((uint32_t)a, (uint32_t)b) | ((uint64_t)vrt_recps_f32((uint32_t)(a >> 32), (uint32_t)(b >> 32)) << 32); }
static inline uint64_t vrt_vrsqrts_d(uint64_t a, uint64_t b) { return (uint64_t)vrt_rsqrts_f32((uint32_t)a, (uint32_t)b) | ((uint64_t)vrt_rsqrts_f32((uint32_t)(a >> 32), (uint32_t)(b >> 32)) << 32); }
/* VMULL.P8: carry-less 8x8 -> 16 per lane */
static inline vrt_u128 vrt_vmull_p8(uint64_t a, uint64_t b) {
    vrt_u128 r = 0;
    for (int i = 0; i < 8; i++) {
        uint32_t x = (a >> (8 * i)) & 0xff, y = (b >> (8 * i)) & 0xff, p = 0;
        for (int k = 0; k < 8; k++) if ((y >> k) & 1) p ^= x << k;
        r |= (vrt_u128)(p & 0xffffu) << (16 * i);
    }
    return r;
}
/* half <-> single (VCVTB/VCVTT, IEEE half, round to nearest even) */
static inline float vrt_h2f(uint16_t h) {
    uint32_t s = (uint32_t)(h & 0x8000) << 16, e = (h >> 10) & 0x1f, m = h & 0x3ff, o;
    if (e == 0) { if (!m) o = s; else { e = 1; while (!(m & 0x400)) { m <<= 1; e--; } m &= 0x3ff; o = s | ((e + 112) << 23) | (m << 13); } }
    else if (e == 31) o = s | 0x7f800000u | (m << 13);
    else o = s | ((e + 112) << 23) | (m << 13);
    return vrt_bits2f(o);
}
static inline uint16_t vrt_f2h(float f) {
    uint32_t u = vrt_f2bits(f), s = (u >> 16) & 0x8000, e = (u >> 23) & 0xff, m = u & 0x7fffffu;
    if (e == 0xff) return (uint16_t)(s | 0x7c00 | (m ? 0x200 | (m >> 13) : 0));
    int ne = (int)e - 127 + 15;
    if (ne >= 31) return (uint16_t)(s | 0x7c00);
    if (ne <= 0) {
        if (ne < -10) return (uint16_t)s;
        m |= 0x800000u; uint32_t sh = (uint32_t)(14 - ne), half = m >> sh, rem = m & ((1u << sh) - 1), mid = 1u << (sh - 1);
        if (rem > mid || (rem == mid && (half & 1))) half++;
        return (uint16_t)(s | half);
    }
    uint32_t half = (uint32_t)ne << 10 | (m >> 13), rem = m & 0x1fffu;
    if (rem > 0x1000u || (rem == 0x1000u && (half & 1))) half++;
    return (uint16_t)(s | half);
}

/* ---- exclusives: monitor = (address, value seen); strex = compare-and-swap ---- */
#define VRT_EXCL(BITS, T) \
static inline uint32_t vrt_ldrex##BITS(vrt_ctx *x, uint32_t a) { \
    T v = __atomic_load_n((T *)(vrt_mem + a), __ATOMIC_SEQ_CST); x->ex_addr = a; x->ex_val = v; return (uint32_t)v; } \
static inline uint32_t vrt_strex##BITS(vrt_ctx *x, uint32_t a, uint32_t nv) { \
    T exp = (T)x->ex_val; \
    int ok = (x->ex_addr == a && a != 0) && __atomic_compare_exchange_n((T *)(vrt_mem + a), &exp, (T)nv, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); \
    x->ex_addr = 0; return ok ? 0u : 1u; }
VRT_EXCL(8, uint8_t)
VRT_EXCL(16, uint16_t)
VRT_EXCL(32, uint32_t)
static inline uint64_t vrt_ldrex64(vrt_ctx *x, uint32_t a) {
    uint64_t v = __atomic_load_n((uint64_t *)(vrt_mem + a), __ATOMIC_SEQ_CST); x->ex_addr = a; x->ex_val = v; return v; }
static inline uint32_t vrt_strex64(vrt_ctx *x, uint32_t a, uint64_t nv) {
    uint64_t exp = x->ex_val;
    int ok = (x->ex_addr == a && a != 0) && __atomic_compare_exchange_n((uint64_t *)(vrt_mem + a), &exp, nv, 0, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST);
    x->ex_addr = 0; return ok ? 0u : 1u; }
#endif
