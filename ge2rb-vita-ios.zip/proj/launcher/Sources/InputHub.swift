import Foundation
import GameController

/// Merges on-screen touch controls and physical game controllers into the runtime's input state.
final class InputHub {
    static let shared = InputHub()
    private let lock = NSLock()
    private var touchMask: UInt32 = 0
    private var padMask: UInt32 = 0
    private var touchSticks: [Double] = [0, 0, 0, 0]     // lx ly rx ry in -1...1 (y: down positive)
    private var padSticks: [Double] = [0, 0, 0, 0]

    private init() {
        NotificationCenter.default.addObserver(forName: .GCControllerDidConnect, object: nil, queue: .main) { [weak self] n in
            if let c = n.object as? GCController { self?.attach(c) }
        }
        GCController.controllers().forEach(attach)
    }

    // MARK: touch
    func setTouch(bit: UInt32, down: Bool) {
        lock.lock(); if down { touchMask |= bit } else { touchMask &= ~bit }; lock.unlock(); push()
    }
    func setTouchStick(left: Bool, x: Double, y: Double) {
        lock.lock(); let o = left ? 0 : 2; touchSticks[o] = x; touchSticks[o + 1] = y; lock.unlock(); push()
    }

    // MARK: physical controller
    private func attach(_ c: GCController) {
        guard let gp = c.extendedGamepad else { return }
        gp.valueChangedHandler = { [weak self] gp, _ in self?.read(gp) }
    }
    private func read(_ gp: GCExtendedGamepad) {
        var m: UInt32 = 0
        func set(_ on: Bool, _ bit: Int32) { if on { m |= UInt32(bit) } }
        set(gp.buttonA.isPressed, Int32(VRT_CROSS)); set(gp.buttonB.isPressed, Int32(VRT_CIRCLE))
        set(gp.buttonX.isPressed, Int32(VRT_SQUARE)); set(gp.buttonY.isPressed, Int32(VRT_TRIANGLE))
        set(gp.leftShoulder.isPressed, Int32(VRT_L1)); set(gp.rightShoulder.isPressed, Int32(VRT_R1))
        set(gp.dpad.up.isPressed, Int32(VRT_UP)); set(gp.dpad.down.isPressed, Int32(VRT_DOWN))
        set(gp.dpad.left.isPressed, Int32(VRT_LEFT)); set(gp.dpad.right.isPressed, Int32(VRT_RIGHT))
        set(gp.buttonMenu.isPressed, Int32(VRT_START))
        set(gp.buttonOptions?.isPressed ?? false, Int32(VRT_SELECT))
        set(gp.leftThumbstickButton?.isPressed ?? false, Int32(VRT_L3))
        set(gp.rightThumbstickButton?.isPressed ?? false, Int32(VRT_R3))
        set(gp.buttonHome?.isPressed ?? false, Int32(VRT_PS))
        lock.lock()
        padMask = m
        padSticks = [Double(gp.leftThumbstick.xAxis.value), Double(-gp.leftThumbstick.yAxis.value),
                     Double(gp.rightThumbstick.xAxis.value), Double(-gp.rightThumbstick.yAxis.value)]
        lock.unlock(); push()
    }

    // MARK: publish to runtime
    private func push() {
        lock.lock()
        let mask = touchMask | padMask
        var s = [UInt8](repeating: 128, count: 4)
        for i in 0..<4 {
            let v = abs(padSticks[i]) > 0.06 ? padSticks[i] : touchSticks[i]
            s[i] = UInt8(max(0, min(255, (128 + v * 127).rounded())))
        }
        lock.unlock()
        vrt_input_set_buttons(mask)
        vrt_input_set_sticks(s[0], s[1], s[2], s[3])
    }
}
