import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @StateObject private var lib = GameLibrary()
    @State private var picking = false
    @State private var confirmDelete = false
    @State private var showControls = false

    var body: some View {
        NavigationView {
            List {
                Section("Game data") {
                    if lib.importing {
                        ProgressView(value: lib.progress)
                        Text(lib.message).font(.caption).lineLimit(1).truncationMode(.middle)
                        Button("Cancel import", role: .destructive) { lib.cancelImport() }
                    } else {
                        Button(lib.installed ? "Re-import game zip…" : "Import game zip…") { picking = true }
                        if lib.installed {
                            Button("Delete game data", role: .destructive) { confirmDelete = true }
                        }
                        if !lib.message.isEmpty {
                            Text(lib.message).font(.footnote).foregroundColor(.secondary)
                        }
                    }
                    Text("Use a zip of your own dump containing `app/\(GameLibrary.titleID)` and `patch/\(GameLibrary.titleID)`. Needs ~4 GB free. Keep the app open while importing.")
                        .font(.footnote).foregroundColor(.secondary)
                }
                if !lib.checks.isEmpty {
                    Section("Checks") {
                        ForEach(lib.checks) { c in
                            HStack {
                                Image(systemName: c.ok ? "checkmark.circle.fill" : "xmark.octagon.fill")
                                    .foregroundColor(c.ok ? .green : .red)
                                VStack(alignment: .leading) {
                                    Text(c.title); Text(c.detail).font(.caption).foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                }
                Section("Controls") {
                    Button("Controls test (touch + gamepad)") { showControls = true }
                }
                Section("Runtime") {
                    Text(lib.rtStatus).font(.footnote)
                    Button("Test memory reservation") { lib.probeRuntime() }
                }
                Section {
                    Button("Launch") { }.disabled(true)
                    Text("Launch is disabled until recompiled game code is linked into this build.")
                        .font(.footnote).foregroundColor(.secondary)
                }
            }
            .navigationTitle("GE2RB Launcher")
        }
        .navigationViewStyle(.stack)
        .fileImporter(isPresented: $picking, allowedContentTypes: [.zip]) { result in
            if case .success(let url) = result { lib.importZip(url) }
        }
        .fullScreenCover(isPresented: $showControls) { ControlsTestView() }
        .alert("Delete imported game data?", isPresented: $confirmDelete) {
            Button("Delete", role: .destructive) { lib.deleteGame() }
            Button("Cancel", role: .cancel) { }
        }
    }
}
