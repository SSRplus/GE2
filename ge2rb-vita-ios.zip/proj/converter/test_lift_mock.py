"""Runs without Capstone: injects a fake one and checks the lifter's C output at least compiles.
Semantics are checked against Unicorn by difftest.py in CI."""
import os, subprocess, sys, tempfile, types

NAMES_INS = ('ADD ADC SUB SBC RSB CMP CMN AND ORR EOR BIC ORN TST TEQ MOV MVN LSL LSR ASR ROR RRX MOVW MOVT MUL MLA MLS UMULL '
             'SMULL UMLAL SMLAL UXTB UXTH SXTB SXTH REV REV16 REVSH RBIT CLZ UBFX SBFX BFI BFC LDR LDRB LDRH LDRSB LDRSH STR '
             'STRB STRH LDRD STRD PUSH POP LDM LDMIA LDMDB STM STMIA STMDB B BL BLX BX CBZ CBNZ NOP IT DMB DSB ISB TBB TBH ADDW SUBW '
             'MOVS HINT BKPT UDF UXTAB UXTAH SXTAB SXTAH LDREX LDREXB LDREXH LDREXD STREX STREXB STREXH STREXD VADD VSUB VMUL VDIV '
             'VMLA VMLS VNMLA VNMLS VNMUL VNEG VABS VSQRT VMOV FCONSTS FCONSTD VLDR VSTR VPUSH VPOP VSTMIA VLDMIA VSTMDB VLDMDB '
             'VCMP VCMPE VCVT FMSTAT VMRS VMSR VRECPE VRSQRTE VRECPS VRSQRTS VCVTB VCVTT ADR VLD1 VST1 VMULL VMLAL VMLSL VMOVL VSHLL VADDW VSHL VSHR VSHRN VSLI VPADD VPADDL VPADAL VUZP VTRN VREV16 VREV32 VREV64 VCLE VCLT VCGE VCGT VACGT VACGE VMAX VMIN VORR VAND VBIC VEOR VBSL VBIF VBIT VMVN VDUP VCEQ PLD MRC').split()
K = types.ModuleType('arm_const')
n = 1
for nm in NAMES_INS: setattr(K, 'ARM_INS_' + nm, n); n += 1
for nm in 'INVALID EQ NE HS LO MI PL VS VC HI LS GE LT GT LE AL'.split(): setattr(K, 'ARM_CC_' + nm, n); n += 1
for nm in 'INVALID ASR LSL LSR ROR RRX ASR_REG LSL_REG LSR_REG ROR_REG RRX_REG'.split(): setattr(K, 'ARM_SFT_' + nm, n if nm != 'INVALID' else 0); n += 1
K.ARM_OP_REG, K.ARM_OP_IMM, K.ARM_OP_MEM, K.ARM_OP_FP = 1000, 1001, 1002, 1003
REGS = {f'r{i}': 2000 + i for i in range(13)}; REGS.update(sp=2013, lr=2014, pc=2015, apsr_nzcv=2016, fpscr=2017)
REGS.update({f's{i}': 3000 + i for i in range(32)}); REGS.update({f'd{i}': 3100 + i for i in range(32)}); REGS.update({f'q{i}': 3200 + i for i in range(16)})
K.ARM_REG_PC = 2015
class Cs:
    def __init__(s, *a): s.detail = False
    def reg_name(s, r): return {v: k for k, v in REGS.items()}[r]
cap = types.ModuleType('capstone'); cap.Cs = Cs; cap.CS_ARCH_ARM = 0; cap.CS_MODE_THUMB = 0; cap.CS_MODE_ARM = 1; cap.arm_const = K
sys.modules['capstone'] = cap
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lift

class Shift: 
    def __init__(s, t=0, v=0): s.type, s.value = t, v
class Mem:
    def __init__(s, base, disp=0, index=0, lshift=0, scale=1): s.base, s.disp, s.index, s.lshift, s.scale = base, disp, index, lshift, scale
class Op:
    def __init__(s, type_, reg=0, imm=0, mem=None, shift=None, subtracted=False, fp=0.0):
        s.type, s.reg, s.imm, s.mem, s.shift, s.subtracted, s.fp = type_, reg, imm, mem, shift or Shift(), subtracted, fp
        s.vector_index = -1
R = lambda n, sh=None: Op(K.ARM_OP_REG, reg=REGS[n], shift=sh)
def LANE(op, i):
    op.vector_index = i
    return op
IM = lambda v: Op(K.ARM_OP_IMM, imm=v)
M = lambda base, **kw: Op(K.ARM_OP_MEM, mem=Mem(REGS[base], **kw))
class Insn:
    def __init__(s, name, ops, addr=0x1000, size=2, cc='AL', S=False, wb=False, mn=None, op_str=''):
        s.id = getattr(K, 'ARM_INS_' + name); s.operands = ops; s.address = addr; s.size = size
        s.cc = getattr(K, 'ARM_CC_' + cc); s.update_flags = S; s.writeback = wb
        s.mnemonic = mn or name.lower(); s.op_str = op_str; s.bytes = bytes(size)

def _adr(ins, raw):
    ins.bytes = bytes(raw)
    return ins

def test_emit_compiles():
    lf = lift.Lifter(0x1000, lambda a, n: bytes(n), relocs={0x10: (47, 1, 0x24), 0x14: (48, 1, 0x24), 0x20: (47, 15, 0x1234), 0x28: (47, 1, 0x40)})
    lf._dec = {0x1000: None, 0x1004: None}
    lf._tables = {0x1000: [0x1004, 0x1004, 0x1004]}
    cases = [
        Insn('ADD', [R('r0'), R('r1'), IM(4)], S=True), Insn('ADD', [R('r0'), R('r1'), R('r2', Shift(K.ARM_SFT_LSL, 2))]),
        Insn('SUB', [R('r3'), IM(1)], S=True), Insn('RSB', [R('r0'), R('r1'), IM(0)], S=True),
        Insn('CMP', [R('r0'), IM(7)]), Insn('TST', [R('r0'), R('r1')]), Insn('MOV', [R('r0'), R('r1')], S=True),
        Insn('MVN', [R('r0'), IM(5)], size=4, S=True), Insn('AND', [R('r0'), R('r1'), IM(0xff)], size=4, S=True),
        Insn('LSL', [R('r0'), R('r1'), IM(3)], S=True), Insn('ASR', [R('r0'), R('r1'), R('r2')]),
        Insn('MOVW', [R('r0'), IM(0x1234)], size=4), Insn('MOVW', [R('r1'), IM(0)], addr=0x1010, size=4), Insn('MOVT', [R('r1'), IM(0)], addr=0x1014, size=4), Insn('MOVW', [R('r2'), IM(0)], addr=0x1020, size=4), Insn('MOV', [R('r3'), IM(0)], addr=0x1028, size=4, mn='movw'), Insn('MOV', [R('r3'), IM(0x1234)], addr=0x1030, size=4, mn='movw'), Insn('MOVT', [R('r0'), IM(0x5678)], size=4),
        Insn('MUL', [R('r0'), R('r1'), R('r0')], S=True), Insn('MLA', [R('r0'), R('r1'), R('r2'), R('r3')], size=4),
        Insn('UMULL', [R('r0'), R('r1'), R('r2'), R('r3')], size=4), Insn('UXTB', [R('r0'), R('r1')]),
        Insn('SXTH', [R('r0'), R('r1', Shift(K.ARM_SFT_ROR, 8))], size=4), Insn('UBFX', [R('r0'), R('r1'), IM(4), IM(8)], size=4),
        Insn('BFI', [R('r0'), R('r1'), IM(4), IM(8)], size=4), Insn('BFC', [R('r0'), IM(4), IM(8)], size=4),
        Insn('CLZ', [R('r0'), R('r1')], size=4), Insn('REV', [R('r0'), R('r1')]),
        Insn('LDR', [R('r0'), M('r1', disp=8)]), Insn('LDR', [R('r0'), M('pc', disp=8)]),
        Insn('LDR', [R('r0'), M('r1', disp=-4)], size=4, wb=True), Insn('LDR', [R('r0'), M('r1', index=REGS['r2'], lshift=2)], size=4),
        Insn('LDR', [R('r0'), M('r1'), IM(4)], size=4), Insn('STRB', [R('r0'), M('r1', disp=1)]),
        Insn('LDRSH', [R('r0'), M('r1', disp=2)]), Insn('LDRD', [R('r0'), R('r1'), M('r2', disp=8)], size=4),
        Insn('STRD', [R('r0'), R('r1'), M('sp', disp=8)], size=4, wb=True),
        Insn('PUSH', [R('r4'), R('r5'), R('lr')]), Insn('POP', [R('r4'), R('r5'), R('pc')]),
        Insn('POP', [R('r4'), R('r5')], cc='EQ'), Insn('LDMIA'.replace('IA', ''), [R('r0'), R('r1'), R('r2')], wb=True),
        Insn('STMDB', [R('sp'), R('r4'), R('lr')], size=4, wb=True),
        Insn('B', [IM(0x1004)]), Insn('B', [IM(0x1004)], cc='NE'), Insn('CBZ', [R('r0'), IM(0x1004)]),
        Insn('BL', [IM(0x2000)], size=4), Insn('BLX', [R('r3')]), Insn('BX', [R('lr')]), Insn('BX', [R('r3')]),
        Insn('MOV', [R('r0'), IM(1)], cc='GT'), Insn('NOP', []), Insn('TBB', [M('pc', index=REGS['r0'])]),
        Insn('HINT', [], mn='nop.w'), Insn('BKPT', [IM(0)]), Insn('MOVS', [R('r0'), IM(3)], S=True), Insn('UXTAH', [R('r0'), R('r1'), R('r2')], size=4),
        Insn('LDREX', [R('r0'), M('r1', disp=4)], size=4), Insn('STREX', [R('r0'), R('r1'), M('r2')], size=4), Insn('LDREXD', [R('r0'), R('r1'), M('r2')], size=4),
        Insn('STREXD', [R('r0'), R('r1'), R('r2'), M('r3')], size=4), Insn('LDREXB', [R('r0'), M('r1')], size=4),
        Insn('VADD', [R('s0'), R('s1'), R('s2')], size=4, mn='vadd.f32'), Insn('VMUL', [R('d0'), R('d1'), R('d2')], size=4),
        Insn('VMLA', [R('s0'), R('s1'), R('s2')], size=4), Insn('VNMLS', [R('d0'), R('d1'), R('d2')], size=4), Insn('VSQRT', [R('s0'), R('s1')], size=4),
        Insn('VNEG', [R('d0'), R('d1')], size=4), Insn('VMOV', [R('s0'), R('s1')], size=4), Insn('VMOV', [R('r0'), R('s1')], size=4),
        Insn('VMOV', [R('s1'), R('r0')], size=4), Insn('VMOV', [R('r0'), R('r1'), R('d2')], size=4), Insn('VMOV', [R('d2'), R('r0'), R('r1')], size=4),
        Insn('FCONSTS', [R('s0'), Op(K.ARM_OP_FP, fp=1.0)], size=4), Insn('FCONSTD', [R('d0'), Op(K.ARM_OP_FP, fp=-2.5)], size=4),
        Insn('VLDR', [R('s0'), M('r1', disp=8)], size=4), Insn('VSTR', [R('d0'), M('pc', disp=8)], size=4), Insn('VLDR', [R('d0'), M('sp', disp=-8)], size=4),
        Insn('VPUSH', [R('d8'), R('d9'), R('d10')], size=4), Insn('VPOP', [R('s16'), R('s17')], size=4),
        Insn('VSTMIA', [R('r0'), R('d0'), R('d1')], size=4, wb=True), Insn('VLDMDB', [R('r0'), R('s0'), R('s1')], size=4, wb=True),
        Insn('VCMP', [R('s0'), R('s1')], size=4), Insn('VCMP', [R('d0'), Op(K.ARM_OP_FP, fp=0.0)], size=4), Insn('FMSTAT', [], size=4), Insn('FMSTAT', [R('apsr_nzcv'), R('fpscr')], size=4), Insn('VMSR', [R('fpscr'), R('r0')], size=4),
        Insn('VMRS', [R('r0'), R('s0')], size=4), Insn('VMSR', [R('s0'), R('r0')], size=4),
        Insn('VCVT', [R('s0'), R('s1')], size=4, mn='vcvt.f32.s32'), Insn('VCVT', [R('d0'), R('s1')], size=4, mn='vcvt.f64.u32'),
        Insn('VCVT', [R('s0'), R('s1')], size=4, mn='vcvt.s32.f32'), Insn('VCVT', [R('s0'), R('d1')], size=4, mn='vcvt.u32.f64'),
        Insn('VCVT', [R('d0'), R('s1')], size=4, mn='vcvt.f64.f32'), Insn('VCVT', [R('s0'), R('d1')], size=4, mn='vcvt.f32.f64'),
        Insn('VORR', [R('q0'), R('q1'), R('q2')], size=4), Insn('VORR', [R('d0'), IM(0xff00)], size=4, mn='vorr.i32'), Insn('VAND', [R('d0'), R('d1'), R('d2')], size=4),
        Insn('VBIC', [R('q0'), R('q1'), R('q2')], size=4), Insn('VEOR', [R('d0'), R('d1'), R('d2')], size=4), Insn('VBSL', [R('q0'), R('q1'), R('q2')], size=4),
        Insn('VBIF', [R('d0'), R('d1'), R('d2')], size=4), Insn('VBIT', [R('d0'), R('d1'), R('d2')], size=4), Insn('VMVN', [R('q0'), R('q1')], size=4),
        Insn('VDUP', [R('q0'), R('r0')], size=4, mn='vdup.32'), Insn('VDUP', [R('d0'), R('r0')], size=4, mn='vdup.8'),
        Insn('VCEQ', [R('q0'), R('q1'), R('q2')], size=4, mn='vceq.i32'), Insn('VCEQ', [R('d0'), R('d1'), IM(0)], size=4, mn='vceq.f32'),
        Insn('VMOV', [R('d8'), IM(2)], size=4, mn='vmov.i32'), Insn('VMOV', [R('q1'), IM(0xff)], size=4, mn='vmov.i8'), Insn('VMOV', [R('q0'), R('q1')], size=4, mn='vmov'),
        Insn('VADD', [R('q0'), R('q1'), R('q2')], size=4, mn='vadd.f32'), Insn('VMLA', [R('d4'), R('d30'), R('d28')], size=4, mn='vmla.f32'),
        Insn('VNEG', [R('d6'), R('d24')], size=4, mn='vneg.f32'), Insn('VABS', [R('q1'), R('q2')], size=4, mn='vabs.f32'),
        Insn('PLD', [M('r0', disp=4)], size=4),
        Insn('VRECPE', [R('q0'), R('q1')], size=4, mn='vrecpe.f32'), Insn('VRSQRTE', [R('d0'), R('d1')], size=4, mn='vrsqrte.f32'),
        Insn('VRECPS', [R('q0'), R('q1'), R('q2')], size=4, mn='vrecps.f32'), Insn('VRSQRTS', [R('d0'), R('d1'), R('d2')], size=4, mn='vrsqrts.f32'),
        Insn('VMULL', [R('q0'), R('d1'), R('d2')], size=4, mn='vmull.p8'),
        Insn('VCVTB', [R('s0'), R('s1')], size=4, mn='vcvtb.f32.f16'), Insn('VCVTT', [R('s2'), R('s3')], size=4, mn='vcvtt.f16.f32'),
        _adr(Insn('ADR', [R('r0'), IM(0x1020)], size=2), [0x05, 0xa0]), _adr(Insn('ADR', [R('r1'), IM(0x1020)], size=4), [0x0f, 0xf2, 0x08, 0x01]),
        Insn('VST1', [R('d0'), R('d1'), M('r0')], size=4, mn='vst1.8', wb=True), Insn('VLD1', [R('d16'), R('d17'), R('d18'), R('d19'), M('r1'), R('r2')], size=4, mn='vld1.64'),
        Insn('VLD1', [LANE(R('d0'), 1), M('r1')], size=4, mn='vld1.32'), Insn('VST1', [LANE(R('d3'), 5), M('r1')], size=4, mn='vst1.8', wb=True),
        Insn('VMULL', [R('q8'), R('d16'), R('d17')], size=4, mn='vmull.s16'), Insn('VMULL', [R('q0'), R('d1'), LANE(R('d2'), 3)], size=4, mn='vmull.u16'),
        Insn('VMLAL', [R('q0'), R('d1'), R('d2')], size=4, mn='vmlal.u8'), Insn('VMLSL', [R('q0'), R('d1'), R('d2')], size=4, mn='vmlsl.s32'),
        Insn('VMOVL', [R('q8'), R('d16')], size=4, mn='vmovl.u8'), Insn('VSHLL', [R('q8'), R('d16'), IM(8)], size=4, mn='vshll.u8'),
        Insn('VADDW', [R('q8'), R('q8'), R('d17')], size=4, mn='vaddw.s16'), Insn('VSHRN', [R('d0'), R('q1'), IM(8)], size=4, mn='vshrn.i32'),
        Insn('VSHL', [R('d0'), R('d1'), IM(3)], size=4, mn='vshl.i32'), Insn('VSHL', [R('q0'), R('q1'), R('q2')], size=4, mn='vshl.s16'),
        Insn('VSHR', [R('q0'), R('q1'), IM(4)], size=4, mn='vshr.u16'), Insn('VSLI', [R('d0'), R('d1'), IM(5)], size=4, mn='vsli.8'),
        Insn('VPADD', [R('d0'), R('d1'), R('d2')], size=4, mn='vpadd.i16'), Insn('VPADD', [R('d0'), R('d1'), R('d2')], size=4, mn='vpadd.f32'),
        Insn('VPADDL', [R('q0'), R('q1')], size=4, mn='vpaddl.s8'), Insn('VPADAL', [R('d0'), R('d1')], size=4, mn='vpadal.u16'),
        Insn('VUZP', [R('d0'), R('d1')], size=4, mn='vuzp.16'), Insn('VTRN', [R('d0'), R('d1')], size=4, mn='vtrn.32'),
        Insn('VREV32', [R('q0'), R('q1')], size=4, mn='vrev32.8'), Insn('VCLE', [R('q0'), R('q1'), IM(0)], size=4, mn='vcle.s32'),
        Insn('VCGE', [R('d0'), R('d1'), R('d2')], size=4, mn='vcge.f32'), Insn('VACGT', [R('d0'), R('d1'), R('d2')], size=4, mn='vacgt.f32'),
        Insn('VMAX', [R('d0'), R('d1'), R('d2')], size=4, mn='vmax.s16'), Insn('VMIN', [R('q0'), R('q1'), R('q2')], size=4, mn='vmin.f32'),
        Insn('VMUL', [R('q0'), R('q1'), LANE(R('d2'), 1)], size=4, mn='vmul.f32'), Insn('VMLA', [R('d0'), R('d1'), LANE(R('d2'), 0)], size=4, mn='vmla.f32'),
        Insn('VADD', [R('q2'), R('q2'), R('q15')], size=4, mn='vadd.i32'), Insn('VSUB', [R('d0'), R('d1'), R('d2')], size=4, mn='vsub.i16'), Insn('VMUL', [R('q0'), R('q1'), R('q2')], size=4, mn='vmul.i8'),
        Insn('VDUP', [R('q0'), LANE(R('d3'), 1)], size=4, mn='vdup.32'), Insn('MRC', [], size=4, op_str='p15, #0, r0, c13, c0, #3'),
    ]
    body = []
    for i, ins in enumerate(cases):
        lines, _ = lf.emit(ins)
        body.append(f"void t{i}(vrt_ctx *x) {{\n" + "\n".join(lines) + "\nL_1004:;\n}\n")
    src = '#include "vita_ops.h"\nuint32_t MOD_B;\nuint32_t MOD_SEG[4];\n' + "\n".join(body)
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, 't.c'); open(p, 'w').write(src)
        inc = os.path.join(os.path.dirname(__file__), '..', 'runtime', 'include')
        r = subprocess.run(['gcc', '-fsyntax-only', '-Wall', '-Wno-unused-label', '-Wno-unused-variable', '-ffp-contract=off', '-I', inc, p], capture_output=True, text=True)
        assert r.returncode == 0, r.stderr + "\n" + src
    assert not lf.stats['bad'], dict(lf.stats['bad'])
    assert 0x28 in lf.reloc_used, 'movw reported under the MOV id must still use its relocation'


def test_arm_mode_emits_compile():
    lf = lift.Lifter(0x1000, lambda a, n: bytes(n), arm=True)
    lf._dec = {0x1000: None, 0x1010: None}
    cases = [
        Insn('MOV', [R('pc'), R('lr')], size=4), Insn('MOV', [R('pc'), R('r3')], size=4), Insn('BX', [R('lr')], size=4), Insn('BX', [R('r2')], size=4),
        Insn('BL', [IM(0x2000)], size=4), Insn('BLX', [IM(0x2002)], size=4), Insn('B', [IM(0x1010)], size=4, cc='NE'),
        Insn('ADD', [R('r0'), R('pc'), IM(8)], size=4), Insn('LDR', [R('r0'), M('pc', disp=8)], size=4),
        Insn('POP', [R('r4'), R('pc')], size=4), Insn('MOV', [R('r0'), IM(1)], size=4, cc='EQ'), Insn('RSB', [R('r0'), R('r0'), IM(0)], size=4, S=True, cc='MI'),
    ]
    body = []
    for i, ins in enumerate(cases):
        lines, _ = lf.emit(ins)
        body.append(f"void a{i}(vrt_ctx *x) {{\n" + "\n".join(lines) + "\nL_1010:;\n}\n")
    src = '#include "vita_ops.h"\nuint32_t MOD_B;\nuint32_t MOD_SEG[4];\n' + "\n".join(body)
    assert not lf.stats['bad'], dict(lf.stats['bad'])
    assert 'x->r[14] = (MOD_B + 0x4u);' in src and '(MOD_B + 0x8u)' in src       # ARM: lr = next insn (no thumb bit), pc reads +8
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, 'a.c'); open(p, 'w').write(src)
        inc = os.path.join(os.path.dirname(__file__), '..', 'runtime', 'include')
        r = subprocess.run(['gcc', '-fsyntax-only', '-Wall', '-Wno-unused-label', '-Wno-unused-variable', '-I', inc, p], capture_output=True, text=True)
        assert r.returncode == 0, r.stderr + "\n" + src


def test_blx_lr_calls_the_old_target():
    """Regression: `blx lr` (vtable calls) used to write lr first and then call the new lr = the next instruction."""
    import ctypes
    lf = lift.Lifter(0x10000000, lambda a, n: bytes(n)); lf._dec = {}; lf._tables = {}
    A = 0x10000000
    src = '#include "vita_ops.h"\nuint32_t MOD_B;\n'
    for n, ins in {'blxlr': Insn('BLX', [R('lr')], addr=A + 0x100, size=2), 'blxr3': Insn('BLX', [R('r3')], addr=A + 0x100, size=2)}.items():
        lines, _ = lf.emit(ins)
        src += f"void {n}(vrt_ctx *x){{\n" + "\n".join(lines) + "\n}\n"
    root = os.path.join(os.path.dirname(__file__), '..', 'runtime')
    with tempfile.TemporaryDirectory() as d:
        open(d + '/t.c', 'w').write(src)
        subprocess.run(['gcc', '-shared', '-fPIC', '-O1', '-w', '-I', root + '/include', root + '/src/vita_rt.c', root + '/src/vita_input.c',
                        root + '/test/harness.c', d + '/t.c', '-o', d + '/t.so', '-lpthread', '-lm'], check=True)
        lib = ctypes.CDLL(d + '/t.so')
        lib.vrt_harness_run.argtypes = [ctypes.c_void_p, ctypes.c_void_p]; lib.vrt_register.argtypes = [ctypes.c_uint32, ctypes.c_void_p]
        assert lib.vrt_init(0) == 0
        class Ctx(ctypes.Structure):
            _fields_ = [('r', ctypes.c_uint32 * 16), ('pad', ctypes.c_uint8 * 1024)]
        hits = []
        cb = ctypes.CFUNCTYPE(None, ctypes.c_void_p)(lambda p: hits.append(1))
        lib.vrt_register(0x10002001, ctypes.cast(cb, ctypes.c_void_p))
        ctypes.c_uint32.in_dll(lib, 'MOD_B').value = A
        for name, reg in (('blxlr', 14), ('blxr3', 3)):
            c = Ctx(); c.r[reg] = 0x10002001; hits.clear()
            assert lib.vrt_harness_run(ctypes.cast(getattr(lib, name), ctypes.c_void_p), ctypes.byref(c)) == 0, name
            assert hits == [1] and c.r[14] == ((A + 0x102) | 1), (name, hits, hex(c.r[14]))
