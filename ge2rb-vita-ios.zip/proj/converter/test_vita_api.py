"""Guards the VitaModule API that lift/prep/link tools rely on (a refactor once silently dropped function_starts)."""
import glob, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vita_self import VitaModule

API = ['to_elf', 'read', 'cstr', 'module_info', 'imports', 'exports', 'function_starts']

def test_api_surface():
    for name in API:
        assert hasattr(VitaModule, name), f'VitaModule.{name} is missing'

def test_real_module_if_present():
    G = os.environ.get('GAME_CODE', 'game')
    files = sorted(glob.glob(os.path.join(G, '**', 'god_m000_Boot.self'), recursive=True))
    if not files:
        return
    m = VitaModule(files[0])
    assert len(m.function_starts()) > 10 and m.exports() and m.imports()

if __name__ == '__main__':
    test_api_surface(); test_real_module_if_present(); print('api ok')
