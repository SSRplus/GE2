#!/usr/bin/env python3
"""Thumb-2 -> C lifter, v0 (integer core). NEVER RUN against real Capstone before CI: check the CI log.

  lift.py coverage --app A [--patch P] [--jobs N]            instruction coverage over the whole game
  lift.py module   --app A [--patch P] --module bin/x.self --out gen/   emit C for one module

Generated code conventions (see runtime/include/vita_rt.h, vita_ops.h):
  void f_<addr>(vrt_ctx *x)   registers live in x->r[], flags in x->n/z/c/v
  MOD_B                       runtime base address of the module's text segment
  calls go through vrt_call(x, guest_addr); returning = C return
"""
import argparse, collections, multiprocessing, os, struct, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB, CS_MODE_ARM
from capstone import arm_const as K


class Unsupported(Exception):
    pass


def _lane(o):
    """Lane index of a NEON register operand like d16[1], or -1. Capstone 4/5 expose it as vector_index and/or neon_lane."""
    for attr in ('vector_index', 'neon_lane'):
        v = getattr(o, attr, -1)
        if v is not None and v != -1:
            return v
    return -1


def _ids(*names):
    return {getattr(K, 'ARM_INS_' + n) for n in names if hasattr(K, 'ARM_INS_' + n)}

def _name_map():
    m = {}
    for k in dir(K):
        if k.startswith('ARM_INS_'):
            m.setdefault(getattr(K, k), k[8:])
    return m

INSNAME = _name_map()
OP_REG, OP_IMM, OP_MEM = K.ARM_OP_REG, K.ARM_OP_IMM, K.ARM_OP_MEM
SFT = {n: getattr(K, 'ARM_SFT_' + n) for n in
       ('INVALID', 'ASR', 'LSL', 'LSR', 'ROR', 'RRX', 'ASR_REG', 'LSL_REG', 'LSR_REG', 'ROR_REG', 'RRX_REG')}
REGIDX = {**{f'r{i}': i for i in range(16)}, 'sb': 9, 'sl': 10, 'fp': 11, 'ip': 12, 'sp': 13, 'lr': 14, 'pc': 15}
SHIFTFN = {SFT['LSL']: 'vrt_lsl', SFT['LSR']: 'vrt_lsr', SFT['ASR']: 'vrt_asr', SFT['ROR']: 'vrt_ror', SFT['RRX']: 'vrt_rrx'}
SHIFTFN_REG = {SFT['LSL_REG']: 'vrt_lsl', SFT['LSR_REG']: 'vrt_lsr', SFT['ASR_REG']: 'vrt_asr',
               SFT['ROR_REG']: 'vrt_ror', SFT['RRX_REG']: 'vrt_rrx'}


def cond_c(cc):
    t = {'EQ': 'x->z', 'NE': '!x->z', 'HS': 'x->c', 'LO': '!x->c', 'MI': 'x->n', 'PL': '!x->n',
         'VS': 'x->v', 'VC': '!x->v', 'HI': '(x->c && !x->z)', 'LS': '(!x->c || x->z)',
         'GE': '(x->n == x->v)', 'LT': '(x->n != x->v)', 'GT': '(!x->z && x->n == x->v)',
         'LE': '(x->z || x->n != x->v)'}
    for k, v in t.items():
        if getattr(K, 'ARM_CC_' + k) == cc:
            return v
    return None          # AL / invalid


ARITH = {'ADD': 'vrt_adc({a}, {b}, 0, &co, &vo)', 'ADC': 'vrt_adc({a}, {b}, x->c, &co, &vo)',
         'SUB': 'vrt_adc({a}, ~({b}), 1, &co, &vo)', 'SBC': 'vrt_adc({a}, ~({b}), x->c, &co, &vo)',
         'RSB': 'vrt_adc({b}, ~({a}), 1, &co, &vo)', 'CMP': 'vrt_adc({a}, ~({b}), 1, &co, &vo)',
         'CMN': 'vrt_adc({a}, {b}, 0, &co, &vo)'}
LOGIC = {'AND': '{a} & {b}', 'ORR': '{a} | {b}', 'EOR': '{a} ^ {b}', 'BIC': '{a} & ~({b})', 'ORN': '{a} | ~({b})',
         'TST': '{a} & {b}', 'TEQ': '{a} ^ {b}', 'MOV': '{b}', 'MVN': '~({b})'}
NOWRITE = {'CMP', 'CMN', 'TST', 'TEQ'}
NEON2_NAMES = {'VMULL', 'VMLAL', 'VMLSL', 'VMOVL', 'VSHLL', 'VADDW', 'VSHL', 'VSHR', 'VSHRN', 'VSLI', 'VPADD', 'VPADDL', 'VPADAL', 'VUZP', 'VTRN',
               'VREV16', 'VREV32', 'VREV64', 'VRECPE', 'VRSQRTE', 'VRECPS', 'VRSQRTS', 'VCLE', 'VCLT', 'VCGE', 'VCGT', 'VACGT', 'VACGE', 'VMAX', 'VMIN'}
NEON_NAMES = {'VORR', 'VAND', 'VBIC', 'VEOR', 'VBSL', 'VBIF', 'VBIT', 'VMVN', 'VDUP', 'VCEQ'}
VFP_NAMES = {'VADD', 'VSUB', 'VMUL', 'VDIV', 'VMLA', 'VMLS', 'VNMLA', 'VNMLS', 'VNMUL', 'VNEG', 'VABS', 'VSQRT', 'VMOV', 'FCONSTS',
             'FCONSTD', 'VLDR', 'VSTR', 'VPUSH', 'VPOP', 'VSTMIA', 'VLDMIA', 'VSTMDB', 'VLDMDB', 'VCMP', 'VCMPE', 'VCVT',
             'FMSTAT', 'VMRS', 'VMSR'}
LDST = {'LDR': ('ld', 4, False), 'LDRB': ('ld', 1, False), 'LDRH': ('ld', 2, False),
        'LDRSB': ('ld', 1, True), 'LDRSH': ('ld', 2, True),
        'STR': ('st', 4, False), 'STRB': ('st', 1, False), 'STRH': ('st', 2, False)}


class Lifter:
    def __init__(self, text_vaddr, read, base_sym='MOD_B', relocs=None, seg_sym='MOD_SEG', arm=False):
        self.arm, self.pcoff = arm, (8 if arm else 4)               # ARM mode: pc reads as address+8, 4-byte instructions
        self.md = Cs(CS_ARCH_ARM, CS_MODE_ARM if arm else CS_MODE_THUMB)
        self.md.detail = True
        self.tv, self.read, self.B = text_vaddr, read, base_sym
        self.relocs, self.seg_sym, self.reloc_used = relocs or {}, seg_sym, set()
        self.call_targets = set()
        self.stats = {'ok': collections.Counter(), 'bad': collections.Counter()}
        self._dec = {}
        self._tables = {}

    # ---------- small helpers ----------
    def A(self, addr):                       # guest address expression of a module address
        return f"({self.B} + 0x{addr - self.tv:x}u)"

    def ri(self, reg):
        try:
            return REGIDX[self.md.reg_name(reg)]
        except KeyError:
            raise Unsupported('register ' + str(self.md.reg_name(reg)))

    def val(self, insn, op, aligned=False):
        i = self.ri(op.reg)
        if i == 15:
            e = self.A(insn.address + self.pcoff)
            return f"({e} & ~3u)" if aligned else e
        return f"x->r[{i}]"

    def setr(self, op, expr):
        i = self.ri(op.reg)
        if i == 15:
            raise Unsupported('write to pc')
        return f"x->r[{i}] = {expr};"

    def op2(self, insn, op):
        """-> (pre statements, value expr, carry var or None)"""
        if op.type == OP_IMM:
            return [], f"0x{op.imm & 0xffffffff:x}u", None
        if op.type != OP_REG:
            raise Unsupported('operand type')
        v = self.val(insn, op)
        st, sv = op.shift.type, op.shift.value
        if st == SFT['INVALID']:
            return [], v, None
        if st in SHIFTFN:
            return [f"uint32_t t2 = {SHIFTFN[st]}({v}, {sv}, &co);"], 't2', 'co'
        if st in SHIFTFN_REG:
            return [f"uint32_t t2 = {SHIFTFN_REG[st]}({v}, x->r[{self.ri(sv)}] & 0xffu, &co);"], 't2', 'co'
        raise Unsupported('shift type')

    def modimm_rotated(self, insn):
        b = insn.bytes
        if self.arm:
            return len(b) == 4 and ((int.from_bytes(bytes(b), 'little') >> 8) & 0xf) != 0
        if len(b) != 4:
            return False
        hw1, hw2 = b[0] | b[1] << 8, b[2] | b[3] << 8
        return bool(((hw1 >> 10) & 1) or ((hw2 >> 14) & 1))

    # ---------- instruction emitters: return (lines, terminal_if_unconditional) ----------
    def alu(self, insn, name):
        ops = insn.operands
        S = insn.update_flags
        if name in ('ADC', 'SBC'):
            S = insn.mnemonic.lower().startswith(name.lower() + 's')     # Capstone sets update_flags for the carry read
        if INSNAME.get(insn.id) == 'MOVS':
            S = True
        if name in ('MOV', 'MVN'):
            rd, a_op, o2 = ops[0], None, ops[1]
        elif name in NOWRITE:
            rd, a_op, o2, S = None, ops[0], ops[1], True
        elif len(ops) == 2:
            rd, a_op, o2 = ops[0], ops[0], ops[1]
        else:
            rd, a_op, o2 = ops[0], ops[1], ops[2]
        L = ['uint8_t co = x->c, vo = x->v; (void)vo;']
        pre, b, carry = self.op2(insn, o2)
        L += pre
        a = self.val(insn, a_op, aligned=(o2.type == OP_IMM)) if a_op is not None else '0'
        arith = name in ARITH
        L.append(f"uint32_t r = {(ARITH if arith else LOGIC)[name].format(a=a, b=b)};")
        if not arith and S and carry is None and o2.type == OP_IMM and self.modimm_rotated(insn):
            L.append(f"co = {(o2.imm >> 31) & 1};")
        if rd is not None and self.ri(rd.reg) == 15:
            if name != 'MOV' or S:
                raise Unsupported('write to pc')
            tgt = (o2.type == OP_REG and self.ri(o2.reg) == 14 and o2.shift.type == SFT['INVALID'])
            return L + (['return;'] if tgt else ['vrt_call(x, r); return;']), True
        if rd is not None:
            L.append(self.setr(rd, 'r'))
        if S:
            L += ['x->n = r >> 31;', 'x->z = (r == 0);', 'x->c = co;']
            if arith:
                L.append('x->v = vo;')
        return L, False

    def shift(self, insn, name):
        ops = insn.operands
        if len(ops) == 3:
            rd, rm, amt = ops
        else:
            rd = rm = ops[0]
            amt = ops[1]
        fn = {'LSL': 'vrt_lsl', 'LSR': 'vrt_lsr', 'ASR': 'vrt_asr', 'ROR': 'vrt_ror', 'RRX': 'vrt_rrx'}[name]
        n = str(amt.imm) if amt.type == OP_IMM else f"(x->r[{self.ri(amt.reg)}] & 0xffu)"
        L = ['uint8_t co = x->c;', f"uint32_t r = {fn}({self.val(insn, rm)}, {n}, &co);", self.setr(rd, 'r')]
        if insn.update_flags:
            L += ['x->n = r >> 31;', 'x->z = (r == 0);', 'x->c = co;']
        return L, False

    def mul(self, insn, name):
        ops = insn.operands
        g = lambda o: self.val(insn, o)
        if name in ('MUL', 'MLA', 'MLS'):
            if name == 'MUL' and len(ops) == 2:
                ops = [ops[0], ops[0], ops[1]]
            p = f"{g(ops[1])} * {g(ops[2])}"
            if name == 'MUL':
                e = p
            elif name == 'MLA':
                e = f"{p} + {g(ops[3])}"
            else:
                e = f"{g(ops[3])} - ({p})"
            L = [f"uint32_t r = {e};", self.setr(ops[0], 'r')]
            if insn.update_flags:
                L += ['x->n = r >> 31;', 'x->z = (r == 0);']
            return L, False
        lo, hi, a, b = ops[0], ops[1], ops[2], ops[3]
        signed = name.startswith('S')
        ta, tb = ('(int64_t)(int32_t)', '(int64_t)(int32_t)') if signed else ('(uint64_t)', '(uint64_t)')
        L = [f"uint64_t p = (uint64_t)({ta}{g(a)} * {tb}{g(b)});"]
        if name in ('UMLAL', 'SMLAL'):
            L.append(f"p += ((uint64_t){g(hi)} << 32) | {g(lo)};")
        L += [self.setr(lo, '(uint32_t)p'), self.setr(hi, '(uint32_t)(p >> 32)')]
        if insn.update_flags:
            L += ['x->n = (uint32_t)(p >> 63);', 'x->z = (p == 0);']
        return L, False

    def unary(self, insn, name):
        ops = insn.operands
        v = self.val(insn, ops[1])
        if name in ('UXTB', 'UXTH', 'SXTB', 'SXTH'):
            rot = 0
            if ops[1].shift.type == SFT['ROR']:
                rot = ops[1].shift.value
            elif len(ops) > 2 and ops[2].type == OP_IMM:
                rot = ops[2].imm
            if rot:
                v = f"vrt_ror_nc({v}, {rot})"
        e = {'UXTB': f"({v}) & 0xffu", 'UXTH': f"({v}) & 0xffffu", 'SXTB': f"vrt_sx8({v})", 'SXTH': f"vrt_sx16({v})",
             'REV': f"vrt_rev({v})", 'REV16': f"vrt_rev16({v})", 'REVSH': f"vrt_revsh({v})",
             'RBIT': f"vrt_rbit({v})", 'CLZ': f"vrt_clz({v})"}[name]
        return [self.setr(ops[0], e)], False

    def bitfield(self, insn, name):
        ops = insn.operands
        if name == 'BFC':
            rd, lsb, w = ops[0], ops[1].imm, ops[2].imm
            m = ((1 << w) - 1) << lsb
            return [self.setr(rd, f"{self.val(insn, rd)} & 0x{(~m) & 0xffffffff:x}u")], False
        rd, rn, lsb, w = ops[0], ops[1], ops[2].imm, ops[3].imm
        m = ((1 << w) - 1)
        v = self.val(insn, rn)
        if name == 'UBFX':
            e = f"({v} >> {lsb}) & 0x{m:x}u"
        elif name == 'SBFX':
            e = f"(uint32_t)((int32_t)({v} << {32 - lsb - w}) >> {32 - w})"
        else:  # BFI
            e = f"({self.val(insn, rd)} & 0x{(~(m << lsb)) & 0xffffffff:x}u) | (({v} & 0x{m:x}u) << {lsb})"
        return [self.setr(rd, e)], False

    def mem_addr(self, insn, ops, mi):
        """-> (addr expr, writeback statement or None). ops[mi] is the memory operand."""
        mem = ops[mi].mem
        base = self.ri(mem.base)
        bexpr = f"({self.A(insn.address + self.pcoff)} & ~3u)" if base == 15 else f"x->r[{base}]"
        post = ops[mi + 1] if mi + 1 < len(ops) else None
        if post is not None:                                       # post-indexed
            if post.type == OP_IMM:
                off = f"0x{post.imm & 0xffffffff:x}u"
            else:
                off = f"x->r[{self.ri(post.reg)}]"
                if post.shift.type == SFT['LSL']:
                    off = f"({off} << {post.shift.value})"
            sign = '-' if getattr(post, 'subtracted', False) else '+'
            return bexpr, f"x->r[{base}] = x->r[{base}] {sign} {off};"
        if mem.index:
            off = f"x->r[{self.ri(mem.index)}]"
            sh = getattr(mem, 'lshift', 0) or (ops[mi].shift.value if ops[mi].shift.type == SFT['LSL'] else 0)
            if sh:
                off = f"({off} << {sh})"
            sign = '-' if (getattr(mem, 'scale', 1) < 0 or getattr(ops[mi], 'subtracted', False)) else '+'
            addr = f"({bexpr} {sign} {off})"
        else:
            addr = f"({bexpr} + 0x{mem.disp & 0xffffffff:x}u)"
        wb = f"x->r[{base}] = a;" if insn.writeback else None
        return addr, wb

    def ldst(self, insn, name):
        kind, size, signed = LDST[name]
        ops = insn.operands
        mi = next(i for i, o in enumerate(ops) if o.type == OP_MEM)
        addr, wb = self.mem_addr(insn, ops, mi)
        rt = ops[0]
        if self.ri(rt.reg) == 15:
            raise Unsupported('ldr pc')
        L = [f"uint32_t a = {addr};"]
        if kind == 'ld':
            e = f"vrt_ld{size * 8}(a)"
            if signed:
                e = f"vrt_sx{size * 8}({e})"
            L.append(f"uint32_t v = {e};")
            if wb:
                L.append(wb)
            L.append(self.setr(rt, 'v'))                    # load result wins if rt == base
        else:
            L.append(f"uint32_t v = {self.val(insn, rt)};")
            L.append(f"vrt_st{size * 8}(a, v);")
            if wb:
                L.append(wb)
        return L, False

    def ldstd(self, insn, name):
        ops = insn.operands
        mi = next(i for i, o in enumerate(ops) if o.type == OP_MEM)
        addr, wb = self.mem_addr(insn, ops, mi)
        L = [f"uint32_t a = {addr};"]
        if name == 'LDRD':
            L += ['uint32_t v0 = vrt_ld32(a), v1 = vrt_ld32(a + 4);']
            if wb:
                L.append(wb)
            L += [self.setr(ops[0], 'v0'), self.setr(ops[1], 'v1')]
        else:
            L += [f"uint32_t v0 = {self.val(insn, ops[0])}, v1 = {self.val(insn, ops[1])};",
                  'vrt_st32(a, v0); vrt_st32(a + 4, v1);']
            if wb:
                L.append(wb)
        return L, False

    def block(self, insn, name):
        ops = insn.operands
        if name in ('PUSH', 'POP'):
            regs = [self.ri(o.reg) for o in ops]
            base, wb = 13, True
            kind = 'st' if name == 'PUSH' else 'ld'
            down = name == 'PUSH'
        else:
            base = self.ri(ops[0].reg)
            regs = [self.ri(o.reg) for o in ops[1:]]
            wb = insn.writeback
            kind = 'ld' if name.startswith('LDM') else 'st'
            down = name.endswith('DB')
        n = len(regs)
        L = [f"uint32_t a = x->r[{base}]{f' - {4 * n}u' if down else ''};"]
        ret = False
        for k, r in enumerate(sorted(regs)):
            if kind == 'st':
                L.append(f"vrt_st32(a + {4 * k}u, {self.A(insn.address + self.pcoff) if r == 15 else f'x->r[{r}]'});")
            elif r == 15:
                L.append(f"(void)vrt_ld32(a + {4 * k}u);")
                ret = True
            else:
                L.append(f"x->r[{r}] = vrt_ld32(a + {4 * k}u);")
        if wb and not (kind == 'ld' and base in regs):
            L.append(f"x->r[{base}] = " + (f"a;" if down else f"x->r[{base}] + {4 * n}u;"))
        if ret:
            L.append('return;')
        return L, ret

    def branch(self, insn, name):
        ops = insn.operands
        nxt = insn.address + insn.size
        arm = self.arm
        tm = '' if arm else ' | 1u'                        # B/BL stay in the current instruction set
        lr = f"{self.A(nxt)}" if arm else f"{self.A(nxt)} | 1u"
        if name in ('B', 'CBZ', 'CBNZ'):
            t = ops[-1].imm & 0xffffffff
            if t not in self._dec:
                self.call_targets.add(t if arm else (t | 1))
            go = f"goto L_{t:x};" if t in self._dec else f"{{ vrt_call(x, {self.A(t)}{tm}); return; }}"
            if name == 'B':
                return [go], True
            tst = f"x->r[{self.ri(ops[0].reg)}] {'==' if name == 'CBZ' else '!='} 0"
            return [f"if ({tst}) {go}"], False
        if name == 'BL':
            t = ops[0].imm & 0xffffffff
            self.call_targets.add(t if arm else (t | 1))
            return [f"x->r[14] = {lr};", f"vrt_call(x, {self.A(t)}{tm});"], False
        if name == 'BLX':
            L = [f"x->r[14] = {lr};"]
            if ops[0].type == OP_IMM:                     # exchanges instruction set
                t = ops[0].imm & 0xffffffff
                if arm:
                    self.call_targets.add(t | 1)
                    L.append(f"vrt_call(x, {self.A(t)} | 1u);")
                else:
                    self.call_targets.add(t & 0xfffffffe)
                    L.append(f"vrt_call(x, {self.A(t & 0xfffffffe)});")
            else:
                L.append(f"vrt_call(x, x->r[{self.ri(ops[0].reg)}]);")
            return L, False
        if name == 'BX':
            r = self.ri(ops[0].reg)
            return (['return;'] if r == 14 else [f"vrt_call(x, x->r[{r}]); return;"]), True
        raise Unsupported(name)

    def extadd(self, insn, name):
        ops = insn.operands
        rot = ops[2].shift.value if len(ops) > 2 and ops[2].shift.type == SFT['ROR'] else 0
        v = self.val(insn, ops[2])
        if rot:
            v = f"vrt_ror_nc({v}, {rot})"
        e = {'UXTAB': f"({v}) & 0xffu", 'UXTAH': f"({v}) & 0xffffu", 'SXTAB': f"vrt_sx8({v})", 'SXTAH': f"vrt_sx16({v})"}[name]
        return [self.setr(ops[0], f"{self.val(insn, ops[1])} + ({e})")], False

    def excl(self, insn, name):
        ops = insn.operands
        mi = next(i for i, o in enumerate(ops) if o.type == OP_MEM)
        addr, _ = self.mem_addr(insn, ops, mi)
        bits = {'B': 8, 'H': 16, 'D': 64}.get(name[-1], 32) if name not in ('LDREX', 'STREX') else 32
        L = [f"uint32_t a = {addr};"]
        if name.startswith('LDREX'):
            if bits == 64:
                L += ['uint64_t v = vrt_ldrex64(x, a);', self.setr(ops[0], '(uint32_t)v'), self.setr(ops[1], '(uint32_t)(v >> 32)')]
            else:
                L += [f"uint32_t v = vrt_ldrex{bits}(x, a);", self.setr(ops[0], 'v')]
        else:
            if bits == 64:
                nv = f"((uint64_t){self.val(insn, ops[2])} << 32) | {self.val(insn, ops[1])}"
                L += [f"uint32_t s = vrt_strex64(x, a, {nv});", self.setr(ops[0], 's')]
            else:
                L += [f"uint32_t s = vrt_strex{bits}(x, a, {self.val(insn, ops[1])});", self.setr(ops[0], 's')]
        return L, False

    def table_targets(self, insn, dec, lo, hi):
        """Entries of a TBB/TBH jump table (pc-relative). Count from the preceding `cmp idx, #N`, else heuristic scan."""
        name = INSNAME.get(insn.id)
        mem = insn.operands[0].mem
        if self.ri(mem.base) != 15:
            raise Unsupported(name)
        esz = 1 if name == 'TBB' else 2
        tbl = insn.address + 4
        count = None
        for a in sorted((k for k in dec if k < insn.address), reverse=True)[:12]:
            p = dec[a]
            if (INSNAME.get(p.id) == 'CMP' and len(p.operands) == 2 and p.operands[0].type == OP_REG
                    and p.operands[0].reg == mem.index and p.operands[1].type == OP_IMM):
                count = p.operands[1].imm + 1
                break
        try:
            data = self.read(tbl, 1024 * esz)
        except Exception:
            data = b''
        ent = lambda k: data[k] if esz == 1 else data[2 * k] | (data[2 * k + 1] << 8)
        out = []
        if count is not None and 0 < count <= 1024:
            out = [tbl + 2 * ent(k) for k in range(min(count, len(data) // esz))]
        else:                                                   # heuristic: stop at first target outside the function
            for k in range(min(512, len(data) // esz)):
                t = tbl + 2 * ent(k)
                if not (insn.address < t < hi):
                    break
                out.append(t)
        out = [t for t in out if lo <= t < hi]
        if not out:
            raise Unsupported(name)
        return out

    def tbl(self, insn, name):
        tg = self._tables.get(insn.address)
        if not tg or any(t not in self._dec for t in tg):
            raise Unsupported(name)
        idx = f"x->r[{self.ri(insn.operands[0].mem.index)}]"
        L = [f"switch ({idx}) {{"] + [f"  case {k}: goto L_{t:x};" for k, t in enumerate(tg)]
        L += [f'  default: vrt_fatal("jump table index out of range at 0x%x", {self.A(insn.address)});', '}']
        return L, True

    # ---- VFP (scalar) ----
    def vk(self, op):
        nm = self.md.reg_name(op.reg)
        if len(nm) > 1 and nm[0] in 'sdq' and nm[1:].isdigit():
            return nm[0], int(nm[1:])
        try:
            return 'core', self.ri(op.reg)
        except Unsupported:
            return 'other', -1

    def V(self, op):
        k, n = self.vk(op)
        if k not in ('s', 'd'):
            raise Unsupported('neon-or-core')
        return k, n

    @staticmethod
    def vx(k, n):
        return f"x->s.f[{n}]" if k == 's' else f"x->s.d[{n}]"

    @staticmethod
    def fplit(v, k):
        import math, struct
        if v != v:
            return "__builtin_nanf(\"\")" if k == 's' else "__builtin_nan(\"\")"
        if math.isinf(v):
            return ("-" if v < 0 else "") + ("__builtin_inff()" if k == 's' else "__builtin_inf()")
        return float(v).hex() + ("f" if k == 's' else "")

    def vfp(self, insn, name):
        ops = insn.operands
        mn = insn.mnemonic.lower()
        FP = getattr(K, 'ARM_OP_FP', None)
        sfx = mn.split('.')[-1]
        first = self.vk(ops[0]) if ops and ops[0].type == OP_REG else None
        if name in ('VMUL', 'VMLA', 'VMLS') and first and first[0] in ('d', 'q') and ops and _lane(ops[-1]) != -1 and sfx == 'f32':
            return self.vec_f32_scalar(insn, name)
        if name in ('VADD', 'VSUB', 'VMUL', 'VMLA', 'VMLS', 'VNEG', 'VABS') and first and (first[0] == 'q' or (first[0] == 'd' and sfx in ('f32', 'i8', 'i16', 'i32', 'i64'))):
            if sfx == 'f32':
                return self.vec_f32(insn, name)
            if sfx in ('i8', 'i16', 'i32', 'i64') and name in ('VADD', 'VSUB', 'VMUL'):
                return self.vec_int(insn, name, int(sfx[1:]))
            raise Unsupported(name + '-neon')
        if name == 'VMOV' and first and (first[0] == 'q' or sfx.startswith('i') or (first[0] == 'd' and len(ops) == 2 and ops[1].type == FP and sfx == 'f32')):
            return self.vmov_neon(insn)
        if name in ('VADD', 'VSUB', 'VMUL', 'VDIV'):
            (k, d), (_, n), (_, m) = self.V(ops[0]), self.V(ops[1]), self.V(ops[2])
            op = {'VADD': '+', 'VSUB': '-', 'VMUL': '*', 'VDIV': '/'}[name]
            return [f"{self.vx(k, d)} = {self.vx(k, n)} {op} {self.vx(k, m)};"], False
        if name in ('VMLA', 'VMLS', 'VNMLA', 'VNMLS', 'VNMUL'):
            (k, d), (_, n), (_, m) = self.V(ops[0]), self.V(ops[1]), self.V(ops[2])
            ty = 'float' if k == 's' else 'double'
            D = self.vx(k, d)
            e = {'VMLA': f"{D} + p", 'VMLS': f"{D} + (-p)", 'VNMLA': f"(-{D}) + (-p)", 'VNMLS': f"(-{D}) + p", 'VNMUL': "-p"}[name]
            return [f"{ty} p = {self.vx(k, n)} * {self.vx(k, m)};", f"{D} = {e};"], False
        if name in ('VNEG', 'VABS', 'VSQRT'):
            (k, d), (_, m) = self.V(ops[0]), self.V(ops[1])
            f = {'VNEG': '-', 'VABS': '__builtin_fabsf' if k == 's' else '__builtin_fabs',
                 'VSQRT': '__builtin_sqrtf' if k == 's' else '__builtin_sqrt'}[name]
            return [f"{self.vx(k, d)} = {f}({self.vx(k, m)});"], False
        if name in ('VMOV', 'FCONSTS', 'FCONSTD'):
            if len(ops) == 2:
                a, b = ops
                if b.type == FP or b.type == OP_IMM:
                    k, d = self.V(a)
                    v = b.fp if b.type == FP else float(b.imm)
                    return [f"{self.vx(k, d)} = {self.fplit(v, k)};"], False
                ka, na = self.vk(a); kb, nb = self.vk(b)
                if ka in ('s', 'd') and ka == kb:
                    return [f"{self.vx(ka, na)} = {self.vx(kb, nb)};"], False
                if ka == 'core' and kb == 's':
                    return [self.setr(a, f"vrt_f2bits(x->s.f[{nb}])")], False
                if ka == 's' and kb == 'core':
                    return [f"x->s.f[{na}] = vrt_bits2f({self.val(insn, b)});"], False
            if len(ops) == 3:
                ka, kb, kc = self.vk(ops[0]), self.vk(ops[1]), self.vk(ops[2])
                if ka[0] == 'core' and kb[0] == 'core' and kc[0] == 'd':
                    return [f"uint64_t t = x->s.u64[{kc[1]}];", self.setr(ops[0], '(uint32_t)t'), self.setr(ops[1], '(uint32_t)(t >> 32)')], False
                if ka[0] == 'd' and kb[0] == 'core' and kc[0] == 'core':
                    return [f"x->s.u64[{ka[1]}] = ((uint64_t){self.val(insn, ops[2])} << 32) | {self.val(insn, ops[1])};"], False
            raise Unsupported(name)
        if name in ('VLDR', 'VSTR'):
            k, n = self.V(ops[0])
            addr, wb = self.mem_addr(insn, ops, 1)
            sz = 4 if k == 's' else 8
            lv = self.vx(k, n)
            L = [f"uint32_t a = {addr};"]
            L.append(f"memcpy(&{lv}, vrt_mem + a, {sz});" if name == 'VLDR' else f"memcpy(vrt_mem + a, &{lv}, {sz});")
            return L, False
        if name in ('VPUSH', 'VPOP', 'VSTMIA', 'VLDMIA', 'VSTMDB', 'VLDMDB'):
            rl = ops if name in ('VPUSH', 'VPOP') else ops[1:]
            regs = [self.V(o) for o in rl]
            sz = 4 if regs[0][0] == 's' else 8
            base = 13 if name in ('VPUSH', 'VPOP') else self.ri(ops[0].reg)
            down = name in ('VPUSH', 'VSTMDB', 'VLDMDB')
            total = sz * len(regs)
            L = [f"uint32_t a = x->r[{base}]{f' - {total}u' if down else ''};"]
            load = name in ('VPOP', 'VLDMIA', 'VLDMDB')
            for i, (k, n) in enumerate(regs):
                lv = self.vx(k, n)
                L.append(f"memcpy(&{lv}, vrt_mem + a + {i * sz}u, {sz});" if load else f"memcpy(vrt_mem + a + {i * sz}u, &{lv}, {sz});")
            if name in ('VPUSH', 'VPOP') or insn.writeback:
                L.append(f"x->r[{base}] = " + ("a;" if down else f"x->r[{base}] + {total}u;"))
            return L, False
        if name in ('VCMP', 'VCMPE'):
            k, a = self.V(ops[0])
            if ops[1].type == FP or ops[1].type == OP_IMM:
                b = self.fplit(ops[1].fp if ops[1].type == FP else float(ops[1].imm), k)
            else:
                kb, nb = self.V(ops[1]); b = self.vx(kb, nb)
            return [f"vrt_fcmp{32 if k == 's' else 64}(x, {self.vx(k, a)}, {b});"], False
        if name == 'VCVT':
            parts = mn.split('.')
            if len(parts) != 3 or len(ops) != 2:
                raise Unsupported(name)
            dst, src = parts[1], parts[2]
            (kd, d), (ks, m) = self.V(ops[0]), self.V(ops[1])
            if dst in ('f32', 'f64') and src in ('s32', 'u32'):
                ct = 'int32_t' if src == 's32' else 'uint32_t'
                return [f"{ct} i; memcpy(&i, &x->s.f[{m}], 4);", f"{self.vx(kd, d)} = ({'float' if dst == 'f32' else 'double'})i;"], False
            if dst in ('s32', 'u32') and src in ('f32', 'f64'):
                fn = {('s32', 'f32'): 'vrt_f2s', ('u32', 'f32'): 'vrt_f2u', ('s32', 'f64'): 'vrt_d2s', ('u32', 'f64'): 'vrt_d2u'}[(dst, src)]
                return [f"uint32_t t = {fn}({self.vx(ks, m)});", f"memcpy(&x->s.f[{d}], &t, 4);"], False
            if (dst, src) == ('f64', 'f32'):
                return [f"x->s.d[{d}] = (double)x->s.f[{m}];"], False
            if (dst, src) == ('f32', 'f64'):
                return [f"x->s.f[{d}] = (float)x->s.d[{m}];"], False
            raise Unsupported(name)
        if name == 'FMSTAT':
            return ['x->n = (x->fpscr >> 31) & 1; x->z = (x->fpscr >> 30) & 1; x->c = (x->fpscr >> 29) & 1; x->v = (x->fpscr >> 28) & 1;'], False
        if name == 'VMRS':
            if 'apsr' in self.md.reg_name(ops[0].reg):
                return self.vfp(insn, 'FMSTAT')
            return [self.setr(ops[0], 'x->fpscr')], False
        if name == 'VMSR':
            return [f"x->fpscr = {self.val(insn, ops[-1])};"], False
        raise Unsupported(name)


    # ---- NEON (subset) ----
    def vec_f32(self, insn, name):
        """lane-wise .f32 on D (2 lanes) / Q (4 lanes) registers; NEON flushes denormals and uses the default NaN"""
        ops = insn.operands
        ks = [self.vk(o) if o.type == OP_REG else ('x', 0) for o in ops]
        if any(o.type != OP_REG or _lane(o) != -1 for o in ops) or any(k[0] not in ('d', 'q') for k in ks):
            raise Unsupported('neon-f32')
        lanes = 2 if ks[0][0] == 'd' else 4
        F = lambda k, i: f"x->s.f[{(2 if k[0] == 'd' else 4) * k[1] + i}]"
        L = []
        for i in range(lanes):
            d = F(ks[0], i)
            if name == 'VNEG':
                L.append(f"{d} = -{F(ks[1], i)};")
            elif name == 'VABS':
                L.append(f"{d} = __builtin_fabsf({F(ks[1], i)});")
            elif name in ('VADD', 'VSUB', 'VMUL'):
                op = {'VADD': '+', 'VSUB': '-', 'VMUL': '*'}[name]
                L.append(f"{d} = vrt_nres(vrt_nf({F(ks[1], i)}) {op} vrt_nf({F(ks[2], i)}));")
            elif name in ('VMLA', 'VMLS'):
                op = '+' if name == 'VMLA' else '-'
                L.append(f"{{ float p = vrt_nres(vrt_nf({F(ks[1], i)}) * vrt_nf({F(ks[2], i)})); {d} = vrt_nres(vrt_nf({d}) {op} p); }}")
            else:
                raise Unsupported(name)
        return L, False

    def vec_int(self, insn, name, bits):
        ops = insn.operands
        ks = [self.vk(o) for o in ops]
        if len(ops) != 3 or any(o.type != OP_REG or _lane(o) != -1 for o in ops) or any(k[0] not in ('d', 'q') for k in ks):
            raise Unsupported(name + '-neon-int')
        fn = {'VADD': 'vrt_vadd', 'VSUB': 'vrt_vsub', 'VMUL': 'vrt_vmul'}[name]
        return [f"{d} = {fn}({n}, {m}, {bits});" for d, n, m in zip(self.U(ks[0]), self.U(ks[1]), self.U(ks[2]))], False

    def vec_f32_scalar(self, insn, name):
        ops = insn.operands
        ks = [self.vk(o) for o in ops]
        if len(ops) != 3 or ks[2][0] != 'd' or ks[0][0] not in ('d', 'q') or ks[1][0] != ks[0][0]:
            raise Unsupported(name + '-scalar')
        lanes = 2 if ks[0][0] == 'd' else 4
        F = lambda k, i: f"x->s.f[{(2 if k[0] == 'd' else 4) * k[1] + i}]"
        sc = f"vrt_nf(x->s.f[{2 * ks[2][1] + _lane(ops[2])}])"
        L = []
        for i in range(lanes):
            d, n = F(ks[0], i), F(ks[1], i)
            if name == 'VMUL':
                L.append(f"{d} = vrt_nres(vrt_nf({n}) * {sc});")
            else:
                op = '+' if name == 'VMLA' else '-'
                L.append(f"{{ float p = vrt_nres(vrt_nf({n}) * {sc}); {d} = vrt_nres(vrt_nf({d}) {op} p); }}")
        return L, False

    @staticmethod
    def rep(v, bits):
        v &= (1 << bits) - 1
        r = 0
        for s_ in range(0, 64, bits):
            r |= v << s_
        return r

    def U(self, k):
        if k[0] == 'd':
            return [f"x->s.u64[{k[1]}]"]
        if k[0] == 'q':
            return [f"x->s.u64[{2 * k[1]}]", f"x->s.u64[{2 * k[1] + 1}]"]
        raise Unsupported('neon-reg')

    def neon(self, insn, name):
        ops = insn.operands
        mn = insn.mnemonic.lower().split('.')
        suf = mn[1] if len(mn) > 1 else ''
        digits = ''.join(ch for ch in suf if ch.isdigit())
        bits = int(digits) if digits else 64
        FP = getattr(K, 'ARM_OP_FP', None)
        if name != 'VDUP' and any(o.type == OP_REG and _lane(o) != -1 for o in ops):
            raise Unsupported(name + '-lane')
        ks = [self.vk(o) if o.type == OP_REG else None for o in ops]
        if ks[0] is None or ks[0][0] not in ('d', 'q'):
            raise Unsupported(name)
        D = self.U(ks[0])
        L = []
        if name == 'VDUP' and len(ops) == 2 and ops[1].type == OP_REG and ks[1][0] == 'd' and _lane(ops[1]) != -1:
            v = f"(uint32_t)(x->s.u64[{ks[1][1]}] >> {_lane(ops[1]) * bits})"
            return [f"uint64_t t = vrt_dup({v}, {bits});"] + [f"{u} = t;" for u in D], False
        imm = ops[1] if len(ops) == 2 and ops[1].type in (OP_IMM, FP) else None
        if name == 'VDUP':
            if ops[1].type != OP_REG or ks[1][0] != 'core':
                raise Unsupported('VDUP-scalar')
            L += [f"uint64_t t = vrt_dup({self.val(insn, ops[1])}, {bits});"] + [f"{u} = t;" for u in D]
            return L, False
        if name == 'VMVN' and imm is not None:
            L += [f"{u} = ~0x{self.rep(imm.imm, bits):x}ull;" for u in D]
            return L, False
        if name in ('VORR', 'VBIC') and imm is not None:
            op = '|=' if name == 'VORR' else '&= ~'
            L += [f"{u} {op} 0x{self.rep(imm.imm, bits):x}ull;" for u in D]
            return L, False
        if len(ops) == 2 and name == 'VMVN':
            return [f"{u} = ~{v};" for u, v in zip(D, self.U(ks[1]))], False
        if len(ops) != 3 or ks[1] is None or ks[2] is None and not (name == 'VCEQ' and ops[2].type == OP_IMM):
            raise Unsupported(name)
        N = self.U(ks[1])
        if name == 'VCEQ':
            for i, u in enumerate(D):
                if ops[2].type == OP_IMM:
                    b = '0ull'
                else:
                    b = self.U(ks[2])[i]
                fn = 'vrt_vceq_f(%s, %s)' % (N[i], b) if suf.startswith('f') else 'vrt_vceq_i(%s, %s, %d)' % (N[i], b, bits)
                L.append(f"{u} = {fn};")
            return L, False
        M = self.U(ks[2])
        for u, n, m in zip(D, N, M):
            e = {'VORR': f"{n} | {m}", 'VAND': f"{n} & {m}", 'VBIC': f"{n} & ~{m}", 'VEOR': f"{n} ^ {m}",
                 'VBSL': f"({u} & {n}) | (~{u} & {m})", 'VBIF': f"({u} & {m}) | ({n} & ~{m})",
                 'VBIT': f"({u} & ~{m}) | ({n} & {m})"}[name]
            L.append(f"{u} = {e};")
        return L, False

    def vmov_neon(self, insn):
        ops = insn.operands
        mn = insn.mnemonic.lower().split('.')
        suf = mn[1] if len(mn) > 1 else ''
        FP = getattr(K, 'ARM_OP_FP', None)
        if len(ops) != 2 or ops[0].type != OP_REG:
            raise Unsupported('VMOV-neon')
        k = self.vk(ops[0])
        if k[0] not in ('d', 'q'):
            raise Unsupported('VMOV-neon')
        D = self.U(k)
        if ops[1].type == OP_IMM:
            bits = int(''.join(ch for ch in suf if ch.isdigit()) or 64)
            return [f"{u} = 0x{self.rep(ops[1].imm, bits):x}ull;" for u in D], False
        if ops[1].type == FP:
            import struct
            fb = struct.unpack('<I', struct.pack('<f', ops[1].fp))[0]
            return [f"{u} = 0x{self.rep(fb, 32):x}ull;" for u in D], False
        k2 = self.vk(ops[1])
        if k2[0] == k[0]:
            return [f"{u} = {v};" for u, v in zip(D, self.U(k2))], False
        raise Unsupported('VMOV-neon')


    # ---- NEON: VLD1/VST1 and the widening / shifting / permuting integer family ----
    def Qx(self, n):
        return f"vrt_q128(x->s.u64[{2 * n}], x->s.u64[{2 * n + 1}])"

    def setQ(self, n, e):
        return f"{{ vrt_u128 t_ = {e}; x->s.u64[{2 * n}] = (uint64_t)t_; x->s.u64[{2 * n + 1}] = (uint64_t)(t_ >> 64); }}"

    def vldst1(self, insn, name):
        ops = insn.operands
        mi = next((i for i, o in enumerate(ops) if o.type == OP_MEM), None)
        if mi is None or mi == 0:
            raise Unsupported(name + '-shape')
        regs = [self.vk(o) for o in ops[:mi]]
        if any(k[0] != 'd' for k in regs):
            raise Unsupported(name + '-regs')
        mem = ops[mi].mem
        base = self.ri(mem.base)
        mn = insn.mnemonic.lower().split('.')
        bits = int(''.join(ch for ch in (mn[1] if len(mn) > 1 else '') if ch.isdigit()) or 64)
        lane = [_lane(o) for o in ops[:mi]]
        L = [f"uint32_t a = x->r[{base}];"]
        if any(l != -1 for l in lane):                                 # single element to/from one lane
            if len(regs) != 1:
                raise Unsupported(name + '-lane-multi')
            n, idx = regs[0][1], lane[0]
            mk, sh = f"0x{(1 << bits) - 1:x}ull", idx * bits
            if name == 'VLD1':
                L.append(f"x->s.u64[{n}] = (x->s.u64[{n}] & ~({mk} << {sh})) | ((uint64_t)vrt_ld{bits}(a) << {sh});")
            else:
                L.append(f"vrt_st{bits}(a, (uint32_t)((x->s.u64[{n}] >> {sh}) & {mk}));")
            total = bits // 8
        else:
            for i, (_, n) in enumerate(regs):
                L.append(f"memcpy(&x->s.u64[{n}], vrt_mem + a + {8 * i}u, 8);" if name == 'VLD1' else f"memcpy(vrt_mem + a + {8 * i}u, &x->s.u64[{n}], 8);")
            total = 8 * len(regs)
        post = ops[mi + 1] if mi + 1 < len(ops) else None
        if post is not None and post.type == OP_REG:
            L.append(f"x->r[{base}] += {self.val(insn, post)};")
        elif insn.writeback:
            L.append(f"x->r[{base}] += {total}u;")
        return L, False

    def neon2(self, insn, name):
        ops = insn.operands
        mn = insn.mnemonic.lower().split('.')
        suf = mn[1] if len(mn) > 1 else ''
        sgn = 1 if suf.startswith('s') else 0
        isf = suf.startswith('f')
        if suf.startswith('p') and not (name == 'VMULL' and suf == 'p8'):
            raise Unsupported(name + '-poly')
        bits = int(''.join(ch for ch in suf if ch.isdigit()) or 0)
        kind = lambda o: self.vk(o) if o.type == OP_REG else (None, None)
        ks = [kind(o) for o in ops]
        FPT = getattr(K, 'ARM_OP_FP', None)

        def units(k):
            if k[0] == 'd':
                return [f"x->s.u64[{k[1]}]"]
            if k[0] == 'q':
                return [f"x->s.u64[{2 * k[1]}]", f"x->s.u64[{2 * k[1] + 1}]"]
            raise Unsupported(name + '-reg')

        def elem(o, k):                                         # scalar operand d[idx] -> replicated D value
            return f"vrt_dup_el(x->s.u64[{k[1]}], {_lane(o)}, {bits})"

        if name in ('VMULL', 'VMLAL', 'VMLSL'):
            if ks[0][0] != 'q' or ks[1][0] != 'd' or bits not in (8, 16, 32):
                raise Unsupported(name + '-shape')
            a = f"x->s.u64[{ks[1][1]}]"
            b = elem(ops[2], ks[2]) if _lane(ops[2]) != -1 else f"x->s.u64[{ks[2][1]}]"
            prod = f"vrt_vmull_p8({a}, {b})" if suf == 'p8' else f"vrt_vmull128({a}, {b}, {bits}, {sgn})"
            e = {'VMULL': prod, 'VMLAL': f"vrt_wadd({self.Qx(ks[0][1])}, {prod}, {2 * bits})", 'VMLSL': f"vrt_wsub({self.Qx(ks[0][1])}, {prod}, {2 * bits})"}[name]
            return [self.setQ(ks[0][1], e)], False
        if name in ('VMOVL', 'VSHLL'):
            if ks[0][0] != 'q' or ks[1][0] != 'd' or bits not in (8, 16, 32):
                raise Unsupported(name + '-shape')
            shl = ops[2].imm if name == 'VSHLL' and len(ops) > 2 else 0
            return [self.setQ(ks[0][1], f"vrt_widen(x->s.u64[{ks[1][1]}], {bits}, {sgn}, {shl})")], False
        if name == 'VADDW':
            if ks[0][0] != 'q' or ks[1][0] != 'q' or ks[2][0] != 'd':
                raise Unsupported(name + '-shape')
            return [self.setQ(ks[0][1], f"vrt_wadd({self.Qx(ks[1][1])}, vrt_widen(x->s.u64[{ks[2][1]}], {bits}, {sgn}, 0), {2 * bits})")], False
        if name == 'VSHRN':
            if ks[0][0] != 'd' or ks[1][0] != 'q':
                raise Unsupported(name + '-shape')
            return [f"x->s.u64[{ks[0][1]}] = vrt_shrn({self.Qx(ks[1][1])}, {bits}, {ops[2].imm});"], False
        if name in ('VSHL', 'VSHR', 'VSLI'):
            D, M = units(ks[0]), units(ks[1])
            if len(ops) == 3 and ops[2].type == OP_IMM:
                imm = ops[2].imm
                f = {'VSHL': lambda d, m: f"vrt_shl_imm({m}, {bits}, {imm})", 'VSHR': lambda d, m: f"vrt_shr_imm({m}, {bits}, {imm}, {sgn})",
                     'VSLI': lambda d, m: f"vrt_sli({d}, {m}, {bits}, {imm})"}[name]
                return [f"{d} = {f(d, m)};" for d, m in zip(D, M)], False
            if name == 'VSHL' and len(ops) == 3 and ops[2].type == OP_REG:
                Nn = units(ks[2])
                return [f"{d} = vrt_shl_reg({m}, {n}, {bits}, {sgn});" for d, m, n in zip(D, M, Nn)], False
            raise Unsupported(name + '-form')
        if name == 'VPADD':
            if ks[0][0] != 'd' or len(ops) != 3:
                raise Unsupported(name + '-shape')
            a, b = f"x->s.u64[{ks[1][1]}]", f"x->s.u64[{ks[2][1]}]"
            if isf:
                return [f"{{ float lo = vrt_nres(vrt_nf(vrt_bits2f((uint32_t){a})) + vrt_nf(vrt_bits2f((uint32_t)({a} >> 32)))); "
                        f"float hi = vrt_nres(vrt_nf(vrt_bits2f((uint32_t){b})) + vrt_nf(vrt_bits2f((uint32_t)({b} >> 32)))); "
                        f"x->s.u64[{ks[0][1]}] = (uint64_t)vrt_f2bits(lo) | ((uint64_t)vrt_f2bits(hi) << 32); }}"], False
            return [f"x->s.u64[{ks[0][1]}] = vrt_vpadd({a}, {b}, {bits});"], False
        if name in ('VPADDL', 'VPADAL'):
            D, M = units(ks[0]), units(ks[1])
            if name == 'VPADDL':
                return [f"{d} = vrt_vpaddl({m}, {bits}, {sgn});" for d, m in zip(D, M)], False
            return [f"{d} = vrt_vpadal({d}, {m}, {bits}, {sgn});" for d, m in zip(D, M)], False
        if name in ('VUZP', 'VTRN'):
            if ks[0][0] != 'd' or ks[1][0] != 'd':
                raise Unsupported(name + '-q')
            fn = 'vrt_vuzp' if name == 'VUZP' else 'vrt_vtrn'
            return [f"{fn}(&x->s.u64[{ks[0][1]}], &x->s.u64[{ks[1][1]}], {bits});"], False
        if name in ('VREV16', 'VREV32', 'VREV64'):
            blk = int(name[4:])
            D, M = units(ks[0]), units(ks[1])
            return [f"{d} = vrt_vrev({m}, {bits}, {blk});" for d, m in zip(D, M)], False
        if name in ('VCLE', 'VCLT', 'VCGE', 'VCGT', 'VACGT', 'VACGE'):
            op = {'VCLE': 'VRT_LE', 'VCLT': 'VRT_LT', 'VCGE': 'VRT_GE', 'VCGT': 'VRT_GT', 'VACGT': 'VRT_GT', 'VACGE': 'VRT_GE'}[name]
            absolute = 1 if name.startswith('VAC') else 0
            D, N = units(ks[0]), units(ks[1])
            if len(ops) == 3 and ops[2].type in (OP_IMM, FPT):
                M = ['0ull'] * len(D)
            elif len(ops) == 3:
                M = units(ks[2])
            else:
                raise Unsupported(name + '-form')
            if isf or name.startswith('VAC'):
                return [f"{d} = vrt_vcmp_f({n}, {m}, {op}, {absolute});" for d, n, m in zip(D, N, M)], False
            return [f"{d} = vrt_vcmp_i({n}, {m}, {bits}, {op}, {sgn});" for d, n, m in zip(D, N, M)], False
        if name in ('VRECPE', 'VRSQRTE'):
            if suf != 'f32':
                raise Unsupported(name + '-int')
            fn = 'vrt_vrecpe_d' if name == 'VRECPE' else 'vrt_vrsqrte_d'
            return [f"{d} = {fn}({m});" for d, m in zip(units(ks[0]), units(ks[1]))], False
        if name in ('VRECPS', 'VRSQRTS'):
            fn = 'vrt_vrecps_d' if name == 'VRECPS' else 'vrt_vrsqrts_d'
            return [f"{d} = {fn}({n}, {m});" for d, n, m in zip(units(ks[0]), units(ks[1]), units(ks[2]))], False
        if name in ('VMAX', 'VMIN'):
            D, N, M = units(ks[0]), units(ks[1]), units(ks[2])
            mx = 1 if name == 'VMAX' else 0
            if isf:
                return [f"{d} = vrt_vmaxmin_f({n}, {m}, {mx});" for d, n, m in zip(D, N, M)], False
            return [f"{d} = vrt_vmaxmin_i({n}, {m}, {bits}, {sgn}, {mx});" for d, n, m in zip(D, N, M)], False
        raise Unsupported(name)

    def coproc(self, insn, name):
        import re
        m = re.match(r'p15,\s*#?0,\s*(\w+),\s*c13,\s*c0,\s*#?3$', insn.op_str.strip())
        if name == 'MRC' and m and m.group(1) in REGIDX and REGIDX[m.group(1)] < 15:
            return [f"x->r[{REGIDX[m.group(1)]}] = x->tls;"], False      # TPIDRURO = thread pointer
        raise Unsupported(name)

    def vcvt_half(self, insn, name):
        ops = insn.operands
        parts = insn.mnemonic.lower().split('.')
        if len(parts) != 3 or len(ops) != 2:
            raise Unsupported(name)
        (kd, d), (ks, m) = self.vk(ops[0]), self.vk(ops[1])
        if kd != 's' or ks != 's':
            raise Unsupported(name + '-f64')
        sh = 0 if name == 'VCVTB' else 16
        if parts[1] == 'f32' and parts[2] == 'f16':
            return [f"x->s.f[{d}] = vrt_h2f((uint16_t)(vrt_f2bits(x->s.f[{m}]) >> {sh}));"], False
        if parts[1] == 'f16' and parts[2] == 'f32':
            keep = '0xffff0000u' if sh == 0 else '0x0000ffffu'
            return [f"x->s.f[{d}] = vrt_bits2f((vrt_f2bits(x->s.f[{d}]) & {keep}) | ((uint32_t)vrt_f2h(x->s.f[{m}]) << {sh}));"], False
        raise Unsupported(name)

    def adr(self, insn):
        b = bytes(insn.bytes); rd = self.ri(insn.operands[0].reg)
        base = f"({self.A(insn.address + self.pcoff)} & ~3u)"
        if len(b) == 2:
            hw = b[0] | b[1] << 8
            return [f"x->r[{rd}] = {base} + {(hw & 0xff) * 4}u;"], False
        hw1, hw2 = b[0] | b[1] << 8, b[2] | b[3] << 8
        imm12 = (((hw1 >> 10) & 1) << 11) | (((hw2 >> 12) & 7) << 8) | (hw2 & 0xff)
        if hw1 & 0xFBFF == 0xF20F:
            return [f"x->r[{rd}] = {base} + {imm12}u;"], False
        if hw1 & 0xFBFF == 0xF2AF:
            return [f"x->r[{rd}] = {base} - {imm12}u;"], False
        raise Unsupported('ADR')

    def hint(self, insn):
        m = insn.mnemonic.lower().split('.')[0]
        if m in ('nop', 'yield', 'dbg', 'wfe', 'wfi', 'sev', 'sevl'):
            return [], False
        raise Unsupported('HINT')

    def emit(self, insn):
        name = {'ADDW': 'ADD', 'SUBW': 'SUB', 'MOVS': 'MOV'}.get(INSNAME.get(insn.id, insn.mnemonic), INSNAME.get(insn.id, insn.mnemonic))
        if name == 'MOV' and insn.mnemonic.lower().split('.')[0].startswith('movw'):
            name = 'MOVW'            # Capstone reports MOVW under the generic MOV id; relocated movw must take the MOVW path
        try:
            if name in ARITH or name in LOGIC:
                lines, term = self.alu(insn, name)
            elif name in ('LSL', 'LSR', 'ASR', 'ROR', 'RRX'):
                lines, term = self.shift(insn, name)
            elif name in ('MOVW', 'MOVT'):
                o = insn.operands
                rl = self.relocs.get(insn.address - self.tv)
                if rl is not None:                    # the loader patches this instruction: value = segment base + addend at RUNTIME
                    code, sym, addend = rl
                    if code != (47 if name == 'MOVW' else 48):
                        raise Unsupported('reloc-mismatch')
                    self.reloc_used.add(insn.address - self.tv)
                    val = f"0x{addend:x}u" if sym == 15 else f"({self.seg_sym}[{sym}] + 0x{addend:x}u)"
                    if name == 'MOVW':
                        lines = [self.setr(o[0], f"({val}) & 0xffffu")]
                    else:
                        lines = [self.setr(o[0], f"(x->r[{self.ri(o[0].reg)}] & 0xffffu) | (({val}) & 0xffff0000u)")]
                elif name == 'MOVW':
                    lines = [self.setr(o[0], f"0x{o[1].imm & 0xffff:x}u")]
                else:
                    lines = [self.setr(o[0], f"(x->r[{self.ri(o[0].reg)}] & 0xffffu) | 0x{(o[1].imm & 0xffff) << 16:x}u")]
                term = False
            elif name in ('MUL', 'MLA', 'MLS', 'UMULL', 'SMULL', 'UMLAL', 'SMLAL'):
                lines, term = self.mul(insn, name)
            elif name in ('UXTB', 'UXTH', 'SXTB', 'SXTH', 'REV', 'REV16', 'REVSH', 'RBIT', 'CLZ'):
                lines, term = self.unary(insn, name)
            elif name in ('UBFX', 'SBFX', 'BFI', 'BFC'):
                lines, term = self.bitfield(insn, name)
            elif name in LDST:
                lines, term = self.ldst(insn, name)
            elif name in ('LDRD', 'STRD'):
                lines, term = self.ldstd(insn, name)
            elif name in ('PUSH', 'POP', 'LDM', 'LDMIA', 'LDMDB', 'STM', 'STMIA', 'STMDB'):
                lines, term = self.block(insn, name)
            elif name in ('B', 'BL', 'BLX', 'BX', 'CBZ', 'CBNZ'):
                lines, term = self.branch(insn, name)
            elif name in ('NOP', 'IT'):
                lines, term = [], False
            elif name == 'HINT':
                lines, term = self.hint(insn)
            elif name in ('BKPT', 'UDF'):
                lines, term = [f'vrt_fatal("{name.lower()} executed at 0x%x", {self.A(insn.address)});'], True
            elif name in ('UXTAB', 'UXTAH', 'SXTAB', 'SXTAH'):
                lines, term = self.extadd(insn, name)
            elif name in ('LDREX', 'LDREXB', 'LDREXH', 'LDREXD', 'STREX', 'STREXB', 'STREXH', 'STREXD'):
                lines, term = self.excl(insn, name)
            elif name in ('TBB', 'TBH'):
                lines, term = self.tbl(insn, name)
            elif name in VFP_NAMES:
                lines, term = self.vfp(insn, name)
            elif name in NEON_NAMES:
                lines, term = self.neon(insn, name)
            elif name in ('VLD1', 'VST1'):
                lines, term = self.vldst1(insn, name)
            elif name in NEON2_NAMES:
                lines, term = self.neon2(insn, name)
            elif name in ('VCVTB', 'VCVTT'):
                lines, term = self.vcvt_half(insn, name)
            elif name == 'ADR':
                lines, term = self.adr(insn)
            elif name in ('PLD', 'PLDW', 'PLI'):
                lines, term = [], False
            elif name in ('MRC',):
                lines, term = self.coproc(insn, name)
            elif name in ('DMB', 'DSB', 'ISB'):
                lines, term = ['__sync_synchronize();'], False
            else:
                raise Unsupported(name)
        except (Unsupported, IndexError, KeyError, AttributeError, StopIteration) as e:
            key = name if (isinstance(e, Unsupported) and str(e) == name) else f"{name}!{str(e) or type(e).__name__}".replace(' ', '_')
            self.stats['bad'][key] += 1
            safe = ''.join(ch for ch in name if ch.isalnum() or ch == '_')
            return [f'vrt_fatal("unsupported insn %s at 0x%x", "{safe}", {self.A(insn.address)});'], False
        self.stats['ok'][name] += 1
        c = cond_c(insn.cc)
        if name != 'IT' and c and lines:
            lines = [f"if ({c}) {{"] + ['  ' + l for l in lines] + ['}']
            term = False
        return ['{'] + ['  ' + l for l in lines] + ['}'], term

    # ---------- function level ----------
    @staticmethod
    def is_terminal(insn):
        name = INSNAME.get(insn.id, '')
        if cond_c(insn.cc):
            return False
        if name in ('B', 'BX', 'TBB', 'TBH', 'BKPT', 'UDF'):
            return True
        if name in ('POP', 'LDM', 'LDMIA', 'LDMDB'):
            return any(o.type == OP_REG and o.reg == K.ARM_REG_PC for o in insn.operands)
        if name in ('LDR', 'MOV') and insn.operands and insn.operands[0].type == OP_REG:
            return insn.operands[0].reg == K.ARM_REG_PC
        return False

    def decode(self, lo, hi):
        buf = self.read(lo, hi - lo)
        dec, targets, work = {}, set(), [lo]
        self._tables = {}
        while work:
            a = work.pop()
            if a in dec or not (lo <= a < hi):
                continue
            for insn in self.md.disasm(buf[a - lo:], a):
                if insn.address in dec:
                    break
                dec[insn.address] = insn
                if INSNAME.get(insn.id) in ('B', 'CBZ', 'CBNZ') and insn.operands and insn.operands[-1].type == OP_IMM:
                    t = insn.operands[-1].imm & 0xffffffff
                    targets.add(t)
                    work.append(t)
                if INSNAME.get(insn.id) in ('TBB', 'TBH'):
                    try:
                        tg = self.table_targets(insn, dec, lo, hi)
                        self._tables[insn.address] = tg
                        targets.update(tg)
                        work.extend(tg)
                    except Unsupported:
                        pass
                if self.is_terminal(insn):
                    break
        return dec, targets

    def lift_function(self, start, end, name, single=False, storage=''):
        lo = start & ~1
        dec, targets = self.decode(lo, end)
        self._dec = dec
        out = [f"{storage}void {name}(vrt_ctx *x) {{"]
        for addr in sorted(dec):
            insn = dec[addr]
            if addr in targets:
                out.append(f"L_{addr:x}:;")
            lines, term = self.emit(insn)
            out += ['  ' + l for l in lines]
            if not term and addr + insn.size not in dec:
                out.append('  return;' if single else f'  vrt_fatal("ran off decoded code after 0x%x", {self.A(addr)});')
        if not dec:
            out.append('  vrt_fatal("nothing decoded");')
        out.append('}')
        return "\n".join(out)


# ------------------------------------------------------------------ CLI
def _load(app, patch):
    from prep import collect
    files = collect(app, 'app')
    if patch:
        files.update(collect(patch, 'patch'))
    return files

def _extra_starts(m):
    """Functions the exidx table lacks (tiny leaf routines): exported entry points and thumb code pointers stored in data."""
    from relocs import parse_relocs
    tv = m.loads[0].ph['vaddr']; te = tv + m.loads[0].ph['memsz']
    out = set()
    for lib in m.exports():
        for nid, addr in lib['funcs']:
            if tv <= (addr & ~1) < te:
                out.add(addr)
    for e in parse_relocs(m):
        if e['code'] == 2 and e['sym'] == 0:
            t = tv + e['addend']
            if (t & 1) and tv <= (t & ~1) < te:
                out.add(t)
    return out

def _functions(m, extra=()):
    st = sorted(set(m.function_starts()) | _extra_starts(m) | set(extra))
    code = next(s for s in m.loads if s.ph['flags'] & 1)
    top = code.ph['vaddr'] + len(code.data)
    res = []
    for i, s in enumerate(st):
        if not s & 1:
            continue
        end = (st[i + 1] & ~1) if i + 1 < len(st) else top
        if end > (s & ~1):
            res.append((s, end))
    return code, res

ARM_STUB = (0xE3E00000, 0xE12FFF1E, 0xE1A00000, 0x00000000)       # 16-byte import stub: mvn r0,#0 ; bx lr ; nop ; .word 0

def _is_import_stub(m, addr):
    try:
        return struct.unpack('<4I', m.read(addr, 16)) == ARM_STUB
    except Exception:
        return False

def _lift_all(m, lf, code, fns, name_of, storage=''):
    """Lift every Thumb function, then every call target the tables did not cover: Thumb targets found while decoding, and ARM-mode
    targets (blx imm / bl in ARM code) that are real code, not import stubs. Returns (list of (start, text), n_thumb_found, n_arm_lifted)."""
    out = [(s_, lf.lift_function(s_, e_, name_of(s_), storage=storage)) for s_, e_ in fns]
    lf_arm = Lifter(lf.tv, lf.read, relocs={}, seg_sym=lf.seg_sym, arm=True)
    known = {s_ for s_, _ in fns} | set(m.function_starts()) | _extra_starts(m)
    done = {s_ for s_, _ in fns}
    tv, te = code.ph['vaddr'], code.ph['vaddr'] + len(code.data)
    found = arm_done = 0
    allst = sorted(known)
    for _ in range(6):                                                  # fixpoint (normally 1-2 rounds)
        pending = {t for L in (lf, lf_arm) for t in L.call_targets if tv <= (t & ~1) < te and t not in done}
        pending = {t for t in pending if (t & 1) or not _is_import_stub(m, t)}
        if not pending:
            break
        for L in (lf, lf_arm):
            L.call_targets -= pending
        allst = sorted(known | pending | done)
        for t in sorted(pending):
            done.add(t); known.add(t)
            nxt = [x & ~1 for x in allst if (x & ~1) > (t & ~1)]
            end = nxt[0] if nxt else te
            if end <= (t & ~1):
                continue
            if t & 1:
                if t in {s_ for s_, _ in fns}:
                    continue
                out.append((t, lf.lift_function(t, end, name_of(t), storage=storage)))
                found += 1
            else:
                out.append((t, lf_arm.lift_function(t, end, name_of(t), storage=storage)))
                arm_done += 1
    for k in ('ok', 'bad'):                                             # one statistics object for callers
        lf.stats[k].update(lf_arm.stats[k])
    return out, found, arm_done

def _cov_worker(args):
    rel, path = args
    from vita_self import VitaModule
    m = VitaModule(path)
    from relocs import text_movwt_relocs
    code, fns = _functions(m)
    rl = text_movwt_relocs(m)
    lf = Lifter(code.ph['vaddr'], m.read, relocs=rl)
    _, found, arm = _lift_all(m, lf, code, fns, lambda s_: 'f')
    lf.stats['ok']['<reloc sites total>'] = len(rl)
    lf.stats['ok']['<reloc sites used>'] = len(lf.reloc_used)
    lf.stats['ok']['<call targets without a table entry: thumb>'] = found
    lf.stats['ok']['<call targets without a table entry: arm>'] = arm
    return rel, lf.stats, len(fns)

def cmd_coverage(a):
    files = _load(a.app, a.patch)
    todo = [(r, p) for r, (p, _) in sorted(files.items()) if not a.modules or any(k in r for k in a.modules.split(','))]
    ok, bad = collections.Counter(), collections.Counter()
    with multiprocessing.Pool(a.jobs) as pool:
        for rel, st, n in pool.imap_unordered(_cov_worker, todo):
            ok.update(st['ok']); bad.update(st['bad'])
            print(f"  {rel:40} functions={n:6} lifted={sum(st['ok'].values()):8} unsupported={sum(st['bad'].values()):7}", flush=True)
    f_t, f_a = ok.pop('<call targets without a table entry: thumb>', 0), ok.pop('<call targets without a table entry: arm>', 0)
    print(f"call targets missing from the function table: thumb {f_t} (lifted as extra functions); ARM-mode functions lifted: {f_a}")
    rs_total, rs_used = ok.pop('<reloc sites total>', 0), ok.pop('<reloc sites used>', 0)
    print(f"movw/movt relocation sites: {rs_used} of {rs_total} reached by lifted code ({100 * rs_used / max(1, rs_total):.2f}%; the rest are in unreachable/unlifted code)")
    t_ok, t_bad = sum(ok.values()), sum(bad.values())
    print(f"\nTOTAL instructions reached by recursive descent: {t_ok + t_bad}   lifted {t_ok} ({100 * t_ok / max(1, t_ok + t_bad):.2f}%)   unsupported {t_bad}")
    print("unsupported (top 60):", ", ".join(f"{k}:{v}" for k, v in bad.most_common(60)))
    print("supported (top 25):", ", ".join(f"{k}:{v}" for k, v in ok.most_common(25)))

def cmd_module(a):
    from vita_self import VitaModule
    files = _load(a.app, a.patch)
    rel = next(r for r in files if a.module in r)
    m = VitaModule(files[rel][0])
    from relocs import text_movwt_relocs
    code, fns = _functions(m)
    lf = Lifter(code.ph['vaddr'], m.read, relocs=text_movwt_relocs(m))
    os.makedirs(a.out, exist_ok=True)
    base = os.path.basename(rel).rsplit('.', 1)[0]
    parts = ['#include "vita_ops.h"', 'extern uint32_t MOD_SEG[4];   /* runtime base of each segment of this module (set by the loader) */',
             '#define MOD_B (MOD_SEG[0])', '']
    for s, e in fns:
        parts.append(lf.lift_function(s, e, f"f_{s & ~1:x}"))
    parts.append('\nvoid register_module(void) {')
    for s, e in fns:
        parts.append(f"  vrt_register((MOD_B + 0x{(s & ~1) - code.ph['vaddr']:x}u) | 1u, f_{s & ~1:x});")
    parts.append('}')
    path = os.path.join(a.out, base + '.c')
    open(path, 'w').write("\n".join(parts) + "\n")
    print(f"wrote {path}: {len(fns)} functions, lifted {sum(lf.stats['ok'].values())}, unsupported {sum(lf.stats['bad'].values())}")
    print("unsupported:", dict(lf.stats['bad'].most_common(30)))


def _emit_module(args):
    """-> (rel, idx, functions, ok, bad, reloc_used, reloc_total). Writes <out>/m<idx>.c with per-module (static) symbols."""
    rel, path, idx, out = args
    from vita_self import VitaModule
    from relocs import text_movwt_relocs
    m = VitaModule(path)
    code, fns = _functions(m)
    rl = text_movwt_relocs(m)
    seg = f"m{idx}_SEG"
    lf = Lifter(code.ph['vaddr'], m.read, relocs=rl, seg_sym=seg)
    parts = ['#include "vita_ops.h"', f'uint32_t {seg}[4];            /* runtime base of each segment of {rel} (set by the loader) */',
             f'#define MOD_B ({seg}[0])', '']
    lifted, found, arm = _lift_all(m, lf, code, fns, lambda s_: f"f_{s_ & ~1:x}", storage='static ')
    parts += [t for _, t in lifted]
    parts.append(f'\nvoid register_m{idx}(void) {{')
    for s_, _ in lifted:
        parts.append(f"  vrt_register((MOD_B + 0x{(s_ & ~1) - code.ph['vaddr']:x}u) | {s_ & 1}u, f_{s_ & ~1:x});")
    parts.append('}')
    open(os.path.join(out, f"m{idx}.c"), 'w').write("\n".join(parts) + "\n")
    return rel, idx, len(lifted), sum(lf.stats['ok'].values()), dict(lf.stats['bad']), len(lf.reloc_used), len(rl), found, arm

def cmd_all(a):
    """Emit C for EVERY module + modules_table.c (path, segment-base array, register function)."""
    files = _load(a.app, a.patch)
    os.makedirs(a.out, exist_ok=True)
    mods = [(rel, p) for rel, (p, _) in sorted(files.items())]
    order = sorted(range(len(mods)), key=lambda i: (mods[i][0] != 'eboot.bin', mods[i][0]))      # eboot first, then by name
    jobs = [(mods[i][0], mods[i][1], k, a.out) for k, i in enumerate(order)]
    tot_ok = tot_fn = tot_found = tot_arm = 0; bad = collections.Counter()
    with multiprocessing.Pool(a.jobs) as pool:
        for rel, idx, nfn, ok, b, used, total, found, arm in pool.imap_unordered(_emit_module, jobs):
            tot_ok += ok; tot_fn += nfn; bad.update(b); tot_found += found; tot_arm += arm
            print(f"  m{idx:<3} {rel:42} functions={nfn:6} lifted={ok:8} unsupported={sum(b.values()):5} reloc sites {used}/{total} extra-found={found} arm-lifted={arm}", flush=True)
    t = ['#include <stdint.h>', 'typedef struct { const char *path; uint32_t *seg; void (*reg)(void); } gen_module;']
    t += [f"extern uint32_t m{k}_SEG[4]; extern void register_m{k}(void);" for k in range(len(jobs))]
    t += ['const gen_module gen_modules[] = {']
    t += [f'  {{"{rel}", m{k}_SEG, register_m{k}}},' for rel, _, k, _ in jobs]
    t += ['  {0, 0, 0}', '};']
    open(os.path.join(a.out, 'modules_table.c'), 'w').write("\n".join(t) + "\n")
    print(f"wrote {len(jobs)} module files + modules_table.c in {a.out}: {tot_fn} functions ({tot_found} discovered from call targets), {tot_ok} lifted instructions, unsupported {sum(bad.values())}; ARM-mode functions lifted: {tot_arm}")
    print("unsupported:", dict(bad.most_common(25)))

def build_parser():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest='cmd', required=True)
    for n in ('coverage', 'module', 'all'):
        p = sub.add_parser(n)
        p.add_argument('--app', required=True); p.add_argument('--patch')
        if n in ('coverage', 'all'):
            p.add_argument('--jobs', type=int, default=os.cpu_count() or 2)
        if n == 'coverage':
            p.add_argument('--modules', default='')
        if n == 'module':
            p.add_argument('--module', required=True)
        if n in ('module', 'all'):
            p.add_argument('--out', required=True)
    return ap

if __name__ == '__main__':
    a = build_parser().parse_args()
    {'coverage': cmd_coverage, 'module': cmd_module, 'all': cmd_all}[a.cmd](a)
