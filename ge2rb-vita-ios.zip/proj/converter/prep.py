#!/usr/bin/env python3
"""Stage 1: merge patch over base, unwrap every SELF to ELF, write manifest + HLE worklist.

usage: prep.py --app DIR --patch DIR --out DIR [--nid-db vita-headers/db]
DIR holds eboot.bin, bin/, sce_module/, modules_psvita/ ... (anything with SCE magic is picked up)
"""
import argparse, hashlib, json, os, re, sys, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vita_self import VitaModule

SKIP_PREFIX = ('sce_sys/',)

def collect(root, tag):
    found = {}
    for dp, _, fns in os.walk(root):
        for fn in fns:
            p = os.path.join(dp, fn)
            rel = os.path.relpath(p, root).replace(os.sep, '/')
            if rel.startswith(SKIP_PREFIX): continue
            with open(p, 'rb') as f:
                if f.read(4) != b'SCE\0': continue
            found[rel] = (p, tag)
    return found

def load_nid_db(path):
    db = {}
    if not path or not os.path.isdir(path): return db
    rx = re.compile(r'^\s+([A-Za-z_]\w*):\s+(0x[0-9A-Fa-f]{1,8})\s*$')
    for dp, _, fns in os.walk(path):
        for fn in fns:
            if not fn.endswith('.yml'): continue
            for line in open(os.path.join(dp, fn), errors='ignore'):
                m = rx.match(line)
                if m and m.group(1) not in ('nid', 'version', 'firmware'):
                    db.setdefault(int(m.group(2), 16), m.group(1))
    return db

def sha256(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--app', required=True); ap.add_argument('--patch')
    ap.add_argument('--out', required=True); ap.add_argument('--nid-db')
    a = ap.parse_args()

    files = collect(a.app, 'app')
    if a.patch: files.update(collect(a.patch, 'patch'))      # patch overrides base
    if not files: sys.exit('no SELF files found')
    os.makedirs(os.path.join(a.out, 'elf'), exist_ok=True)
    nids = load_nid_db(a.nid_db)

    mods, provided = {}, set()
    for rel, (p, tag) in sorted(files.items()):
        m = VitaModule(p)
        mi = m.module_info()
        dst = os.path.join(a.out, 'elf', rel.rsplit('.', 1)[0] + '.elf')
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        open(dst, 'wb').write(m.to_elf())
        ex = m.exports(); im = m.imports()
        provided.add(mi['name']); provided.update(e['lib'] for e in ex)
        mods[rel] = dict(source=tag, sha256=sha256(p), name=mi['name'], module_nid=mi['nid'],
                         mod_start=mi['mod_start'], is_exec=(m.e_type == 0xfe04),
                         segments=[dict(type=s.ph['type'], vaddr=s.ph['vaddr'], filesz=s.ph['filesz'],
                                        memsz=s.ph['memsz'], flags=s.ph['flags']) for s in m.segs],
                         exports=[e['lib'] for e in ex],
                         imports=[dict(lib=i['lib'], funcs=[n for n, _ in i['funcs']],
                                       vars=[n for n, _ in i['vars']]) for i in im])

    work = collections.defaultdict(set)      # libs nobody in the package provides -> need HLE
    for rel, m in mods.items():
        for i in m['imports']:
            if i['lib'] not in provided:
                work[i['lib']].update(i['funcs'])
    hle = {lib: sorted(f"0x{n:08X} {nids.get(n, '?')}" for n in s) for lib, s in sorted(work.items())}

    known = {}
    for rel, m in mods.items():
        for i in m['imports']:
            for n in i['funcs']:
                if n in nids: known[f"0x{n:08X}"] = nids[n]
    json.dump(known, open(os.path.join(a.out, 'nid_db.json'), 'w'), indent=0)
    json.dump(dict(modules=mods), open(os.path.join(a.out, 'manifest.json'), 'w'), indent=1)
    json.dump(hle, open(os.path.join(a.out, 'hle_worklist.json'), 'w'), indent=1)
    total = sum(len(v) for v in hle.values())
    named = sum(1 for v in hle.values() for x in v if not x.endswith('?'))
    with open(os.path.join(a.out, 'REPORT.txt'), 'w') as f:
        f.write(f"modules: {len(mods)}  (from patch: {sum(1 for m in mods.values() if m['source']=='patch')})\n")
        f.write(f"system libs to HLE: {len(hle)}  functions: {total}  named: {named}\n\n")
        for lib, v in sorted(hle.items(), key=lambda x: -len(x[1])): f.write(f"{lib:30}{len(v):5}\n")
    print(open(os.path.join(a.out, 'REPORT.txt')).read())

if __name__ == '__main__':
    main()
