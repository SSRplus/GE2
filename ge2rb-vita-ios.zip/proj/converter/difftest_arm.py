#!/usr/bin/env python3
"""Whole-function differential test for the ARM-mode functions the game calls (libgcc-style helpers such as integer division).
Each function is executed in Unicorn (ARM mode, the module's real bytes) and as lifted C with the same random inputs; return registers,
callee-saved registers, sp and memory must match. Functions that call other code or loop forever under Unicorn are skipped."""
import argparse, collections, ctypes, hashlib, os, random, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from unicorn import Uc, UcError, UC_ARCH_ARM, UC_MODE_ARM
from unicorn import arm_const as U
import lift
from difftest import Ctx, INC, SRC, HAR, DATA, DSIZE, rand_val
from vita_self import VitaModule
from prep import collect

SENT = 0x10000000          # return address: execution stops here


def gather(app, patch, mods):
    files = collect(app, 'app')
    if patch:
        files.update(collect(patch, 'patch'))
    funcs, seen = [], set()
    for rel, (p, _) in sorted(files.items()):
        if not any(k in rel for k in mods):
            continue
        m = VitaModule(p)
        code, fns = lift._functions(m)
        from relocs import text_movwt_relocs
        lf = lift.Lifter(code.ph['vaddr'], m.read, relocs=text_movwt_relocs(m))
        lifted, _, _ = lift._lift_all(m, lf, code, fns, lambda s: 'f')
        arm_starts = [s for s, _ in lifted if not s & 1]
        allst = sorted({s & ~1 for s in m.function_starts()} | {s & ~1 for s, _ in lifted} | {code.ph['vaddr'] + len(code.data)})
        for s in arm_starts:
            end = min(x for x in allst if x > s)
            end = min(end, s + 0x2000)
            body = m.read(s, end - s)
            h = hashlib.md5(body).hexdigest()
            if h in seen:
                continue
            seen.add(h)
            funcs.append((rel, m, code, s, end))
    return funcs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--app', required=True); ap.add_argument('--patch'); ap.add_argument('--out', default='difftest_arm.txt')
    ap.add_argument('--modules', default='eboot,god.self,net.self,enemy.self,libc,libdeflt')
    ap.add_argument('--states', type=int, default=60)
    a = ap.parse_args()
    funcs = gather(a.app, a.patch, a.modules.split(','))
    print(f"{len(funcs)} distinct ARM-mode functions to test", flush=True)
    if not funcs:
        open(a.out, 'w').write("no ARM-mode functions found\n"); return

    body = ['#include "vita_ops.h"', 'uint32_t MOD_B;', 'uint32_t MOD_SEG[4];']
    for i, (rel, m, code, s, end) in enumerate(funcs):
        lf = lift.Lifter(code.ph['vaddr'], m.read, arm=True)
        body.append(lf.lift_function(s, end, f"f{i}", storage='static '))
        body.append(f"void T{i}(vrt_ctx *x) {{ f{i}(x); }}")
    d = tempfile.mkdtemp(); cpath, so = os.path.join(d, 't.c'), os.path.join(d, 't.so')
    open(cpath, 'w').write("\n".join(body))
    srcs = [os.path.join(SRC, f) for f in os.listdir(SRC) if f.endswith('.c')]
    r = subprocess.run(['gcc', '-shared', '-fPIC', '-O1', '-w', '-ffp-contract=off', '-I', INC, *srcs, HAR, cpath, '-o', so, '-lpthread', '-lm'], capture_output=True, text=True)
    if r.returncode:
        print(r.stderr[:3000]); sys.exit('generated C failed to compile')
    lib = ctypes.CDLL(so)
    lib.vrt_commit.argtypes = [ctypes.c_uint32, ctypes.c_size_t]; lib.vrt_harness_run.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    assert lib.vrt_init(0) == 0 and lib.vrt_commit(DATA, DSIZE) == 0
    mem = ctypes.c_void_p.in_dll(lib, 'vrt_mem').value
    mod_b = ctypes.c_uint32.in_dll(lib, 'MOD_B')
    rng = random.Random(11); lines = []; tot = bad = 0
    for i, (rel, m, code, s, end) in enumerate(funcs):
        base = code.ph['vaddr'] & ~0xfff; size = ((end - base) + 0xfff) & ~0xfff
        text = bytearray(m.read(base, size))
        mod_b.value = code.ph['vaddr']
        assert lib.vrt_commit(base, size) == 0
        ctypes.memmove(mem + base, bytes(text), size)
        fn = ctypes.cast(getattr(lib, f"T{i}"), ctypes.c_void_p)
        mu = Uc(UC_ARCH_ARM, UC_MODE_ARM); mu.mem_map(base, size); mu.mem_map(DATA, DSIZE); mu.mem_write(base, bytes(text))
        ok = fail = skip = 0; ex = []
        for _ in range(a.states):
            regs = [rand_val(rng) for _ in range(13)]
            if rng.random() < 0.5:
                regs[0], regs[1] = rng.choice([0, 1, 2, 3, 7, 100, 1000, 0xffff, 0x7fffffff, 0x80000000, 0xffffffff]), rng.choice([0, 1, 2, 3, 5, 10, 255, 0x10000, 0x7fffffff, 0xffffffff])
            sp = DATA + 0x8000 + rng.randrange(0, 0x400) * 4
            data = bytes(rng.getrandbits(8) for _ in range(DSIZE))
            mu.mem_write(DATA, data)
            mu.reg_write(U.UC_ARM_REG_CPSR, 0x10 | (rng.getrandbits(4) << 28))
            for k in range(13): mu.reg_write(getattr(U, f'UC_ARM_REG_R{k}'), regs[k])
            mu.reg_write(U.UC_ARM_REG_SP, sp); mu.reg_write(U.UC_ARM_REG_LR, SENT)
            try:
                mu.emu_start(s, SENT, count=200000)
                if mu.reg_read(U.UC_ARM_REG_PC) != SENT:
                    skip += 1; continue
            except UcError:
                skip += 1; continue
            exp = [mu.reg_read(getattr(U, f'UC_ARM_REG_R{k}')) for k in range(13)] + [mu.reg_read(U.UC_ARM_REG_SP)]
            exp_mem = bytes(mu.mem_read(DATA, DSIZE))
            ctypes.memmove(mem + DATA, data, DSIZE)
            c = Ctx()
            for k in range(13): c.r[k] = regs[k]
            c.r[13] = sp; c.r[14] = SENT
            rc = lib.vrt_harness_run(fn, ctypes.byref(c))
            got = [c.r[k] for k in range(14)]; got_mem = ctypes.string_at(mem + DATA, DSIZE)
            tot += 1
            if rc == 0 and got == exp and got_mem == exp_mem:
                ok += 1
            else:
                fail += 1; bad += 1
                if len(ex) < 2:
                    diffs = [f"r{k}: want {exp[k]:#x} got {got[k]:#x}" for k in range(14) if exp[k] != got[k]][:4]
                    ex.append(f"    in r0={regs[0]:#x} r1={regs[1]:#x} -> " + ("C crashed" if rc else "; ".join(diffs) + ("; memory differs" if exp_mem != got_mem else "")))
        lines.append(f"{rel:34} +0x{s - code.ph['vaddr']:06x} size={end - s:5} ok={ok:3} FAIL={fail:3} skipped={skip:3}")
        lines += ex
    lines.insert(0, f"TOTAL {tot - bad}/{tot} passed over {len(funcs)} ARM functions")
    open(a.out, 'w').write("\n".join(lines) + "\n")
    print("\n".join(lines[:60]))


if __name__ == '__main__':
    main()
