import os, glob, pytest, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vita_self import VitaModule
G = os.environ.get('GAME_CODE', 'game')
files = glob.glob(os.path.join(G, '**', '*.self'), recursive=True)[:5]

@pytest.mark.skipif(not files, reason='no game files')
@pytest.mark.parametrize('f', files)
def test_unwrap(f):
    m = VitaModule(f)
    assert m.to_elf()[:4] == b'\x7fELF' and m.e_machine == 40
    assert m.module_info()['name']
