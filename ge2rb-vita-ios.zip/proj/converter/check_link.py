#!/usr/bin/env python3
"""Cross-check the C linker (runtime/test/test_link) against the independent Python analysis (link_check.py).
usage: check_link.py LINK_OUTPUT.txt APPDIR PATCHDIR [hle_worklist.json]"""
import collections, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from link_check import compute

def main():
    out, app, patch = sys.argv[1:4]
    line = next(l for l in open(out) if l.startswith('modules='))
    c = {k: int(v) for k, v in re.findall(r'(\w+)=(\d+)', line)}
    py = compute(app, patch)
    pairs = [('modules', 'modules'), ('game_func', 'game_func'), ('game_var', 'game_var'), ('hle_func_missing', 'system_func'), ('hle_var', 'system_var')]
    ok = True
    for ck, pk in pairs:
        same = c[ck] == py[pk]; ok &= same
        print(f"  {ck:18} C={c[ck]:6}  python={py[pk]:6}  {'ok' if same else 'MISMATCH'}")
    ce = c['exports'] if 'exports' in c else None
    if py['missing']:
        ok = False; print("  python found MISSING symbols in game libraries:", py['missing'])
    print("  load failures:", c.get('load_failures'))
    ok &= c.get('load_failures') == 0
    if len(sys.argv) > 4:                      # annotate the system calls the game needs, by library
        names = json.load(open(sys.argv[4]))
        print("\nSystem libraries to implement (HLE) - unique functions:")
        for lib, lst in sorted(names.items(), key=lambda kv: -len(kv[1])):
            print(f"  {lib:28}{len(lst):4}   e.g. " + ", ".join(x.split(' ', 1)[1] for x in lst[:3]))
    print("link cross-check:", "C linker == Python analysis" if ok else "MISMATCH")
    sys.exit(0 if ok else 1)

if __name__ == '__main__':
    main()
