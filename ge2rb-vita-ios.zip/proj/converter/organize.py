#!/usr/bin/env python3
"""Pull ONLY the game's code (SELF files) out of the user's game zip into game/{app,patch}/.

Assets (GBs) are never extracted in CI; they stay in the zip the user imports on the phone.
Accepts wrapper folders, `ux0/app/PCSE00789/...`, or a bare `PCSE00789/...` (treated as base).

usage: organize.py --zip game.zip --out game [--title PCSE00789]
"""
import argparse, os, sys, zipfile

def map_path(path, title):
    c = [x for x in path.replace('\\', '/').split('/') if x not in ('.', '..', '')]
    for i in range(len(c) - 1):
        if c[i] in ('app', 'patch') and c[i + 1] == title:
            return c[i], c[i + 2:]
    if title in c:
        i = c.index(title)
        return 'app', c[i + 1:]
    return None

def is_code_name(rel):
    b = rel[-1] if rel else ''
    return b == 'eboot.bin' or b.endswith(('.self', '.suprx'))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--zip', required=True); ap.add_argument('--out', required=True)
    ap.add_argument('--title', default='PCSE00789')
    a = ap.parse_args()
    n = {'app': 0, 'patch': 0}; bad = 0
    with zipfile.ZipFile(a.zip) as z:
        for info in z.infolist():
            if info.is_dir(): continue
            m = map_path(info.filename, a.title)
            if not m or not m[1] or not is_code_name(m[1]): continue
            side, rel = m
            dst = os.path.join(a.out, side, *rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            with z.open(info) as src, open(dst, 'wb') as out:
                head = src.read(4)
                if head != b'SCE\0':          # not a SELF (e.g. a plain data file named *.suprx)
                    out.close(); os.remove(dst); bad += 1; continue
                out.write(head)
                while True:
                    chunk = src.read(1 << 20)
                    if not chunk: break
                    out.write(chunk)
            n[side] += 1
    print(f"extracted code files: app={n['app']} patch={n['patch']} (skipped non-SELF: {bad})")
    if n['app'] == 0:
        sys.exit(f"no {a.title} code found in zip - expected app/{a.title}/eboot.bin")
    if n['patch'] == 0:
        print("warning: no patch code found - the update (patch/) is required for the current game version")

if __name__ == '__main__':
    main()
