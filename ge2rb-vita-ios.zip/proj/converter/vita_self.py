"""Minimal PS Vita SELF (already decrypted) -> ELF reader + SceModuleInfo parser."""
import struct, zlib

class Seg:
    def __init__(s, idx, ph, data): s.idx = idx; s.ph = ph; s.data = data

class VitaModule:
    def __init__(self, path):
        self.path = path
        d = open(path, 'rb').read()
        if d[:4] != b'SCE\0':
            raise ValueError('not a SELF')
        self._unwrap(d)
        self._parse()

    def _unwrap(self, d):
        (magic, ver, sdk, htype, meta, hlen, elfsz, selfsz, unk, selfoff, appoff,
         elfoff, phoff, shoff, secinfo) = struct.unpack('<4sIHHIQQQQQQQQQQ', d[:0x60])
        self.eh = d[elfoff:elfoff + 0x34]
        phnum, = struct.unpack('<H', self.eh[0x2c:0x2e])
        self.phraw = d[phoff:phoff + phnum * 0x20]
        self.blobs = []
        for i in range(phnum):
            off, ln, comp, enc = struct.unpack('<QQQQ', d[secinfo + i*0x20: secinfo + i*0x20 + 0x20])
            if enc != 2:
                raise ValueError(f'{self.path}: segment {i} is encrypted - dump with NoNpDrm/FAGDec first')
            raw = d[off:off + ln]
            if comp == 2:
                raw = zlib.decompress(raw)
            self.blobs.append(raw)

    def _parse(self):
        self.e_type, self.e_machine = struct.unpack('<HH', self.eh[0x10:0x14])
        self.e_entry, = struct.unpack('<I', self.eh[0x18:0x1c])
        self.segs = []
        for i in range(len(self.phraw) // 0x20):
            t, off, va, pa, fsz, msz, fl, al = struct.unpack('<8I', self.phraw[i*0x20:(i+1)*0x20])
            ph = dict(type=t, off=off, vaddr=va, paddr=pa, filesz=fsz, memsz=msz, flags=fl, align=al)
            self.segs.append(Seg(i, ph, self.blobs[i][:fsz]))
        self.loads = [s for s in self.segs if s.ph['type'] == 1]

    def to_elf(self):
        phoff, = struct.unpack('<I', self.eh[0x1c:0x20])
        size = max([phoff + len(self.phraw)] + [s.ph['off'] + len(s.data) for s in self.segs])
        out = bytearray(size)
        out[:0x34] = self.eh
        out[phoff:phoff + len(self.phraw)] = self.phraw
        for s in self.segs:
            out[s.ph['off']:s.ph['off'] + len(s.data)] = s.data
        return bytes(out)

    def read(self, vaddr, n):
        for s in self.loads:
            b = s.ph['vaddr']
            if b <= vaddr < b + s.ph['memsz']:
                o = vaddr - b
                c = s.data[o:o + n]
                return c + b'\0' * (n - len(c))
        raise KeyError(hex(vaddr))

    def cstr(self, vaddr):
        out = b''
        while len(out) < 256:
            c = self.read(vaddr + len(out), 1)
            if c == b'\0': break
            out += c
        return out.decode('latin1')

    def module_info(self):
        seg = self.e_entry >> 30
        off = self.e_entry & 0x3fffffff
        base = self.segs[seg].ph['vaddr']
        mi = self.read(base + off, 0x5c)
        attr, ver = struct.unpack('<HH', mi[:4])
        name = mi[4:31].split(b'\0')[0].decode()
        gp, ent_top, ent_end, stub_top, stub_end, nid = struct.unpack('<6I', mi[0x20:0x38])
        mod_start, mod_stop = struct.unpack('<2I', mi[0x44:0x4c])
        exidx_top, exidx_end = struct.unpack('<2I', mi[0x4c:0x54])
        return dict(exidx=(base + exidx_top, base + exidx_end), name=name, attr=attr, nid=nid, seg_base=base, mi_vaddr=base + off,
                    ent=(base + ent_top, base + ent_end), stub=(base + stub_top, base + stub_end),
                    mod_start=mod_start, mod_stop=mod_stop)

    def imports(self):
        a, b = self.module_info()['stub']
        res, p = [], a
        while p < b:
            size, = struct.unpack('<H', self.read(p, 2))
            if size not in (0x24, 0x34): break
            r = self.read(p, size)
            ver, attr, nf, nv, nt = struct.unpack('<5H', r[2:12])
            if size == 0x34:
                nid, nameptr, _, fnid, fent, vnid, vent = struct.unpack('<7I', r[0x10:0x2c])
            else:
                nid, nameptr, fnid, fent, vnid, vent = struct.unpack('<6I', r[0x0c:0x24])
            u32 = lambda a: struct.unpack('<I', self.read(a, 4))[0]
            res.append(dict(lib=self.cstr(nameptr) if nameptr else '', lib_nid=nid,
                            funcs=[(u32(fnid + 4*i), u32(fent + 4*i)) for i in range(nf)],
                            vars=[(u32(vnid + 4*i), u32(vent + 4*i)) for i in range(nv)]))
            p += size
        return res

    def exports(self):
        """Export libraries of this module: list of dict(lib, lib_nid, funcs=[(nid, addr)], vars=[(nid, addr)]).
        Layout (0x20 bytes): size:u16 ver:u16 attr:u16 nfunc:u16 nvar:u32 ntls:u32 lib_nid:u32 name*:u32 nid_table*:u32 entry_table*:u32.
        Tables hold functions first, then variables (verified: first nfunc entries are Thumb text addresses)."""
        a, b = self.module_info()['ent']
        res, p = [], a
        u32 = lambda x: struct.unpack('<I', self.read(x, 4))[0]
        while p < b:
            size, = struct.unpack('<H', self.read(p, 2))
            if size < 0x20:
                break
            r = self.read(p, size)
            attr, nf = struct.unpack('<HH', r[4:8])
            nv, ntls, lib_nid, nameptr, nidtab, enttab = struct.unpack('<6I', r[8:32])
            n = nf + nv
            nids = [u32(nidtab + 4 * i) for i in range(n)]
            ents = [u32(enttab + 4 * i) for i in range(n)]
            res.append(dict(lib=self.cstr(nameptr) if nameptr else '', lib_nid=lib_nid, attr=attr,
                            funcs=list(zip(nids[:nf], ents[:nf])), vars=list(zip(nids[nf:], ents[nf:]))))
            p += size
        return res

    def function_starts(self):
        """Function entry addresses from ARM.exidx. Bit 0 set = Thumb. Sorted, unique."""
        a, b = self.module_info()['exidx']
        out = set()
        for ea in range(a, b, 8):
            w, = struct.unpack('<I', self.read(ea, 4))
            off = ((w & 0x7fffffff) ^ 0x40000000) - 0x40000000      # prel31 -> signed
            out.add((ea + off) & 0xffffffff)
        return sorted(out)
